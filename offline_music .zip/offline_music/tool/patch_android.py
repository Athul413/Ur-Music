"""Patches the flutter-generated Android project for streaming, background audio and the server service."""
import glob, re

mf = "android/app/src/main/AndroidManifest.xml"
s = open(mf).read()

perms = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>
"""
s = s.replace("<application", perms + "    <application", 1)
s = s.replace("<application", '<application android:usesCleartextTraffic="true" android:requestLegacyExternalStorage="true"', 1)

services = """
        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback" android:exported="true">
            <intent-filter><action android:name="android.media.browse.MediaBrowserService"/></intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver" android:exported="true">
            <intent-filter><action android:name="android.intent.action.MEDIA_BUTTON"/></intent-filter>
        </receiver>
        <service android:name="com.pravera.flutter_foreground_task.service.ForegroundService"
            android:foregroundServiceType="dataSync" android:exported="false"/>
"""
s = s.replace("</application>", services + "    </application>", 1)
open(mf, "w").write(s)

for f in glob.glob("android/app/src/main/**/MainActivity.*", recursive=True):
    src = open(f).read()
    pkg = re.search(r"package\s+([\w.]+)", src).group(1)
    if f.endswith(".kt"):
        open(f, "w").write(f"package {pkg}\n\nimport com.ryanheise.audioservice.AudioServiceActivity\n\nclass MainActivity : AudioServiceActivity()\n")
    else:
        open(f, "w").write(f"package {pkg};\n\nimport com.ryanheise.audioservice.AudioServiceActivity;\n\npublic class MainActivity extends AudioServiceActivity {{}}\n")
print("patched")

# --- Achufy branding: app name + launcher icons ---
import os, shutil
s = open(mf).read()
s = re.sub(r'android:label="[^"]*"', 'android:label="Achufy"', s, count=1)
open(mf, "w").write(s)
for d in glob.glob("tool/icons/mipmap-*"):
    dst = os.path.join("android/app/src/main/res", os.path.basename(d))
    os.makedirs(dst, exist_ok=True)
    for f in glob.glob(d + "/*.png"):
        shutil.copy(f, dst)
    for old in glob.glob(dst + "/ic_launcher.*"):
        if not old.endswith(".png"):
            os.remove(old)
print("branded")
