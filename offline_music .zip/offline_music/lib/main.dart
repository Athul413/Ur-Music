import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'client.dart';
import 'server.dart';

const kGreen = Color(0xFF1DB954);
const kBg = Color(0xFF121212);

final messengerKey = GlobalKey<ScaffoldMessengerState>();
final currentId = ValueNotifier<String?>(null);

void toast(String msg) {
  messengerKey.currentState
    ?..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
        content: Text(msg), behavior: SnackBarBehavior.floating));
}

Future<void> main() async {
  runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (d) {
      FlutterError.presentError(d);
      toast('Something went wrong. Please try again.');
    };
    await JustAudioBackground.init(
      androidNotificationChannelId: 'com.example.achufy.audio',
      androidNotificationChannelName: 'Achufy playback',
      androidNotificationOngoing: true,
    );
    player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace st) {
      toast(e is PlayerException
          ? "Can't play this track: ${e.message ?? 'unknown error'}"
          : "Playback error. Check the server connection.");
    });
    player.sequenceStateStream.listen((s) {
      final t = s?.currentSource?.tag;
      currentId.value = t is MediaItem ? t.id : null;
    });
    runApp(const App());
  }, (e, st) => toast('Something went wrong: $e'));
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Achufy',
        scaffoldMessengerKey: messengerKey,
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
              seedColor: kGreen, brightness: Brightness.dark, primary: kGreen),
          scaffoldBackgroundColor: kBg,
          appBarTheme: const AppBarTheme(
              backgroundColor: kBg, elevation: 0, scrolledUnderElevation: 0),
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: Colors.black,
            indicatorColor: Colors.transparent,
            labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
                fontSize: 12,
                color: s.contains(WidgetState.selected)
                    ? Colors.white
                    : Colors.white54)),
            iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
                color: s.contains(WidgetState.selected)
                    ? Colors.white
                    : Colors.white54)),
          ),
        ),
        home: const ModePicker(),
      );
}

class ModePicker extends StatelessWidget {
  const ModePicker({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(28),
                    child: Image.asset('assets/logo.png', width: 110, height: 110),
                  ),
                ),
                const SizedBox(height: 20),
                const Text('Achufy',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
                const Text('Your music. No internet needed.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60)),
                const SizedBox(height: 44),
                FilledButton(
                  style: FilledButton.styleFrom(
                      backgroundColor: kGreen,
                      foregroundColor: Colors.black,
                      shape: const StadiumBorder(),
                      padding: const EdgeInsets.symmetric(vertical: 16)),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ClientPage())),
                  child: const Text('Play music',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                ),
                const SizedBox(height: 14),
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                      shape: const StadiumBorder(),
                      side: const BorderSide(color: Colors.white38),
                      padding: const EdgeInsets.symmetric(vertical: 16)),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ServerPage())),
                  child: const Text('Run as music server (old phone)',
                      style: TextStyle(fontSize: 15)),
                ),
              ],
            ),
          ),
        ),
      );
}
