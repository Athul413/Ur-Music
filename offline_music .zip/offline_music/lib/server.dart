import 'dart:convert';
import 'dart:io';
import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:flutter/material.dart' hide Router;
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;
import 'package:shelf_router/shelf_router.dart';

const _mimes = {
  'mp3': 'audio/mpeg', 'm4a': 'audio/mp4', 'aac': 'audio/aac',
  'flac': 'audio/flac', 'ogg': 'audio/ogg', 'opus': 'audio/ogg',
  'wav': 'audio/wav',
};

class Track {
  final int id;
  final String path, title, artist, album;
  final bool cover;
  Track(this.id, this.path, this.title, this.artist, this.album, this.cover);
  Map<String, dynamic> toJson() => {
        'id': id, 'title': title, 'artist': artist, 'album': album, 'cover': cover,
      };
}

int _stableId(String s) {
  var h = 0x811c9dc5;
  for (final b in utf8.encode(s)) {
    h ^= b;
    h = (h * 0x01000193) & 0xFFFFFFFF;
  }
  return h;
}

class MusicServer {
  HttpServer? _http;
  final Map<int, Track> byId = {};

  Future<int> scan(String dir) async {
    byId.clear();
    final d = Directory(dir);
    if (!await d.exists()) return 0;
    await for (final e in d.list(recursive: true, followLinks: false)) {
      if (e is! File) continue;
      final ext = e.path.split('.').last.toLowerCase();
      if (!_mimes.containsKey(ext)) continue;
      final name = e.uri.pathSegments.last.replaceAll(RegExp(r'\.[^.]+$'), '');
      String title = name, artist = 'Unknown artist', album = 'Unknown album';
      bool cover = false;
      try {
        final m = readMetadata(e, getImage: true);
        if ((m.title ?? '').trim().isNotEmpty) title = m.title!;
        if ((m.artist ?? '').trim().isNotEmpty) artist = m.artist!;
        if ((m.album ?? '').trim().isNotEmpty) album = m.album!;
        cover = m.pictures.isNotEmpty;
      } catch (_) {}
      var id = _stableId(e.path.replaceFirst(dir, ''));
      while (byId.containsKey(id)) {
        id++;
      }
      byId[id] = Track(id, e.path, title, artist, album, cover);
    }
    return byId.length;
  }

  Track? _byId(String id) {
    final i = int.tryParse(id);
    return i == null ? null : byId[i];
  }

  Future<Response> _stream(Request req, String id) async {
    final t = _byId(id);
    if (t == null) return Response.notFound('no such track');
    final file = File(t.path);
    if (!await file.exists()) return Response.notFound('file missing');
    final int len;
    try {
      len = await file.length();
    } catch (_) {
      return Response.internalServerError(body: 'cannot read file');
    }
    final ext = t.path.split('.').last.toLowerCase();
    final h = {
      'content-type': _mimes[ext] ?? 'application/octet-stream',
      'accept-ranges': 'bytes',
    };
    final m = RegExp(r'bytes=(\d*)-(\d*)').firstMatch(req.headers['range'] ?? '');
    if (m != null) {
      final s = m.group(1)!.isEmpty ? 0 : int.parse(m.group(1)!);
      var e = m.group(2)!.isEmpty ? len - 1 : int.parse(m.group(2)!);
      if (e >= len) e = len - 1;
      if (s > e) return Response(416, headers: {'content-range': 'bytes */$len'});
      return Response(206,
          body: file.openRead(s, e + 1),
          headers: {
            ...h,
            'content-range': 'bytes $s-$e/$len',
            'content-length': '${e - s + 1}',
          });
    }
    return Response.ok(file.openRead(), headers: {...h, 'content-length': '$len'});
  }

  Response _cover(Request req, String id) {
    final t = _byId(id);
    if (t == null || !t.cover) return Response.notFound('no cover');
    try {
      final p = readMetadata(File(t.path), getImage: true).pictures.first;
      return Response.ok(p.bytes, headers: {
        'content-type': p.mimetype.isEmpty ? 'image/jpeg' : p.mimetype,
        'cache-control': 'max-age=86400',
      });
    } catch (_) {
      return Response.notFound('no cover');
    }
  }

  // Lyrics: a .lrc (synced) or .txt file with the same name as the song.
  Future<Response> _lyrics(Request req, String id) async {
    final t = _byId(id);
    if (t == null) return Response.notFound('no such track');
    final base = t.path.replaceFirst(RegExp(r'\.[^./]+$'), '');
    for (final ext in ['lrc', 'LRC', 'txt', 'TXT']) {
      final f = File('$base.$ext');
      if (await f.exists()) {
        final bytes = await f.readAsBytes();
        return Response.ok(bytes,
            headers: {'content-type': 'text/plain; charset=utf-8'});
      }
    }
    return Response.notFound('no lyrics');
  }

  Future<void> start(int port) async {
    await stop();
    final r = Router()
      ..get('/api/ping', (Request _) => Response.ok('ok'))
      ..get(
          '/api/tracks',
          (Request _) => Response.ok(
              jsonEncode(byId.values.map((t) => t.toJson()).toList()),
              headers: {'content-type': 'application/json'}))
      ..get('/stream/<id>', _stream)
      ..get('/cover/<id>', _cover)
      ..get('/lyrics/<id>', _lyrics);
    _http = await io.serve(r.call, InternetAddress.anyIPv4, port);
  }

  Future<void> stop() async {
    await _http?.close(force: true);
    _http = null;
  }
}

class ServerPage extends StatefulWidget {
  const ServerPage({super.key});
  @override
  State<ServerPage> createState() => _ServerPageState();
}

class _ServerPageState extends State<ServerPage> {
  static final _server = MusicServer();
  final _dir = TextEditingController(text: '/storage/emulated/0/Music');
  final _port = TextEditingController(text: '8080');
  bool _running = false, _busy = false;
  String _status = 'Stopped';
  List<String> _ips = [];

  Future<void> _start() async {
    try {
      await _startInner();
    } catch (e) {
      try {
        await _server.stop();
        await FlutterForegroundTask.stopService();
      } catch (_) {}
      if (mounted) {
        setState(() {
          _busy = false;
          _running = false;
          _status = 'Error: $e';
        });
      }
    }
  }

  Future<void> _startInner() async {
    setState(() {
      _busy = true;
      _status = 'Requesting permissions...';
    });
    await Permission.manageExternalStorage.request();
    await Permission.notification.request();
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'achufy_server', channelName: 'Achufy server'),
      iosNotificationOptions: const IOSNotificationOptions(),
      foregroundTaskOptions: ForegroundTaskOptions(
          eventAction: ForegroundTaskEventAction.nothing()),
    );
    await FlutterForegroundTask.startService(
        notificationTitle: 'Achufy server running',
        notificationText: 'Serving your library on the local network');
    setState(() => _status = 'Scanning library...');
    final dir = _dir.text.trim();
    if (!await Directory(dir).exists()) {
      throw 'Folder not found: $dir\n(Allow "all files access" for Achufy in Settings > Apps.)';
    }
    final n = await _server.scan(dir);
    final port = int.tryParse(_port.text) ?? 8080;
    await _server.start(port);
    final ips = <String>[];
    for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
      for (final a in i.addresses) {
        ips.add('${a.address}:$port');
      }
    }
    if (!mounted) return;
    setState(() {
      _running = true;
      _busy = false;
      _ips = ips;
      _status = n == 0
          ? 'Running - 0 tracks found (is the folder empty?)'
          : 'Running - $n tracks';
    });
  }

  Future<void> _stop() async {
    await _server.stop();
    await FlutterForegroundTask.stopService();
    setState(() {
      _running = false;
      _status = 'Stopped';
      _ips = [];
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Achufy server')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          TextField(
              controller: _dir,
              enabled: !_running,
              decoration: const InputDecoration(
                  labelText: 'Music folder', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(
              controller: _port,
              enabled: !_running,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  labelText: 'Port', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : (_running ? _stop : _start),
            child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(_running ? 'Stop server' : 'Start server')),
          ),
          const SizedBox(height: 20),
          Text(_status, style: const TextStyle(fontSize: 16)),
          if (_ips.isNotEmpty) ...[
            const SizedBox(height: 12),
            const Text('Enter one of these in the player:'),
            for (final ip in _ips)
              SelectableText(ip,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold)),
          ],
          const SizedBox(height: 24),
          const Text('Lyrics: put a .lrc (synced) or .txt file with the same name '
              'next to each song, e.g. song.mp3 + song.lrc.\n\n'
              'Tip: turn off battery optimization for this app and keep the phone '
              'plugged in.'),
        ]),
      );
}
