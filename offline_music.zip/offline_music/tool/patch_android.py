"""Patches the flutter-generated Android project for streaming, background audio and the server service."""
import glob, re

mf = "android/app/src/main/AndroidManifest.xml"
s = open(mf).read()

perms = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>
"""
# Add permissions before the application element.
s = s.replace("<application", perms + "    <application", 1)

# Flutter's generated manifest already contains android:label and android:icon.
# Replace those values instead of adding duplicate XML attributes (which makes
# AndroidManifest.xml fail to parse).
app_match = re.search(r"<application\b[^>]*>", s, flags=re.DOTALL)
if not app_match:
    raise SystemExit("Could not find the <application> element in AndroidManifest.xml")
app_tag = app_match.group(0)

def set_android_attr(tag, name, value):
    pattern = rf'\bandroid:{re.escape(name)}\s*=\s*"[^"]*"'
    replacement = f'android:{name}="{value}"'
    if re.search(pattern, tag):
        return re.sub(pattern, replacement, tag, count=1)
    return tag[:-1].rstrip() + f' {replacement}>'

app_tag = set_android_attr(app_tag, "label", "Achufy")
app_tag = set_android_attr(app_tag, "icon", "@drawable/achufy_icon")
app_tag = set_android_attr(app_tag, "usesCleartextTraffic", "true")
app_tag = set_android_attr(app_tag, "requestLegacyExternalStorage", "true")
s = s[:app_match.start()] + app_tag + s[app_match.end():]

# A simple vector launcher mark matching the in-app Achufy logo.
import os
os.makedirs("android/app/src/main/res/drawable", exist_ok=True)
open("android/app/src/main/res/drawable/achufy_icon.xml", "w").write("""<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#101310" android:pathData="M0,0h108v108h-108z"/>
    <path android:fillColor="#1ED760" android:pathData="M10,96L39,12Q43,2 49,12L98,96H73L45,35L28,96Z"/>
    <path android:strokeColor="#101310" android:strokeWidth="5" android:strokeLineCap="round"
        android:pathData="M53,67L53,91 M64,57L64,91 M75,70L75,91"/>
</vector>
""")

services = """
        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback" android:exported="true">
            <intent-filter><action android:name="android.media.browse.MediaBrowserService"/></intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver" android:exported="true">
            <intent-filter><action android:name="android.intent.action.MEDIA_BUTTON"/></intent-filter>
        </receiver>
        <service android:name="com.pravera.flutter_foreground_task.service.ForegroundService"
            android:foregroundServiceType="dataSync" android:exported="false"/>
"""
s = s.replace("</application>", services + "    </application>", 1)
open(mf, "w").write(s)

for f in glob.glob("android/app/src/main/**/MainActivity.*", recursive=True):
    src = open(f).read()
    pkg = re.search(r"package\s+([\w.]+)", src).group(1)
    if f.endswith(".kt"):
        open(f, "w").write(f"package {pkg}\n\nimport com.ryanheise.audioservice.AudioServiceActivity\n\nclass MainActivity : AudioServiceActivity()\n")
    else:
        open(f, "w").write(f"package {pkg};\n\nimport com.ryanheise.audioservice.AudioServiceActivity;\n\npublic class MainActivity extends AudioServiceActivity {{}}\n")
print("patched")
