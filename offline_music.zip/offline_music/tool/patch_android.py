"""Patches the flutter-generated Android project for streaming, background audio and the server service."""
import glob, re

mf = "android/app/src/main/AndroidManifest.xml"
s = open(mf).read()

perms = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>
"""
s = s.replace("<application", perms + "    <application", 1)
s = s.replace("<application", '<application android:usesCleartextTraffic="true" android:requestLegacyExternalStorage="true"', 1)

services = """
        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback" android:exported="true">
            <intent-filter><action android:name="android.media.browse.MediaBrowserService"/></intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver" android:exported="true">
            <intent-filter><action android:name="android.intent.action.MEDIA_BUTTON"/></intent-filter>
        </receiver>
        <service android:name="com.pravera.flutter_foreground_task.service.ForegroundService"
            android:foregroundServiceType="dataSync" android:exported="false"/>
"""
s = s.replace("</application>", services + "    </application>", 1)
open(mf, "w").write(s)

KT = """package PKG

import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : AudioServiceActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "achufy/audio")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "outputs" -> result.success(outputs())
                    "openSwitcher" -> result.success(launch(
                        if (Build.VERSION.SDK_INT >= 29) "android.settings.panel.action.VOLUME"
                        else Settings.ACTION_BLUETOOTH_SETTINGS))
                    "openBluetooth" -> result.success(launch(Settings.ACTION_BLUETOOTH_SETTINGS))
                    else -> result.notImplemented()
                }
            }
    }

    private fun launch(action: String): Boolean {
        return try {
            startActivity(Intent(action))
            true
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                true
            } catch (e2: Exception) {
                false
            }
        }
    }

    private fun outputs(): Map<String, Any> {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val list = ArrayList<Map<String, String>>()
        val seen = HashSet<String>()
        for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            val kind: String = when (d.type) {
                AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "speaker"
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "bluetooth"
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "wired"
                AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "usb"
                AudioDeviceInfo.TYPE_HDMI -> "hdmi"
                else -> ""
            }
            if (kind.isEmpty()) continue
            val product = d.productName?.toString() ?: ""
            val name = if (kind == "speaker") "Phone speaker"
                else if (product.isNotBlank()) product else kind.replaceFirstChar { it.uppercase() }
            if (seen.add(kind + name)) list.add(mapOf("kind" to kind, "name" to name))
        }
        @Suppress("DEPRECATION")
        val active = if (am.isBluetoothA2dpOn) "bluetooth" else if (am.isWiredHeadsetOn) "wired" else "speaker"
        return mapOf("active" to active, "devices" to list)
    }
}
"""

for f in glob.glob("android/app/src/main/**/MainActivity.*", recursive=True):
    src = open(f).read()
    pkg = re.search(r"package\s+([\w.]+)", src).group(1)
    if f.endswith(".kt"):
        open(f, "w").write(KT.replace("PKG", pkg))
    else:
        open(f, "w").write("package " + pkg + ";\n\nimport com.ryanheise.audioservice.AudioServiceActivity;\n\npublic class MainActivity extends AudioServiceActivity {}\n")
print("patched")

# --- Achufy branding: app name + launcher icons ---
import os, shutil
s = open(mf).read()
s = re.sub(r'android:label="[^"]*"', 'android:label="Achufy"', s, count=1)
open(mf, "w").write(s)
for d in glob.glob("tool/icons/mipmap-*"):
    dst = os.path.join("android/app/src/main/res", os.path.basename(d))
    os.makedirs(dst, exist_ok=True)
    for f in glob.glob(d + "/*.png"):
        shutil.copy(f, dst)
    for old in glob.glob(dst + "/ic_launcher.*"):
        if not old.endswith(".png"):
            os.remove(old)
print("branded")
