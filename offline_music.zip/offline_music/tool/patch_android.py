"""Patches the flutter-generated Android project:
streaming, background audio, server service, Android TV, floating lyrics, branding."""
import glob, os, re, shutil

mf = "android/app/src/main/AndroidManifest.xml"
s = open(mf).read()

perms = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
    <uses-feature android:name="android.software.leanback" android:required="false"/>
    <uses-feature android:name="android.hardware.touchscreen" android:required="false"/>
"""
s = s.replace("<application", perms + "    <application", 1)
s = s.replace(
    "<application",
    '<application android:usesCleartextTraffic="true" '
    'android:requestLegacyExternalStorage="true" android:banner="@drawable/banner"',
    1,
)
# Android TV launcher entry
s = re.sub(
    r'(<category android:name="android.intent.category.LAUNCHER"\s*/>)',
    r'\1\n                <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>',
    s, count=1,
)
services = """
        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback" android:exported="true">
            <intent-filter><action android:name="android.media.browse.MediaBrowserService"/></intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver" android:exported="true">
            <intent-filter><action android:name="android.intent.action.MEDIA_BUTTON"/></intent-filter>
        </receiver>
        <service android:name="com.pravera.flutter_foreground_task.service.ForegroundService"
            android:foregroundServiceType="dataSync" android:exported="false"/>
"""
s = s.replace("</application>", services + "    </application>", 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Achufy"', s, count=1)
open(mf, "w").write(s)

MAIN_KT = """package PKG

import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : AudioServiceActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "achufy/audio").setMethodCallHandler { call, result ->
            when (call.method) {
                "outputs" -> result.success(outputs())
                "isTv" -> result.success(isTv())
                "quit" -> {
                    OverlayHolder.overlay?.hide()
                    result.success(true)
                    finishAndRemoveTask()
                    Handler(Looper.getMainLooper()).postDelayed({
                        android.os.Process.killProcess(android.os.Process.myPid())
                    }, 500)
                }
                "openSwitcher" -> result.success(launch(
                    if (Build.VERSION.SDK_INT >= 29) "android.settings.panel.action.VOLUME"
                    else Settings.ACTION_BLUETOOTH_SETTINGS))
                "openBluetooth" -> result.success(launch(Settings.ACTION_BLUETOOTH_SETTINGS))
                else -> result.notImplemented()
            }
        }

        val overlayChannel = MethodChannel(messenger, "achufy/overlay")
        OverlayHolder.channel = overlayChannel
        overlayChannel.setMethodCallHandler { call, result ->
            when (call.method) {
                "show" -> {
                    val o = OverlayHolder.overlay
                        ?: LyricsOverlay(applicationContext).also { OverlayHolder.overlay = it }
                    if (!o.canShow()) {
                        try {
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + packageName)))
                        } catch (e: Exception) {
                        }
                        result.success(false)
                    } else {
                        result.success(o.show())
                    }
                }
                "update" -> {
                    OverlayHolder.overlay?.update(call.argument<String>("a") ?: "", call.argument<String>("b") ?: "")
                    result.success(true)
                }
                "hide" -> {
                    OverlayHolder.overlay?.hide()
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun isTv(): Boolean {
        val ui = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        return ui.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            !packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
    }

    private fun launch(action: String): Boolean {
        return try {
            startActivity(Intent(action))
            true
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                true
            } catch (e2: Exception) {
                false
            }
        }
    }

    private fun outputs(): Map<String, Any> {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val list = ArrayList<Map<String, String>>()
        val seen = HashSet<String>()
        for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            val kind: String = when (d.type) {
                AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "speaker"
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "bluetooth"
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "wired"
                AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "usb"
                AudioDeviceInfo.TYPE_HDMI -> "hdmi"
                else -> ""
            }
            if (kind.isEmpty()) continue
            val product = d.productName?.toString() ?: ""
            val name = if (kind == "speaker") "Phone speaker"
                else if (product.isNotBlank()) product else kind.replaceFirstChar { it.uppercase() }
            if (seen.add(kind + name)) list.add(mapOf("kind" to kind, "name" to name))
        }
        @Suppress("DEPRECATION")
        val active = if (am.isBluetoothA2dpOn) "bluetooth" else if (am.isWiredHeadsetOn) "wired" else "speaker"
        return mapOf("active" to active, "devices" to list)
    }
}
"""

OVERLAY_KT = """package PKG

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import io.flutter.plugin.common.MethodChannel

/** Keeps the overlay and Dart channel alive across activity restarts. */
object OverlayHolder {
    var overlay: LyricsOverlay? = null
    var channel: MethodChannel? = null
}

class LyricsOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var cur: TextView? = null
    private var nxt: TextView? = null

    fun canShow(): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    fun show(): Boolean {
        if (!canShow()) return false
        if (root != null) return true
        val dp = ctx.resources.displayMetrics.density
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding((18 * dp).toInt(), (12 * dp).toInt(), (18 * dp).toInt(), (12 * dp).toInt())
        val bg = GradientDrawable()
        bg.cornerRadius = 22 * dp
        bg.setColor(Color.parseColor("#E61E0D11"))
        bg.setStroke((1 * dp).toInt(), Color.parseColor("#66E5383B"))
        box.background = bg

        val close = TextView(ctx)
        close.text = "\u2715"
        close.setTextColor(Color.parseColor("#B3FFFFFF"))
        close.textSize = 16f
        close.setPadding((12 * dp).toInt(), (2 * dp).toInt(), (4 * dp).toInt(), (2 * dp).toInt())
        close.setOnClickListener {
            hide()
            OverlayHolder.channel?.invokeMethod("closed", null)
        }
        val closeLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        closeLp.gravity = Gravity.END
        box.addView(close, closeLp)

        val c = TextView(ctx)
        c.setTextColor(Color.WHITE)
        c.textSize = 18f
        c.gravity = Gravity.CENTER
        c.setTypeface(c.typeface, Typeface.BOLD)
        c.maxLines = 2
        val n = TextView(ctx)
        n.setTextColor(Color.parseColor("#99FFFFFF"))
        n.textSize = 14f
        n.gravity = Gravity.CENTER
        n.maxLines = 1
        box.addView(c)
        box.addView(n)

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            (ctx.resources.displayMetrics.widthPixels * 0.9).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = (120 * dp).toInt()

        var startY = 0
        var touchY = 0f
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = p.y
                    touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(box, p)
                    true
                }
                else -> false
            }
        }
        wm.addView(box, p)
        root = box
        cur = c
        nxt = n
        return true
    }

    fun update(a: String, b: String) {
        cur?.text = a
        nxt?.text = b
    }

    fun hide() {
        root?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        root = null
    }
}
"""

for f in glob.glob("android/app/src/main/**/MainActivity.*", recursive=True):
    src = open(f).read()
    pkg = re.search(r"package\s+([\w.]+)", src).group(1)
    if f.endswith(".kt"):
        open(f, "w").write(MAIN_KT.replace("PKG", pkg))
        open(os.path.join(os.path.dirname(f), "LyricsOverlay.kt"), "w").write(OVERLAY_KT.replace("PKG", pkg))
    else:
        raise SystemExit("Expected a Kotlin MainActivity")
print("patched")

# ---- launcher icons + TV banner ----
for d in glob.glob("tool/icons/mipmap-*"):
    dst = os.path.join("android/app/src/main/res", os.path.basename(d))
    os.makedirs(dst, exist_ok=True)
    for f in glob.glob(d + "/*.png"):
        shutil.copy(f, dst)
    for old in glob.glob(dst + "/ic_launcher.*"):
        if not old.endswith(".png"):
            os.remove(old)
os.makedirs("android/app/src/main/res/drawable-xhdpi", exist_ok=True)
shutil.copy("tool/banner.png", "android/app/src/main/res/drawable-xhdpi/banner.png")
print("branded")
