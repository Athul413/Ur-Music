// Achufy relay: forwards HTTP requests from players to your music server
// over a WebSocket that the server opens. Deploy on any Node host.
const http = require('http');
const { WebSocketServer } = require('ws');

const rooms = new Map(); // id -> { ws, pending: Map<reqId, res>, n }

const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  const m = u.pathname.match(/^\/r\/([A-Za-z0-9_-]+)(\/.*)?$/);
  if (!m) {
    res.writeHead(200, { 'content-type': 'text/plain' });
    return res.end('Achufy relay is running');
  }
  const room = rooms.get(m[1]);
  if (!room || room.ws.readyState !== 1) {
    res.writeHead(503, { 'content-type': 'text/plain' });
    return res.end('Your music server is offline');
  }
  const id = ++room.n;
  room.pending.set(id, res);
  room.ws.send(JSON.stringify({
    t: 'req', id, method: req.method,
    path: (m[2] || '/') + u.search,
    headers: { range: req.headers.range || '' },
  }));
  res.on('close', () => {
    if (room.pending.delete(id) && room.ws.readyState === 1) {
      room.ws.send(JSON.stringify({ t: 'cancel', id }));
    }
  });
});

const wss = new WebSocketServer({ noServer: true, maxPayload: 8 * 1024 * 1024 });

server.on('upgrade', (req, socket, head) => {
  const u = new URL(req.url, 'http://x');
  const id = u.searchParams.get('id');
  if (u.pathname !== '/connect' || !id || !/^[A-Za-z0-9_-]+$/.test(id)) {
    return socket.destroy();
  }
  wss.handleUpgrade(req, socket, head, (ws) => {
    const old = rooms.get(id);
    if (old) { try { old.ws.close(); } catch (e) {} }
    const room = { ws, pending: new Map(), n: 0 };
    rooms.set(id, room);
    ws.on('message', (data, isBinary) => {
      if (isBinary) {
        const rid = data.readUInt32BE(0);
        const r = room.pending.get(rid);
        if (r) r.write(data.subarray(4));
        return;
      }
      let m;
      try { m = JSON.parse(data.toString()); } catch (e) { return; }
      const r = room.pending.get(m.id);
      if (!r) return;
      if (m.t === 'res') {
        const headers = {};
        for (const k of Object.keys(m.headers || {})) {
          if (k.toLowerCase() !== 'transfer-encoding') headers[k] = m.headers[k];
        }
        r.writeHead(m.status, headers);
      } else if (m.t === 'end') {
        room.pending.delete(m.id);
        r.end();
      }
    });
    ws.on('close', () => {
      for (const r of room.pending.values()) { try { r.end(); } catch (e) {} }
      if (rooms.get(id) === room) rooms.delete(id);
    });
  });
});

const port = process.env.PORT || 3000;
server.listen(port, () => console.log('Achufy relay on port ' + port));
