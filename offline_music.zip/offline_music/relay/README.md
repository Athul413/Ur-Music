# Achufy relay
Lets the player reach your music server from anywhere.

Deploy for free (example: Render.com):
1. Push this `relay` folder to a GitHub repo (or keep it as a subfolder).
2. On Render: New > Web Service > connect the repo, set Root Directory to `relay`.
3. Build command: `npm install`   Start command: `npm start`
4. Copy the URL Render gives you (https://something.onrender.com).

Then in Achufy:
- Server phone: Internet mode > relay address, room ID, password > Start.
- Player: Connect > Internet > same relay address, room ID and password.
Free hosts sleep when idle; the first connection can take ~30 seconds.
