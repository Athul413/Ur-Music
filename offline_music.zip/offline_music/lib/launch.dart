import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_control.dart';
import 'client.dart';
import 'main.dart' show kAccent, kCard, Backdrop;
import 'now_playing.dart';
import 'permissions.dart';
import 'server.dart';
import 'vinyl.dart';

/// The front page: status, quick actions and permission check.
class LaunchPage extends StatefulWidget {
  const LaunchPage({super.key});
  @override
  State<LaunchPage> createState() => _LaunchPageState();
}

class _LaunchPageState extends State<LaunchPage> with WidgetsBindingObserver {
  String _server = '';
  String _mode = 'lan';
  int _count = 0;
  bool _localOn = false;
  bool _perm = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _checkPerm();
  }

  Future<void> _checkPerm() async {
    final ok = await hasStorage();
    if (mounted) setState(() => _perm = ok);
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _server = p.getString('server') ?? '';
      _mode = p.getString('conn_mode') ?? 'lan';
      _count = p.getInt('lib_count') ?? 0;
      _localOn = p.getBool('local_on') ?? false;
    });
    await _checkPerm();
    if (!(p.getBool('perm_asked') ?? false)) {
      await p.setBool('perm_asked', true);
      if (mounted && !_perm) await _askPermissions();
    }
  }

  Future<void> _askPermissions() async {
    final go = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        title: const Text('Allow access to your music'),
        content: const Text(
            'Achufy needs permission to:\n\n'
            '\u2022 read the music files on this phone\n'
            '\u2022 show the playback notification\n\n'
            'Nothing leaves your devices unless you turn on internet access.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Not now')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Allow', style: TextStyle(color: kAccent))),
        ],
      ),
    );
    if (go == true && mounted) {
      await ensureStorage(context);
      await _checkPerm();
    }
  }

  Future<void> _open([String? action]) async {
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => ClientPage(startAction: action)));
    _load();
  }

  String _greeting() {
    final h = DateTime.now().hour;
    return h < 12 ? 'Good morning' : (h < 18 ? 'Good afternoon' : 'Good evening');
  }

  Future<void> _more() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: kCard,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const ListTile(
              title: Text('More', style: TextStyle(fontWeight: FontWeight.w800))),
          ListTile(
              leading: const Icon(Icons.dns_outlined),
              title: const Text("Share this phone's music"),
              subtitle: const Text('Turn this phone into a music server'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ServerPage()));
              }),
          ListTile(
              leading: const Icon(Icons.album),
              title: const Text('Player style'),
              onTap: () {
                Navigator.pop(context);
                pickPlayerStyle(context);
              }),
          ListTile(
              leading: const Icon(Icons.lock_open),
              title: const Text('Permissions'),
              onTap: () async {
                Navigator.pop(context);
                await ensureStorage(context);
                _checkPerm();
              }),
          ListTile(
              leading: const Icon(Icons.power_settings_new, color: kAccent),
              title: const Text('Quit Achufy'),
              onTap: () {
                Navigator.pop(context);
                confirmQuit(context);
              }),
        ]),
      ),
    );
  }

  Widget _tile(IconData icon, String title, String sub, VoidCallback onTap) =>
      InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: Colors.white.withAlpha(14),
            border: Border.all(color: Colors.white.withAlpha(20)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  shape: BoxShape.circle, color: kAccent.withAlpha(60)),
              child: Icon(icon, color: Colors.white, size: 22),
            ),
            const Spacer(),
            Text(title,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 2),
            Text(sub,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white54, fontSize: 12)),
          ]),
        ),
      );

  Widget _status() {
    final connected = _server.isNotEmpty;
    final text = connected
        ? '${_mode == 'lan' ? _server.replaceFirst('http://', '') : modeLabel(_mode)}'
            '${_count > 0 ? '  -  $_count songs' : ''}'
        : (_localOn ? 'Playing from this phone' : 'Not connected yet');
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 9,
        height: 9,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: (connected || _localOn) ? Colors.greenAccent : Colors.orangeAccent),
      ),
      const SizedBox(width: 8),
      Flexible(
          child: Text(text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white70, fontSize: 13))),
    ]);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: Backdrop(
          child: SafeArea(
            child: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 20), children: [
              Row(children: [
                ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset('assets/logo.png', width: 42, height: 42)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(_greeting(),
                        style: const TextStyle(color: Colors.white54, fontSize: 12)),
                    const Text('Achufy',
                        style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 2)),
                  ]),
                ),
                IconButton(icon: const Icon(Icons.more_horiz), onPressed: _more),
              ]),
              const SizedBox(height: 18),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(32),
                  gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFFC1272D), Color(0xFF3A0A10)]),
                  boxShadow: [
                    BoxShadow(
                        color: kAccent.withAlpha(70),
                        blurRadius: 36,
                        offset: const Offset(0, 14))
                  ],
                ),
                child: Column(children: [
                  Row(children: [
                    const VinylDisc(size: 118, alwaysSpin: true),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('READY TO PLAY',
                            style: TextStyle(
                                fontSize: 11, letterSpacing: 2, color: Colors.white70)),
                        const SizedBox(height: 6),
                        const Text('Your music,\nyour way',
                            style: TextStyle(
                                fontSize: 24, fontWeight: FontWeight.w900, height: 1.1)),
                        const SizedBox(height: 10),
                        _status(),
                      ]),
                    ),
                  ]),
                  const SizedBox(height: 18),
                  Row(children: [
                    Expanded(
                      child: FilledButton.icon(
                        autofocus: true,
                        style: FilledButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: Colors.black,
                            shape: const StadiumBorder(),
                            padding: const EdgeInsets.symmetric(vertical: 14)),
                        icon: const Icon(Icons.library_music),
                        label: const Text('Open library',
                            style: TextStyle(fontWeight: FontWeight.w800)),
                        onPressed: () => _open(),
                      ),
                    ),
                  ]),
                ]),
              ),
              if (!_perm) ...[
                const SizedBox(height: 14),
                InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: _askPermissions,
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: Colors.orange.withAlpha(30),
                        border: Border.all(color: Colors.orangeAccent.withAlpha(120))),
                    child: const Row(children: [
                      Icon(Icons.lock_outline, color: Colors.orangeAccent),
                      SizedBox(width: 12),
                      Expanded(
                          child: Text(
                              'Allow access to your music files so Achufy can find your songs. Tap to allow.',
                              style: TextStyle(fontSize: 13))),
                    ]),
                  ),
                ),
              ],
              StreamBuilder<SequenceState?>(
                stream: player.sequenceStateStream,
                builder: (_, snap) {
                  final tag = snap.data?.currentSource?.tag;
                  if (tag is! MediaItem) return const SizedBox.shrink();
                  return Padding(
                    padding: const EdgeInsets.only(top: 14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              fullscreenDialog: true,
                              builder: (_) => const NowPlayingPage())),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: kCard,
                            border: Border.all(color: kAccent.withAlpha(70))),
                        child: Row(children: [
                          VinylDisc(url: tag.artUri?.toString(), size: 48),
                          const SizedBox(width: 12),
                          Expanded(
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                const Text('NOW PLAYING',
                                    style: TextStyle(
                                        fontSize: 10, letterSpacing: 1.5, color: kAccent)),
                                Text(tag.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontWeight: FontWeight.w800)),
                                Text(tag.artist ?? '',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        color: Colors.white54, fontSize: 12)),
                              ])),
                          StreamBuilder<bool>(
                            stream: player.playingStream,
                            builder: (_, s) => IconButton(
                              icon: Icon(s.data == true ? Icons.pause : Icons.play_arrow),
                              onPressed: s.data == true ? player.pause : player.play,
                            ),
                          ),
                        ]),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 22),
              const Text('Get started',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.25,
                children: [
                  _tile(Icons.wifi_find, 'Find my server', 'Auto-detect on Wi-Fi',
                      () => _open('find')),
                  _tile(Icons.phone_android, 'This phone', 'Play files stored here',
                      () => _open('local')),
                  _tile(Icons.public, 'From anywhere', 'Tailscale, tunnel, relay',
                      () => _open('connect')),
                  _tile(Icons.album, 'Player style', 'Cover, vinyl, turntable',
                      () => pickPlayerStyle(context)),
                ],
              ),
              const SizedBox(height: 22),
              const Wrap(spacing: 8, runSpacing: 8, children: [
                _Chip(Icons.lyrics, 'Synced lyrics'),
                _Chip(Icons.picture_in_picture_alt, 'Floating lyrics'),
                _Chip(Icons.tv, 'Android TV'),
                _Chip(Icons.wifi_off, 'Works offline'),
              ]),
            ]),
          ),
        ),
      );
}

class _Chip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _Chip(this.icon, this.label);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.white.withAlpha(12)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 15, color: kAccent),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70)),
        ]),
      );
}
