import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'main.dart' show kAccent, kCard;

/// True if Achufy can read music files (any of the storage permissions).
Future<bool> hasStorage() async =>
    await Permission.manageExternalStorage.isGranted ||
    await Permission.audio.isGranted ||
    await Permission.storage.isGranted;

Future<bool> hasNotifications() => Permission.notification.isGranted;

/// Asks for music access (and notifications). Shows a helpful dialog that
/// opens app settings if the user has blocked the permission.
Future<bool> ensureStorage(BuildContext context) async {
  if (await hasStorage()) {
    await Permission.notification.request();
    return true;
  }
  await [Permission.storage, Permission.audio].request();
  if (!await Permission.manageExternalStorage.isGranted) {
    // Opens Android's "All files access" screen.
    await Permission.manageExternalStorage.request();
  }
  await Permission.notification.request();
  final ok = await hasStorage();
  if (!ok && context.mounted) {
    final open = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        title: const Text('Music access needed'),
        content: const Text(
            'Achufy needs permission to read your music files.\n\n'
            'Open settings, tap Permissions, and allow "Music and audio" '
            'or "All files access".'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Not now')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Open settings', style: TextStyle(color: kAccent))),
        ],
      ),
    );
    if (open == true) await openAppSettings();
  }
  return ok;
}
