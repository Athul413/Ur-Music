import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'client.dart' show player;
import 'main.dart' show kAccent, kCard;
import 'overlay.dart';
import 'server.dart' show musicServer;

/// Fully closes Achufy: music, floating lyrics, server, notifications.
Future<void> quitApp() async {
  try {
    await FloatingLyrics.stop();
  } catch (_) {}
  try {
    await player.stop();
  } catch (_) {}
  try {
    await musicServer.stop();
  } catch (_) {}
  try {
    await FlutterForegroundTask.stopService();
  } catch (_) {}
  await Future.delayed(Duration(milliseconds: 300));
  try {
    await MethodChannel('achufy/audio').invokeMethod('quit');
  } catch (_) {
    SystemNavigator.pop();
  }
}

Future<void> confirmQuit(BuildContext context) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      backgroundColor: kCard,
      title: Text('Quit Achufy?'),
      content: Text(
          'This stops the music, the floating lyrics and the server, and closes the app completely.'),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel')),
        TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Quit', style: TextStyle(color: kAccent))),
      ],
    ),
  );
  if (ok == true) await quitApp();
}
