import 'dart:math' as m;
import 'package:flutter/material.dart';
import 'fx.dart';
import 'main.dart' show kAccent;

const vizNames = ['Bars', 'Mirror', 'Circle', 'Wave', 'Dots'];

/// Real-time audio spectrum.
class VizView extends StatefulWidget {
  final double height;
  final int? style;
  VizView({super.key, this.height = 180, this.style});
  @override
  State<VizView> createState() => _VizViewState();
}

class _VizViewState extends State<VizView> {
  bool _ok = true;

  @override
  void initState() {
    super.initState();
    AudioFx.I.acquireViz().then((ok) {
      if (mounted) setState(() => _ok = ok);
    });
  }

  @override
  void dispose() {
    AudioFx.I.releaseViz();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ok) {
      return SizedBox(
        height: widget.height,
        child: Center(
            child: Padding(
          padding: EdgeInsets.all(16),
          child: Text(
              'The visualizer needs the microphone permission (Android requires it to read the audio spectrum). Allow it in Settings > Apps > Achufy.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60)),
        )),
      );
    }
    return ListenableBuilder(
      listenable: AudioFx.I,
      builder: (_, __) => ValueListenableBuilder<List<double>>(
        valueListenable: AudioFx.I.fft,
        builder: (_, v, __) => SizedBox(
          height: widget.height,
          width: double.infinity,
          child: CustomPaint(
              painter: _VizPainter(v, widget.style ?? AudioFx.I.vizStyle, kAccent)),
        ),
      ),
    );
  }
}

class _VizPainter extends CustomPainter {
  final List<double> v;
  final int style;
  final Color color;
  _VizPainter(this.v, this.style, this.color);

  @override
  void paint(Canvas canvas, Size s) {
    final n = v.length;
    if (n == 0) return;
    final paint = Paint()
      ..color = color
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.fill;
    final w = s.width / n;
    double h(int i) => v[i].clamp(0.0, 1.0);
    switch (style) {
      case 1:
        for (var i = 0; i < n; i++) {
          final bh = h(i) * s.height * 0.5 + 2;
          canvas.drawRRect(
              RRect.fromRectAndRadius(
                  Rect.fromCenter(
                      center: Offset(w * i + w / 2, s.height / 2),
                      width: w * 0.6,
                      height: bh * 2),
                  Radius.circular(w)),
              paint);
        }
        break;
      case 2:
        final c = Offset(s.width / 2, s.height / 2);
        final r = m.min(s.width, s.height) * 0.22;
        paint
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3;
        for (var i = 0; i < n; i++) {
          final a = i / n * 2 * m.pi - m.pi / 2;
          final len = h(i) * m.min(s.width, s.height) * 0.28 + 3;
          canvas.drawLine(c + Offset(m.cos(a), m.sin(a)) * r,
              c + Offset(m.cos(a), m.sin(a)) * (r + len), paint);
        }
        break;
      case 3:
        final path = Path();
        for (var i = 0; i < n; i++) {
          final x = w * i + w / 2;
          final y = s.height / 2 - (h(i) - 0.15) * s.height * 0.8 * (i.isEven ? 1 : -1) * 0.6;
          i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
        }
        paint
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3;
        canvas.drawPath(path, paint);
        break;
      case 4:
        for (var i = 0; i < n; i++) {
          final dots = (h(i) * 10).round() + 1;
          for (var d = 0; d < dots; d++) {
            canvas.drawCircle(
                Offset(w * i + w / 2, s.height - 6 - d * (s.height / 12)),
                w * 0.28, paint);
          }
        }
        break;
      default:
        for (var i = 0; i < n; i++) {
          final bh = h(i) * s.height + 2;
          canvas.drawRRect(
              RRect.fromRectAndRadius(
                  Rect.fromLTWH(w * i + w * 0.15, s.height - bh, w * 0.7, bh),
                  Radius.circular(w * 0.3)),
              paint);
        }
    }
  }

  @override
  bool shouldRepaint(covariant _VizPainter old) => true;
}
