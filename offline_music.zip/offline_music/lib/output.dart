import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'main.dart' show kAccent, kCard, toast;

const _ch = MethodChannel('achufy/audio');

IconData _icon(String kind) {
  switch (kind) {
    case 'bluetooth':
      return Icons.bluetooth_audio;
    case 'wired':
      return Icons.headphones;
    case 'usb':
      return Icons.usb;
    case 'hdmi':
      return Icons.tv;
    default:
      return Icons.speaker_phone;
  }
}

Future<void> _open(String method) async {
  try {
    final ok = await _ch.invokeMethod<bool>(method);
    if (ok != true) toast("Couldn't open that screen on this phone.");
  } catch (_) {
    toast("Couldn't open that screen on this phone.");
  }
}

/// Shows where sound is going and opens Android's output switcher.
Future<void> showOutputSheet(BuildContext context) async {
  var active = 'speaker';
  var devices = <Map<String, String>>[];
  try {
    final r = await _ch.invokeMethod<Map>('outputs');
    if (r != null) {
      active = '${r['active']}';
      devices = (r['devices'] as List)
          .map((d) => {'kind': '${(d as Map)['kind']}', 'name': '${d['name']}'})
          .toList();
    }
  } catch (_) {}
  if (devices.isEmpty) {
    devices = [
      {'kind': 'speaker', 'name': 'Phone speaker'}
    ];
  }
  if (!context.mounted) return;
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: kCard,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (_) => SafeArea(
      child: ListView(shrinkWrap: true, children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, 4),
          child: Text('Play on',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: Text(
              'Android chooses where sound goes. Tap a device, then pick it in the switcher.',
              style: TextStyle(color: Colors.white60, fontSize: 12)),
        ),
        for (final d in devices)
          ListTile(
            leading: Icon(_icon(d['kind']!),
                color: d['kind'] == active ? kAccent : Colors.white70),
            title: Text(d['name']!,
                style: TextStyle(
                    color: d['kind'] == active ? kAccent : Colors.white,
                    fontWeight: FontWeight.w700)),
            subtitle: d['kind'] == active
                ? const Text('Playing here', style: TextStyle(color: kAccent))
                : null,
            onTap: () {
              Navigator.pop(context);
              _open('openSwitcher');
            },
          ),
        const Divider(color: Colors.white12),
        ListTile(
          leading: const Icon(Icons.tune),
          title: const Text('Open sound output switcher'),
          onTap: () {
            Navigator.pop(context);
            _open('openSwitcher');
          },
        ),
        ListTile(
          leading: const Icon(Icons.bluetooth),
          title: const Text('Connect a Bluetooth device'),
          onTap: () {
            Navigator.pop(context);
            _open('openBluetooth');
          },
        ),
        const SizedBox(height: 8),
      ]),
    ),
  );
}
