import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'client.dart';
import 'engine.dart';
import 'fx.dart';
import 'main.dart' show Backdrop, kAccent, kCard, isTv, playerStyle;
import 'stats.dart';
import 'viz.dart';

/// Audio control centre: equalizer, effects, visualizer and audio info.
class StudioPage extends StatelessWidget {
  StudioPage({super.key});
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 4,
        child: Backdrop(
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              title: Text('Studio'),
              bottom: TabBar(
                indicatorColor: kAccent,
                tabs: [
                  Tab(text: 'Equalizer'),
                  Tab(text: 'Effects'),
                  Tab(text: 'Visualizer'),
                  Tab(text: 'Info'),
                ],
              ),
            ),
            body: TabBarView(children: [_EqTab(), _EffectsTab(), _VizTab(), _InfoTab()]),
          ),
        ),
      );
}

class _EqTab extends StatelessWidget {
  _EqTab();
  @override
  Widget build(BuildContext context) {
    final fx = AudioFx.I;
    return ListenableBuilder(
      listenable: fx,
      builder: (_, __) => ListView(padding: EdgeInsets.all(16), children: [
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          activeColor: kAccent,
          title: Text('Equalizer'),
          subtitle: Text(fx.available
              ? '10 sliders mapped onto your device\'s ${fx.bands} hardware bands'
              : 'Start a song first - the equalizer attaches to the playing audio'),
          value: fx.eqOn,
          onChanged: fx.setEqOn,
        ),
        Wrap(spacing: 8, runSpacing: 4, children: [
          for (final n in [...kPresets.keys, 'Custom'])
            ChoiceChip(
              label: Text(n),
              selected: fx.preset == n,
              showCheckmark: false,
              selectedColor: kAccent,
              onSelected: (_) => fx.setPreset(n),
            ),
        ]),
        SizedBox(height: 12),
        if (isTv)
          for (var i = 0; i < 10; i++)
            Row(children: [
              SizedBox(width: 56, child: Text('${kBandLabels[i]} Hz', style: TextStyle(fontSize: 12))),
              Expanded(
                child: Slider(
                    min: -12, max: 12, divisions: 48,
                    value: fx.gains[i],
                    onChanged: (v) => fx.setGain(i, v)),
              ),
              SizedBox(width: 44, child: Text('${fx.gains[i].toStringAsFixed(0)} dB', style: TextStyle(fontSize: 12))),
            ])
        else
          SizedBox(
            height: 260,
            child: Row(children: [
              for (var i = 0; i < 10; i++)
                Expanded(
                  child: Column(children: [
                    Text(fx.gains[i].toStringAsFixed(0), style: TextStyle(fontSize: 10, color: Colors.white60)),
                    Expanded(
                      child: RotatedBox(
                        quarterTurns: 3,
                        child: Slider(
                            min: -12, max: 12, divisions: 48,
                            value: fx.gains[i],
                            onChanged: (v) => fx.setGain(i, v)),
                      ),
                    ),
                    Text(kBandLabels[i], style: TextStyle(fontSize: 11)),
                  ]),
                ),
            ]),
          ),
        SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          activeColor: kAccent,
          title: Text('Save for this song only'),
          subtitle: Text(fx.songId == null
              ? 'Play a song to use per-song profiles'
              : (fx.hasSongProfile
                  ? 'This song has its own EQ, bass and virtualizer'
                  : 'Off - this song uses your global settings')),
          value: fx.hasSongProfile,
          onChanged: fx.songId == null ? null : fx.toggleSongProfile,
        ),
        TextButton(onPressed: () => fx.setPreset('Flat'), child: Text('Reset to flat')),
      ]),
    );
  }
}

class _EffectsTab extends StatelessWidget {
  _EffectsTab();
  @override
  Widget build(BuildContext context) {
    final fx = AudioFx.I;
    final en = PlaybackEngine.I;
    return ListenableBuilder(
      listenable: fx,
      builder: (_, __) => ListView(padding: EdgeInsets.all(16), children: [
        _head(Icons.graphic_eq, 'Bass enhancement', fx.bassOk ? null : 'Not supported on this device'),
        Slider(value: fx.bass, onChanged: fx.bassOk ? fx.setBass : null),
        _head(Icons.surround_sound, 'Virtualizer (spatial audio)',
            fx.virtOk ? null : 'Not supported on this device'),
        Slider(value: fx.virt, onChanged: fx.virtOk ? fx.setVirt : null),
        Divider(color: Colors.white12),
        StatefulBuilder(
          builder: (_, set) => Column(children: [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              activeColor: kAccent,
              secondary: Icon(Icons.volume_up),
              title: Text('ReplayGain'),
              subtitle: Text('Evens out loudness using the volume tags in your files'),
              value: en.replayGain,
              onChanged: (v) {
                en.setReplayGain(v);
                set(() {});
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.blur_linear),
              title: Text(en.fadeSec <= 0
                  ? 'Fade between tracks: off'
                  : 'Fade between tracks: ${en.fadeSec.toStringAsFixed(0)} s'),
              subtitle: Slider(
                min: 0,
                max: 10,
                divisions: 10,
                value: en.fadeSec,
                onChanged: (v) {
                  en.setFade(v);
                  set(() {});
                },
              ),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.all_inclusive),
              title: Text('Gapless playback'),
              subtitle: Text('Always on - the next song is prepared before the current one ends'),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              activeColor: kAccent,
              secondary: Icon(Icons.mic_external_off),
              title: Text('Vocal reducer (karaoke)'),
              subtitle: Text('Cuts the vocal frequencies - reduces singing, does not remove it'),
              value: fx.karaoke,
              onChanged: (v) {
                fx.setKaraoke(v);
                set(() {});
              },
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _head(IconData i, String t, String? warn) => Padding(
        padding: EdgeInsets.only(top: 8),
        child: Row(children: [
          Icon(i, color: kAccent),
          SizedBox(width: 10),
          Text(t, style: TextStyle(fontWeight: FontWeight.w700)),
          if (warn != null) ...[
            SizedBox(width: 8),
            Text(warn, style: TextStyle(color: Colors.orangeAccent, fontSize: 12)),
          ],
        ]),
      );
}

class _VizTab extends StatelessWidget {
  _VizTab();
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: AudioFx.I,
        builder: (_, __) => ListView(padding: EdgeInsets.all(16), children: [
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(22)),
            child: VizView(height: 220),
          ),
          SizedBox(height: 14),
          Wrap(spacing: 8, children: [
            for (var i = 0; i < vizNames.length; i++)
              ChoiceChip(
                label: Text(vizNames[i]),
                selected: AudioFx.I.vizStyle == i,
                showCheckmark: false,
                selectedColor: kAccent,
                onSelected: (_) => AudioFx.I.setVizStyle(i),
              ),
          ]),
          SizedBox(height: 10),
          Text('Play a song to see the spectrum move.',
              style: TextStyle(color: Colors.white54, fontSize: 12)),
        ]),
      );
}

class _InfoTab extends StatelessWidget {
  _InfoTab();
  @override
  Widget build(BuildContext context) => StreamBuilder<SequenceState?>(
        stream: player.sequenceStateStream,
        builder: (_, snap) {
          final src = snap.data?.currentSource;
          final tag = src?.tag;
          if (tag is! MediaItem || src is! UriAudioSource) {
            return Center(child: Text('Play a song to see its details'));
          }
          final song = libraryById[int.tryParse(tag.id)];
          return FutureBuilder<Map<String, dynamic>?>(
            future: AudioFx.I.audioInfo(src.uri.toString()),
            builder: (_, f) {
              final i = f.data ?? {};
              String v(Object? x, [String suffix = '']) =>
                  x == null || '$x'.isEmpty ? '-' : '$x$suffix';
              final br = (i['bitrate'] ?? i['bitrateFmt']);
              final rows = <List<String>>[
                ['Title', tag.title],
                ['Artist', tag.artist ?? '-'],
                ['Codec', v(i['codec'])],
                ['Bitrate', br is num ? '${(br / 1000).round()} kbps' : '-'],
                ['Sample rate', i['sampleRate'] is num ? '${i['sampleRate']} Hz' : '-'],
                ['Channels', v(i['channels'])],
                ['Genre', v(song?.genre ?? i['genre'])],
                ['Year', v(i['year'])],
                ['Mood', song == null ? '-' : moodOf(song)],
                ['ReplayGain', tag.extras?['gain'] is num ? '${(tag.extras!['gain'] as num).toStringAsFixed(1)} dB' : 'no tag'],
                ['File size', song?.size == null ? '-' : '${(song!.size! / 1048576).toStringAsFixed(1)} MB'],
                ['Source', song?.isLocal == true ? 'This phone' : 'Server'],
              ];
              return ListView(padding: EdgeInsets.all(16), children: [
                if (f.connectionState != ConnectionState.done)
                  LinearProgressIndicator(color: kAccent),
                for (final r in rows)
                  ListTile(
                    dense: true,
                    title: Text(r[0], style: TextStyle(color: Colors.white60)),
                    trailing: Text(r[1], style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
              ]);
            },
          );
        },
      );
}
