import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_control.dart';
import 'connect.dart';
import 'discovery.dart';
import 'local.dart';
import 'main.dart' show Backdrop, currentId, isTv, kAccent, kBg, kCard, kHeroA, kHeroB, playerStyle, toast;
import 'now_playing.dart';
import 'output.dart';
import 'customize.dart';
import 'engine.dart';
import 'fx.dart';
import 'insights.dart';
import 'karaoke.dart';
import 'lyricstudio.dart';
import 'overlay.dart';
import 'party.dart';
import 'stats.dart';
import 'studio.dart';
import 'permissions.dart';
import 'server.dart' show ServerPage;
import 'vinyl.dart';

final player = AudioPlayer();
String base = '';
String token = '';

/// Builds a server URL (adds the password when one is set).
String url(String path) =>
    '$base$path${token.isEmpty ? '' : '?k=${Uri.encodeQueryComponent(token)}'}';

void setPlayerStyle(int v) {
  playerStyle.value = v;
  store.prefs?.setInt('player_style', v);
}

String modeLabel(String m) {
  switch (m) {
    case 'tailscale':
      return 'Tailscale';
    case 'tunnel':
      return 'Web tunnel';
    case 'direct':
      return 'Direct IP';
    case 'internet':
      return 'Achufy relay';
    default:
      return 'Wi-Fi';
  }
}

Future<void> pickPlayerStyle(BuildContext context) async {
  final v = await showDialog<int>(
    context: context,
    builder: (_) => SimpleDialog(
      backgroundColor: kCard,
      title: Text('Player style'),
      children: [
        for (final e in [
          [0, 'Album cover'],
          [1, 'Vinyl disc (spins)'],
          [2, 'Turntable with tonearm'],
          [3, 'Animated artwork (pulses with bass)'],
        ])
          SimpleDialogOption(
            onPressed: () => Navigator.pop(context, e[0] as int),
            child: Text('${e[1]}',
                style: TextStyle(
                    fontSize: 16,
                    color: playerStyle.value == e[0] ? kAccent : Colors.white,
                    fontWeight:
                        playerStyle.value == e[0] ? FontWeight.w800 : FontWeight.w400)),
          ),
      ],
    ),
  );
  if (v != null) setPlayerStyle(v);
}

class Song {
  final int id;
  final String title, artist, album;
  final bool cover;
  final String? localPath, localCover, genre;
  final int? year, dur, size;
  final double? rg; // ReplayGain track gain (dB)
  Song(this.id, this.title, this.artist, this.album, this.cover,
      {this.localPath,
      this.localCover,
      String? genre,
      this.year,
      this.dur,
      this.size,
      this.rg})
      : genre = (genre == null || genre.trim().isEmpty) ? null : genre.trim();
  factory Song.fromJson(Map<String, dynamic> j) => Song(
      (j['id'] as num).toInt(),
      '${j['title']}',
      '${j['artist']}',
      '${j['album']}',
      j['cover'] == true,
      genre: j['genre']?.toString(),
      year: (j['year'] as num?)?.toInt(),
      dur: (j['dur'] as num?)?.toInt(),
      size: (j['size'] as num?)?.toInt(),
      rg: ((j['rg'] ?? j['gain']) as num?)?.toDouble());
  double? get gain => rg;
  bool get isLocal => localPath != null;
  String? get coverUrl =>
      isLocal ? localCover : (cover ? url('/cover/$id') : null);
}

/// Every visible song (server + this phone), for intelligence features.
List<Song> libraryAll = [];
final Map<int, Song> libraryById = {};

Song? currentSong() {
  final id = int.tryParse(currentId.value ?? '');
  return id == null ? null : libraryById[id];
}

void publishLibrary() {
  libraryAll = [..._serverCache, ..._localCache]
      .where((s) => !stats.hidden.contains(s.id))
      .toList();
  libraryById
    ..clear()
    ..addAll({for (final s in [..._serverCache, ..._localCache]) s.id: s});
}

List<Song> _serverCache = [];
List<Song> _localCache = [];

class Album {
  final String title, artist;
  final List<Song> songs;
  Album(this.title, this.artist, this.songs);
  String? get coverUrl {
    for (final s in songs) {
      if (s.cover) return s.coverUrl;
    }
    return null;
  }
}

/// Playlists + liked songs, saved on this phone.
class Store extends ChangeNotifier {
  SharedPreferences? prefs;
  Map<String, List<int>> playlists = {};
  static const likedName = 'Liked Songs';

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    final raw = prefs!.getString('playlists_v2');
    if (raw != null) {
      playlists = (jsonDecode(raw) as Map<String, dynamic>)
          .map((k, v) => MapEntry(k, List<int>.from(v)));
    }
    base = prefs!.getString('server') ?? '';
    token = prefs!.getString('token') ?? '';
    notifyListeners();
  }

  void _save() {
    prefs?.setString('playlists_v2', jsonEncode(playlists));
    notifyListeners();
  }

  bool liked(int id) => playlists[likedName]?.contains(id) ?? false;
  void toggleLike(int id) {
    final l = playlists.putIfAbsent(likedName, () => []);
    l.contains(id) ? l.remove(id) : l.add(id);
    _save();
  }

  void add(String name, int id) {
    final l = playlists.putIfAbsent(name, () => []);
    if (!l.contains(id)) l.add(id);
    _save();
  }

  void remove(String name) {
    playlists.remove(name);
    _save();
  }

  void createPlaylist(String name) {
    playlists.putIfAbsent(name, () => []);
    _save();
  }
}

final store = Store();

ConcatenatingAudioSource buildSource(List<Song> list) => ConcatenatingAudioSource(
      children: list.map((s) {
        final ex = <String, dynamic>{
          if (s.isLocal) 'path': s.localPath,
          if (s.gain != null) 'gain': s.gain,
        };
        return AudioSource.uri(
          s.isLocal ? Uri.file(s.localPath!) : Uri.parse(url('/stream/${s.id}')),
          tag: MediaItem(
            id: '${s.id}',
            title: s.title,
            artist: s.artist,
            album: s.album,
            extras: ex.isEmpty ? null : ex,
            artUri: s.coverUrl == null
                ? null
                : (s.isLocal ? Uri.file(s.coverUrl!) : Uri.parse(s.coverUrl!)),
          ),
        );
      }).toList(),
    );

Future<void> playSongs(List<Song> list, int index, {bool shuffle = false}) async {
  if (list.isEmpty) return;
  if (list.any((s) => !s.isLocal) && base.isEmpty) {
    toast('Connect to a server first.');
    return;
  }
  if (PartyClient.I.connected) {
    final server = list.where((s) => !s.isLocal).toList();
    if (server.isEmpty) {
      toast('Party mode plays songs from the server library.');
      return;
    }
    final i = list[index].isLocal ? 0 : server.indexWhere((s) => s.id == list[index].id);
    PartyClient.I.setQueue(shuffle ? (server.toList()..shuffle()) : server, shuffle ? 0 : (i < 0 ? 0 : i));
    toast('Playing for everyone in the party');
    return;
  }
  try {
    PlaybackEngine.I.queueIds = list.map((s) => s.id).toList();
    await player.setAudioSource(buildSource(list), initialIndex: index);
    await player.setShuffleModeEnabled(shuffle);
    if (shuffle) await player.shuffle();
    player.play();
  } on PlayerException catch (e) {
    toast("Can't play this track: ${e.message ?? 'unknown error'}");
  } catch (e) {
    toast("Can't start playback. Is the server reachable?");
  }
}

// Transport controls that also work in party mode.
Future<void> doPlay() async =>
    PartyClient.I.connected ? PartyClient.I.ctl('play') : await player.play();
Future<void> doPause() async =>
    PartyClient.I.connected ? PartyClient.I.ctl('pause') : await player.pause();
Future<void> doNext() async =>
    PartyClient.I.connected ? PartyClient.I.ctl('next') : await player.seekToNext();
Future<void> doPrev() async =>
    PartyClient.I.connected ? PartyClient.I.ctl('prev') : await player.seekToPrevious();
Future<void> doSeek(Duration d) async => PartyClient.I.connected
    ? PartyClient.I.ctl('seek', pos: d.inMilliseconds)
    : await player.seek(d);

class CoverArt extends StatelessWidget {
  final String? url;
  final double? size;
  final double radius;
  CoverArt({super.key, this.url, this.size, this.radius = 6});

  Widget _placeholder() => Container(
        color: kCard,
        child: Icon(Icons.music_note,
            color: Colors.white38, size: (size ?? 80) * 0.45),
      );

  @override
  Widget build(BuildContext context) {
    final u = url;
    Widget img;
    if (u == null) {
      img = _placeholder();
    } else if (u.startsWith('/') || u.startsWith('file:')) {
      final path = u.startsWith('file:') ? Uri.parse(u).toFilePath() : u;
      img = Image.file(File(path),
          fit: BoxFit.cover,
          cacheWidth: 500,
          errorBuilder: (_, __, ___) => _placeholder());
    } else {
      img = Image.network(u,
          fit: BoxFit.cover,
          cacheWidth: 500,
          errorBuilder: (_, __, ___) => _placeholder());
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: size == null
          ? SizedBox.expand(child: img)
          : SizedBox(width: size, height: size, child: img),
    );
  }
}

Future<void> addToPlaylistSheet(BuildContext context, Song s) async {
  final choice = await showModalBottomSheet<String>(
    context: context,
    backgroundColor: kCard,
    builder: (_) => SafeArea(
      child: ListView(shrinkWrap: true, children: [
        ListTile(
            leading: CoverArt(url: s.coverUrl, size: 44),
            title: Text(s.title, maxLines: 1),
            subtitle: Text(s.artist, maxLines: 1)),
        Divider(),
        ListTile(
            leading: Icon(Icons.add),
            title: Text('New playlist'),
            onTap: () => Navigator.pop(context, '\u0000new')),
        for (final n in store.playlists.keys)
          ListTile(
              leading: Icon(Icons.queue_music),
              title: Text(n),
              onTap: () => Navigator.pop(context, n)),
      ]),
    ),
  );
  if (choice == null || !context.mounted) return;
  var target = choice;
  if (choice == '\u0000new') {
    final n = await askText(context, 'Playlist name', 'Create');
    if (n == null || n.isEmpty) return;
    target = n;
  }
  store.add(target, s.id);
}

Future<String?> askText(BuildContext context, String title, String ok,
    {String initial = '', String? hint}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(
          controller: c,
          autofocus: true,
          decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context, c.text.trim()),
            child: Text(ok)),
      ],
    ),
  );
}

class SongTile extends StatelessWidget {
  final Song song;
  final VoidCallback onTap;
  SongTile({super.key, required this.song, required this.onTap});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String?>(
        valueListenable: currentId,
        builder: (_, cur, __) {
          final on = cur == '${song.id}';
          return ListTile(
            leading: CoverArt(url: song.coverUrl, size: 50, radius: 10),
            title: Text(song.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: on ? kAccent : Colors.white,
                    fontWeight: on ? FontWeight.w800 : FontWeight.w500)),
            subtitle: Row(children: [
              if (song.isLocal)
                Padding(
                    padding: EdgeInsets.only(right: 4),
                    child: Icon(Icons.phone_android, size: 13, color: Colors.white54)),
              Expanded(
                  child: Text(song.artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.white60))),
            ]),
            trailing: IconButton(
                icon: Icon(Icons.more_vert, color: Colors.white60),
                onPressed: () => addToPlaylistSheet(context, song)),
            onTap: onTap,
          );
        },
      );
}

class SongListPage extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? coverUrl;
  final List<Song> songs;
  SongListPage(
      {super.key,
      required this.title,
      required this.songs,
      this.subtitle,
      this.coverUrl});

  @override
  Widget build(BuildContext context) => Backdrop(
          child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(backgroundColor: Colors.transparent),
        body: ListView(children: [
          Center(
              child: Padding(
                  padding: EdgeInsets.all(8),
                  child: CoverArt(url: coverUrl, size: 210, radius: 22))),
          Padding(
            padding: EdgeInsets.fromLTRB(20, 12, 20, 0),
            child: Text(title,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          ),
          if (subtitle != null)
            Padding(
                padding: EdgeInsets.fromLTRB(20, 2, 20, 0),
                child: Text(subtitle!,
                    style: TextStyle(color: Colors.white60))),
          Padding(
            padding: EdgeInsets.all(16),
            child: Row(children: [
              FilledButton.icon(
                style: FilledButton.styleFrom(
                    backgroundColor: kAccent,
                    foregroundColor: Colors.white,
                    shape: StadiumBorder()),
                icon: Icon(Icons.play_arrow),
                label: Text('Play'),
                onPressed: () => playSongs(songs, 0),
              ),
              SizedBox(width: 12),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(shape: StadiumBorder()),
                icon: Icon(Icons.shuffle),
                label: Text('Shuffle'),
                onPressed: () => playSongs(songs, 0, shuffle: true),
              ),
            ]),
          ),
          for (var i = 0; i < songs.length; i++)
            SongTile(song: songs[i], onTap: () => playSongs(songs, i)),
          SizedBox(height: 24),
        ]),
      ));
}

class ClientPage extends StatefulWidget {
  final String? startAction;
  ClientPage({super.key, this.startAction});
  @override
  State<ClientPage> createState() => _ClientPageState();
}

class _ClientPageState extends State<ClientPage> {
  List<Song> _server = [];
  List<Song> _local = [];
  String _query = '';
  int _tab = 0;
  int _filter = 0; // 0 all, 1 server, 2 this phone
  String? _error;
  bool _loading = true;
  bool _scanning = false;
  bool _searching = false;
  bool _localOn = false;
  String _localDir = '/storage/emulated/0/Music';

  bool get _wide => isTv || MediaQuery.of(context).size.width >= 840;
  double get _k => isTv ? 1.3 : 1.0;
  String get _mode => store.prefs?.getString('conn_mode') ?? 'lan';

  List<Song> get _songs {
    final l = _filter == 1
        ? _server
        : _filter == 2
            ? _local
            : [..._server, ..._local];
    return l.where((s) => !stats.hidden.contains(s.id)).toList()
      ..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
  }

  @override
  void initState() {
    super.initState();
    store.addListener(_rebuild);
    HomeLayout.I.addListener(_rebuild);
    stats.addListener(_rebuild);
    _init();
  }

  @override
  void dispose() {
    store.removeListener(_rebuild);
    HomeLayout.I.removeListener(_rebuild);
    stats.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() {
    if (mounted) setState(() {});
  }

  Future<void> _init() async {
    await store.init();
    _localOn = store.prefs?.getBool('local_on') ?? false;
    _localDir = store.prefs?.getString('local_dir') ?? _localDir;
    if (base.isEmpty && !_localOn) {
      await _autoFlow(silent: true);
    } else {
      await Future.wait([
        if (base.isNotEmpty) _loadServer(retryDiscover: true),
        if (_localOn) _scanPhone(),
      ]);
    }
    publishLibrary();
    await PlaybackEngine.I.restore(libraryById);
    if (mounted) setState(() => _loading = false);
    _saveCount();
    final a = widget.startAction;
    if (a != null && mounted) {
      if (a == 'find') {
        await _autoFlow();
      } else if (a == 'local') {
        await _enableLocal();
      } else if (a == 'connect') {
        await _connectFlow();
      }
    }
  }

  void _saveCount() =>
      store.prefs?.setInt('lib_count', _server.length + _local.length);

  /// Finds a server on the network. Returns true if one was chosen.
  Future<bool> _findServer({bool silent = false}) async {
    if (mounted) setState(() => _searching = true);
    final found = await discoverServers();
    if (mounted) setState(() => _searching = false);
    if (found.isEmpty) {
      if (!silent) toast('No Achufy server found on this network.');
      return false;
    }
    Found? pick = found.length == 1 ? found.first : null;
    if (pick == null && mounted) pick = await pickServer(context, found);
    if (pick == null) return false;
    base = 'http://${pick.host}:${pick.port}';
    await store.prefs?.setString('server', base);
    await store.prefs?.setString('conn_mode', 'lan');
    return true;
  }

  Future<void> _autoFlow({bool silent = false}) async {
    if (await _findServer(silent: silent)) {
      await _loadServer();
    } else if (mounted) {
      setState(() {});
    }
  }

  Future<void> _connectFlow() async {
    final changed = await showConnectSheet(context);
    if (!changed) return;
    setState(() => _loading = true);
    await _loadServer();
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadServer({bool retryDiscover = false}) async {
    _error = null;
    try {
      final r = await http
          .get(Uri.parse(url('/api/tracks')))
          .timeout(Duration(seconds: 10));
      if (r.statusCode == 403) {
        _error = 'This server needs a password.\nTap "Connect" and enter it.';
      } else if (r.statusCode == 503) {
        _error = 'The music server is offline.\nStart it on the server phone.';
      } else if (r.statusCode != 200) {
        throw Exception('Server replied ${r.statusCode}');
      } else {
        final list = jsonDecode(utf8.decode(r.bodyBytes)) as List;
        _server = list.map((j) => Song.fromJson(j as Map<String, dynamic>)).toList();
        _serverCache = _server;
        publishLibrary();
        if (_server.isEmpty) {
          _error = 'Connected, but the server found no songs.\nCheck the music folder on the server phone.';
        }
      }
    } catch (_) {
      _error = _mode == 'lan'
          ? 'Could not reach the server.\nMake sure it is running and both devices are on the same Wi-Fi.'
          : 'Could not reach the server.\nCheck the address and password, and that the server phone is online.';
      if (retryDiscover && _mode == 'lan') {
        if (await _findServer(silent: true)) return _loadServer();
      }
    }
    _saveCount();
    if (mounted) setState(() {});
  }

  Future<void> _scanPhone() async {
    if (mounted) setState(() => _scanning = true);
    try {
      final ok = mounted && await ensureStorage(context);
      if (!ok) {
        toast('Allow access to your music files to scan this phone.');
      } else {
        _local = await scanLocal(_localDir);
        _localCache = _local;
        publishLibrary();
        if (_local.isEmpty) toast('No music found in $_localDir');
      }
    } catch (e) {
      toast('$e'.replaceFirst('Exception: ', ''));
    }
    if (mounted) setState(() => _scanning = false);
  }

  Future<void> _enableLocal() async {
    final dir = await askText(context, 'Music folder on this phone', 'Scan',
        initial: _localDir);
    if (dir == null || dir.isEmpty) return;
    _localDir = dir;
    _localOn = true;
    await store.prefs?.setBool('local_on', true);
    await store.prefs?.setString('local_dir', dir);
    await _scanPhone();
  }

  Future<void> _pickStyle() => pickPlayerStyle(context);

  Future<void> _settings() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: kCard,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(
              title: Text('Settings', style: TextStyle(fontWeight: FontWeight.w800))),
          ListTile(
              leading: Icon(Icons.wifi_find),
              title: Text('Connect to server'),
              subtitle: Text(base.isEmpty
                  ? 'Not connected'
                  : (_mode == 'lan' ? base.replaceFirst('http://', '') : modeLabel(_mode))),
              onTap: () {
                Navigator.pop(context);
                _connectFlow();
              }),
          ListTile(
              leading: Icon(Icons.palette),
              title: Text('Personalize'),
              subtitle: Text('Accent colour and home layout'),
              onTap: () {
                Navigator.pop(context);
                _go(CustomizePage());
              }),
          ListTile(
              leading: Icon(Icons.album),
              title: Text('Player style'),
              subtitle: Text('Cover, vinyl disc or turntable'),
              onTap: () {
                Navigator.pop(context);
                _pickStyle();
              }),
          if (!isTv)
            ValueListenableBuilder<bool>(
              valueListenable: FloatingLyrics.enabled,
              builder: (_, on, __) => SwitchListTile(
                secondary: Icon(Icons.picture_in_picture_alt),
                activeColor: kAccent,
                title: Text('Floating lyrics'),
                subtitle: Text('Show lyrics above other apps'),
                value: on,
                onChanged: (_) {
                  FloatingLyrics.toggle();
                },
              ),
            ),
          ListTile(
              leading: Icon(Icons.phone_android),
              title: Text('Music on this phone'),
              subtitle: Text(_localOn ? _localDir : 'Off'),
              onTap: () {
                Navigator.pop(context);
                _enableLocal();
              }),
          if (base.isNotEmpty)
            ListTile(
                leading: Icon(Icons.refresh),
                title: Text('Refresh server library'),
                onTap: () {
                  Navigator.pop(context);
                  _loadServer();
                }),
          if (_localOn)
            ListTile(
                leading: Icon(Icons.refresh),
                title: Text('Rescan this phone'),
                onTap: () {
                  Navigator.pop(context);
                  _scanPhone();
                }),
          if (_localOn)
            ListTile(
                leading: Icon(Icons.phone_android_outlined),
                title: Text('Turn off phone music'),
                onTap: () async {
                  Navigator.pop(context);
                  await store.prefs?.setBool('local_on', false);
                  setState(() {
                    _localOn = false;
                    _local = [];
                    if (_filter == 2) _filter = 0;
                  });
                }),
          Divider(color: Colors.white12),
          ListTile(
              leading: Icon(Icons.lock_open),
              title: Text('Permissions'),
              subtitle: Text('Music access and notifications'),
              onTap: () {
                Navigator.pop(context);
                ensureStorage(context);
              }),
          ListTile(
              leading: Icon(Icons.dns_outlined),
              title: Text("Share this phone's music"),
              subtitle: Text('Turn this phone into a music server'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => ServerPage()));
              }),
          ListTile(
              leading: Icon(Icons.power_settings_new, color: kAccent),
              title: Text('Quit Achufy'),
              subtitle: Text('Stops music, lyrics and server'),
              onTap: () {
                Navigator.pop(context);
                confirmQuit(context);
              }),
        ]),
      ),
    );
  }

  List<Album> _albums() {
    final m = <String, Album>{};
    for (final s in _songs) {
      m.putIfAbsent('${s.album}|${s.artist}', () => Album(s.album, s.artist, []))
          .songs
          .add(s);
    }
    final l = m.values.toList()
      ..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    return l;
  }

  List<Album> _artists() {
    final m = <String, Album>{};
    for (final s in _songs) {
      m.putIfAbsent(s.artist, () => Album(s.artist, '', [])).songs.add(s);
    }
    final l = m.values.toList()
      ..sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    return l;
  }

  String _greeting() {
    final h = DateTime.now().hour;
    return h < 12 ? 'Good morning' : (h < 18 ? 'Good afternoon' : 'Good evening');
  }

  Widget _filters() {
    if (!_localOn || base.isEmpty) return SizedBox.shrink();
    const labels = ['All', 'Server', 'This phone'];
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 12),
        children: [
          for (var i = 0; i < 3; i++)
            Padding(
              padding: EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text(labels[i]),
                selected: _filter == i,
                showCheckmark: false,
                selectedColor: kAccent,
                labelStyle: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w600),
                onSelected: (_) => setState(() => _filter = i),
              ),
            ),
        ],
      ),
    );
  }

  Widget _empty() => ListView(children: [
        Padding(
          padding: EdgeInsets.fromLTRB(32, 60, 32, 0),
          child: Column(children: [
            ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.asset('assets/logo.png', width: 80, height: 80)),
            SizedBox(height: 20),
            if (_searching || _scanning)
              Padding(
                  padding: EdgeInsets.only(bottom: 12),
                  child: CircularProgressIndicator(color: kAccent)),
            Text(
                _searching
                    ? 'Looking for your server...'
                    : (_error ??
                        (_scanning
                            ? 'Scanning your music...'
                            : 'No music yet.\nFind your server or play music from this phone.')),
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, height: 1.4)),
            SizedBox(height: 24),
            FilledButton.icon(
                style: FilledButton.styleFrom(
                    backgroundColor: kAccent,
                    foregroundColor: Colors.white,
                    shape: StadiumBorder()),
                icon: Icon(Icons.wifi_find),
                onPressed: _searching ? null : () => _autoFlow(),
                label: Text('Find server automatically')),
            SizedBox(height: 10),
            OutlinedButton.icon(
                style: OutlinedButton.styleFrom(shape: StadiumBorder()),
                icon: Icon(Icons.public),
                onPressed: _connectFlow,
                label: Text('Connect (address / internet)')),
            SizedBox(height: 10),
            OutlinedButton.icon(
                style: OutlinedButton.styleFrom(shape: StadiumBorder()),
                icon: Icon(Icons.phone_android),
                onPressed: _enableLocal,
                label: Text('Play music from this phone')),
          ]),
        ),
      ]);

  Widget _header() => Padding(
        padding: EdgeInsets.fromLTRB(20, 14, 6, 4),
        child: Row(children: [
          ClipRRect(
              borderRadius: BorderRadius.circular(11),
              child: Image.asset('assets/logo.png', width: 38, height: 38)),
          SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_greeting(),
                  style: TextStyle(color: Colors.white54, fontSize: 12)),
              Text('Achufy',
                  style: TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
            ]),
          ),
          if (_scanning || _searching)
            Padding(
                padding: EdgeInsets.all(12),
                child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: kAccent))),
          if (!_wide) ...[
            IconButton(
                icon: Icon(Icons.speaker_group_outlined),
                tooltip: 'Output device',
                onPressed: () => showOutputSheet(context)),
            IconButton(icon: Icon(Icons.tune), onPressed: _settings),
          ],
        ]),
      );

  Widget _hero(List<Song> songs, int albums, int artists) => Container(
        margin: EdgeInsets.fromLTRB(16, 12, 16, 8),
        padding: EdgeInsets.fromLTRB(20, 18, 14, 18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [kHeroA, kHeroB]),
          boxShadow: [
            BoxShadow(color: kAccent.withAlpha(60), blurRadius: 28, offset: Offset(0, 10))
          ],
        ),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('YOUR LIBRARY',
                  style: TextStyle(fontSize: 11, letterSpacing: 2, color: Colors.white70)),
              SizedBox(height: 6),
              Text('${songs.length} songs',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              Text('$albums albums - $artists artists',
                  style: TextStyle(color: Colors.white70, fontSize: 13)),
              SizedBox(height: 16),
              FilledButton.icon(
                autofocus: isTv,
                style: FilledButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                    shape: StadiumBorder()),
                icon: Icon(Icons.shuffle, size: 18),
                label: Text('Shuffle play',
                    style: TextStyle(fontWeight: FontWeight.w800)),
                onPressed: () => playSongs(songs, 0, shuffle: true),
              ),
            ]),
          ),
          VinylDisc(
              url: songs.firstWhere((s) => s.coverUrl != null, orElse: () => songs.first).coverUrl,
              size: 104 * _k),
        ]),
      );

  Widget _section(String title, {String? action, VoidCallback? onAction}) =>
      SliverToBoxAdapter(
        child: Padding(
          padding: EdgeInsets.fromLTRB(20, 22, 12, 10),
          child: Row(children: [
            Container(
                width: 4,
                height: 18,
                decoration: BoxDecoration(
                    color: kAccent, borderRadius: BorderRadius.circular(2))),
            SizedBox(width: 10),
            Expanded(
                child: Text(title,
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
            if (action != null)
              TextButton(
                  onPressed: onAction,
                  child: Text(action, style: TextStyle(color: kAccent))),
          ]),
        ),
      );

  void _openList(Album a, String? sub) => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => SongListPage(
              title: a.title, subtitle: sub, coverUrl: a.coverUrl, songs: a.songs)));

  Widget _albumCard(Album a) => InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => _openList(a, a.artist),
        child: Container(
          width: 148 * _k,
          margin: EdgeInsets.only(right: 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CoverArt(url: a.coverUrl, size: 148 * _k, radius: 22),
            SizedBox(height: 8),
            Text(a.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontWeight: FontWeight.w700)),
            Text(a.artist,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Colors.white54, fontSize: 12)),
          ]),
        ),
      );

  Widget _artistChip(Album a) => InkWell(
        borderRadius: BorderRadius.circular(50),
        onTap: () => _openList(a, '${a.songs.length} songs'),
        child: Container(
          width: 92 * _k,
          margin: EdgeInsets.only(right: 12),
          child: Column(children: [
            Container(
              padding: EdgeInsets.all(2),
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                      colors: [kAccent, kHeroB])),
              child: CoverArt(url: a.coverUrl, size: 84 * _k, radius: 50),
            ),
            SizedBox(height: 8),
            Text(a.title,
                maxLines: 1,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
          ]),
        ),
      );

  void _go(Widget w) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  Widget _toolTile(IconData i, String t, VoidCallback f) => InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: f,
        child: Container(
          width: 92 * _k,
          margin: EdgeInsets.only(right: 10),
          padding: EdgeInsets.symmetric(vertical: 14, horizontal: 6),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              color: Colors.white.withAlpha(14),
              border: Border.all(color: Colors.white.withAlpha(20))),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(i, color: kAccent),
            SizedBox(height: 6),
            Text(t,
                textAlign: TextAlign.center,
                maxLines: 2,
                style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600)),
          ]),
        ),
      );

  Widget _tools() => SizedBox(
        height: 92 * _k,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: EdgeInsets.symmetric(horizontal: 20),
          children: [
            _toolTile(Icons.equalizer, 'Studio', () => _go(StudioPage())),
            _toolTile(Icons.mic_external_on, 'Karaoke', () => _go(KaraokePage())),
            _toolTile(Icons.edit_note, 'Lyrics Studio', () => openLyricsStudio(context)),
            _toolTile(Icons.celebration, 'Party', () => _go(PartyPage())),
            _toolTile(Icons.insights, 'Stats', () => _go(StatsPage())),
            _toolTile(Icons.auto_awesome, 'Smart mixes', () => _go(SmartPage())),
            _toolTile(Icons.copy_all, 'Duplicates', () => _go(DuplicatesPage())),
            _toolTile(Icons.palette, 'Personalize', () => _go(CustomizePage())),
          ],
        ),
      );

  Widget _songCard(Song s, List<Song> q, int i) => InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => playSongs(q, i),
        child: Container(
          width: 112 * _k,
          margin: EdgeInsets.only(right: 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CoverArt(url: s.coverUrl, size: 112 * _k, radius: 18),
            SizedBox(height: 6),
            Text(s.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            Text(s.artist,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Colors.white54, fontSize: 11.5)),
          ]),
        ),
      );

  Widget _songRow(List<Song> l) => SizedBox(
        height: 172 * _k,
        child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 20),
            itemCount: l.length,
            itemBuilder: (_, i) => _songCard(l[i], l, i)),
      );

  Widget _home() {
    final songs = _songs;
    if (songs.isEmpty) return _empty();
    final albums = _albums();
    final artists = _artists();
    final shown = songs.length < 15 ? songs.length : 15;
    final byId = {for (final s in songs) s.id: s};
    final recent = [for (final id in stats.recent) if (byId[id] != null) byId[id]!].take(20).toList();
    final most = songs.where((s) => (stats.songs[s.id]?.plays ?? 0) > 0).toList()
      ..sort((a, b) => stats.songs[b.id]!.plays.compareTo(stats.songs[a.id]!.plays));
    final slivers = <Widget>[
      SliverToBoxAdapter(child: _header()),
      SliverToBoxAdapter(child: _filters()),
    ];
    for (final id in HomeLayout.I.order) {
      if (HomeLayout.I.off.contains(id)) continue;
      switch (id) {
        case 'hero':
          slivers.add(SliverToBoxAdapter(child: _hero(songs, albums.length, artists.length)));
          break;
        case 'tools':
          slivers.add(_section('Tools'));
          slivers.add(SliverToBoxAdapter(child: _tools()));
          break;
        case 'recent':
          if (recent.isNotEmpty) {
            slivers.add(_section('Recently played'));
            slivers.add(SliverToBoxAdapter(child: _songRow(recent)));
          }
          break;
        case 'most':
          if (most.isNotEmpty) {
            slivers.add(_section('Most played'));
            slivers.add(SliverToBoxAdapter(child: _songRow(most.take(20).toList())));
          }
          break;
        case 'mood':
          slivers.add(_section('Moods'));
          slivers.add(SliverToBoxAdapter(
            child: SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.symmetric(horizontal: 20),
                children: [
                  for (final m in moods)
                    Padding(
                      padding: EdgeInsets.only(right: 8),
                      child: ActionChip(
                        avatar: Icon(Icons.mood, size: 18),
                        label: Text(m),
                        onPressed: () {
                          final l = songs.where((s) => moodOf(s) == m).toList();
                          if (l.isEmpty) {
                            toast('No $m songs yet');
                          } else {
                            _go(SongListPage(title: '$m mood', subtitle: '${l.length} songs', songs: l));
                          }
                        },
                      ),
                    ),
                ],
              ),
            ),
          ));
          break;
        case 'albums':
          slivers.add(_section('Albums'));
          slivers.add(SliverToBoxAdapter(
            child: SizedBox(
              height: 204 * _k,
              child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  itemCount: albums.length,
                  itemBuilder: (_, i) => _albumCard(albums[i])),
            ),
          ));
          break;
        case 'artists':
          slivers.add(_section('Artists'));
          slivers.add(SliverToBoxAdapter(
            child: SizedBox(
              height: 124 * _k,
              child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  itemCount: artists.length,
                  itemBuilder: (_, i) => _artistChip(artists[i])),
            ),
          ));
          break;
        case 'songs':
          slivers.add(_section('Songs',
              action: songs.length > shown ? 'Show all' : null,
              onAction: () => _go(SongListPage(
                  title: 'All songs', subtitle: '${songs.length} songs', songs: songs))));
          slivers.add(SliverList.builder(
              itemCount: shown,
              itemBuilder: (_, i) =>
                  SongTile(song: songs[i], onTap: () => playSongs(songs, i))));
          break;
      }
    }
    slivers.add(SliverToBoxAdapter(child: SizedBox(height: 24)));
    return RefreshIndicator(
      color: kAccent,
      onRefresh: () async {
        await Future.wait([
          if (base.isNotEmpty) _loadServer(),
          if (_localOn) _scanPhone(),
        ]);
      },
      child: CustomScrollView(slivers: slivers),
    );
  }

  Widget _search() {
    final q = _query.toLowerCase();
    final list = _songs
        .where((s) =>
            q.isEmpty ||
            s.title.toLowerCase().contains(q) ||
            s.artist.toLowerCase().contains(q) ||
            s.album.toLowerCase().contains(q))
        .toList();
    return Column(children: [
      Padding(
        padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
        child: TextField(
          onChanged: (v) => setState(() => _query = v),
          style: TextStyle(color: Colors.white),
          decoration: InputDecoration(
              prefixIcon: Icon(Icons.search, color: Colors.white60),
              hintText: 'What do you want to listen to?',
              hintStyle: TextStyle(color: Colors.white54),
              filled: true,
              fillColor: kCard,
              contentPadding: EdgeInsets.zero,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none)),
        ),
      ),
      Expanded(
        child: list.isEmpty
            ? (_songs.isEmpty
                ? _empty()
                : Center(
                    child: Text('No results', style: TextStyle(color: Colors.white60))))
            : ListView.builder(
                itemCount: list.length,
                itemBuilder: (_, i) =>
                    SongTile(song: list[i], onTap: () => playSongs(list, i))),
      ),
    ]);
  }

  Widget _library() {
    final all = [..._server, ..._local];
    final byId = {for (final s in all) s.id: s};
    final names = store.playlists.keys.toList()
      ..sort((a, b) =>
          a == Store.likedName ? -1 : (b == Store.likedName ? 1 : a.compareTo(b)));
    return ListView(children: [
      Padding(
        padding: EdgeInsets.fromLTRB(16, 8, 8, 8),
        child: Row(children: [
          Expanded(
              child: Text('Your Library',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800))),
          IconButton(
              icon: Icon(Icons.add),
              onPressed: () async {
                final n = await askText(context, 'Playlist name', 'Create');
                if (n != null && n.isNotEmpty) store.createPlaylist(n);
              }),
        ]),
      ),
      if (names.isEmpty)
        Padding(
            padding: EdgeInsets.all(32),
            child: Text(
                'No playlists yet.\nTap the heart in the player or the \u22EE menu on a song.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white60))),
      for (final n in names)
        Builder(builder: (_) {
          final songs = store.playlists[n]!.map((i) => byId[i]).whereType<Song>().toList();
          final liked = n == Store.likedName;
          return ListTile(
            leading: liked
                ? Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: LinearGradient(
                            colors: [kAccent, kHeroB])),
                    child: Icon(Icons.favorite, color: Colors.white))
                : CoverArt(
                    url: songs.isEmpty ? null : songs.first.coverUrl,
                    size: 50,
                    radius: 10),
            title: Text(n),
            subtitle: Text('Playlist - ${songs.length} songs',
                style: TextStyle(color: Colors.white60)),
            trailing: liked
                ? null
                : IconButton(
                    icon: Icon(Icons.delete_outline, color: Colors.white60),
                    onPressed: () => store.remove(n)),
            onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => SongListPage(
                        title: n,
                        subtitle: '${songs.length} songs',
                        coverUrl: songs.isEmpty ? null : songs.first.coverUrl,
                        songs: songs))),
          );
        }),
    ]);
  }

  Widget _miniPlayer() => StreamBuilder<SequenceState?>(
        stream: player.sequenceStateStream,
        builder: (_, snap) {
          final tag = snap.data?.currentSource?.tag;
          if (tag is! MediaItem) return SizedBox.shrink();
          return Container(
            margin: EdgeInsets.fromLTRB(8, 0, 8, 6),
            decoration: BoxDecoration(
                color: kCard,
                border: Border.all(color: kAccent.withAlpha(60)),
                borderRadius: BorderRadius.circular(18)),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            fullscreenDialog: true,
                            builder: (_) => NowPlayingPage())),
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(8, 8, 4, 4),
                      child: Row(children: [
                        ValueListenableBuilder<int>(
                          valueListenable: playerStyle,
                          builder: (_, s, __) => s == 0
                              ? CoverArt(url: tag.artUri?.toString(), size: 46, radius: 10)
                              : VinylDisc(url: tag.artUri?.toString(), size: 46),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                              Text(tag.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontWeight: FontWeight.w700)),
                              Text(tag.artist ?? '',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(color: Colors.white60, fontSize: 12)),
                            ])),
                      ]),
                    ),
                  ),
                ),
                StreamBuilder<bool>(
                  stream: player.playingStream,
                  builder: (_, s) => IconButton(
                    icon: Icon(s.data == true ? Icons.pause : Icons.play_arrow, size: 32),
                    onPressed: s.data == true ? doPause : doPlay,
                  ),
                ),
              ]),
              StreamBuilder<Duration>(
                stream: player.positionStream,
                builder: (_, p) {
                  final total = (player.duration ?? Duration.zero).inMilliseconds;
                  final pos = (p.data ?? Duration.zero).inMilliseconds;
                  return Padding(
                    padding: EdgeInsets.fromLTRB(10, 0, 10, 6),
                    child: LinearProgressIndicator(
                        value: total == 0 ? 0 : (pos / total).clamp(0.0, 1.0),
                        minHeight: 2,
                        color: kAccent,
                        backgroundColor: Colors.white12),
                  );
                },
              ),
            ]),
          );
        },
      );

  @override
  Widget build(BuildContext context) {
    final content = _loading
        ? Center(child: CircularProgressIndicator(color: kAccent))
        : IndexedStack(index: _tab, children: [_home(), _search(), _library()]);
    final wide = _wide;
    return Scaffold(
      backgroundColor: kBg,
      body: Backdrop(
        child: SafeArea(
          bottom: false,
          child: wide
              ? Row(children: [
                  NavigationRail(
                    backgroundColor: Colors.transparent,
                    selectedIndex: _tab,
                    onDestinationSelected: (i) => setState(() => _tab = i),
                    labelType: NavigationRailLabelType.all,
                    selectedIconTheme: IconThemeData(color: Colors.white),
                    unselectedIconTheme: IconThemeData(color: Colors.white54),
                    selectedLabelTextStyle:
                        TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                    unselectedLabelTextStyle: TextStyle(color: Colors.white54),
                    indicatorColor: kAccent.withAlpha(120),
                    leading: Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.asset('assets/logo.png', width: 44, height: 44)),
                    ),
                    trailing: Column(children: [
                      SizedBox(height: 12),
                      IconButton(
                          tooltip: 'Output device',
                          icon: Icon(Icons.speaker_group_outlined),
                          onPressed: () => showOutputSheet(context)),
                      IconButton(
                          tooltip: 'Settings',
                          icon: Icon(Icons.tune),
                          onPressed: _settings),
                    ]),
                    destinations: [
                      NavigationRailDestination(
                          icon: Icon(Icons.home_filled), label: Text('Home')),
                      NavigationRailDestination(
                          icon: Icon(Icons.search), label: Text('Search')),
                      NavigationRailDestination(
                          icon: Icon(Icons.library_music), label: Text('Library')),
                    ],
                  ),
                  Expanded(child: content),
                ])
              : content,
        ),
      ),
      bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
        _miniPlayer(),
        if (!wide)
          NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: [
              NavigationDestination(icon: Icon(Icons.home_filled), label: 'Home'),
              NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
              NavigationDestination(icon: Icon(Icons.library_music), label: 'Your Library'),
            ],
          ),
      ]),
    );
  }
}
