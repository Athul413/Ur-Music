import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:audio_metadata_reader/audio_metadata_reader.dart';

final player = AudioPlayer();

class Song {
  final int id;
  final String title, artist, album;
  final bool cover;
  final String? localPath;
  final Uint8List? coverBytes;
  final String lyrics;
  bool get isLocal => localPath != null;
  Song(this.id, this.title, this.artist, this.album, this.cover,
      {this.localPath, this.coverBytes, this.lyrics = ''});
  factory Song.fromJson(Map<String, dynamic> j) =>
      Song(j['id'], j['title'], j['artist'], j['album'], j['cover'] == true);
}

class ClientPage extends StatefulWidget {
  const ClientPage({super.key});
  @override
  State<ClientPage> createState() => _ClientPageState();
}

class _ClientPageState extends State<ClientPage> {
  String? _base;
  List<Song> _songs = [];
  Map<String, List<int>> _playlists = {};
  String _query = '';
  int _tab = 0;
  String? _error;
  bool _loading = false;
  int _nextLocalId = -1;
  SharedPreferences? _prefs;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs!.getString('playlists');
    if (raw != null) {
      _playlists = (jsonDecode(raw) as Map<String, dynamic>)
          .map((k, v) => MapEntry(k, List<int>.from(v)));
    }
    _base = _prefs!.getString('server');
    if (_base != null) {
      await _load();
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) => _askServer());
    }
    if (mounted) setState(() {});
  }

  void _savePlaylists() =>
      _prefs?.setString('playlists', jsonEncode(_playlists));

  Future<void> _askServer() async {
    final c = TextEditingController(text: _base?.replaceFirst('http://', '') ?? '');
    final v = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Server address'),
        content: TextField(
            controller: c,
            autofocus: true,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(hintText: '192.168.43.1:8080')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, c.text.trim()),
              child: const Text('Connect')),
        ],
      ),
    );
    if (v == null || v.isEmpty) return;
    _base = 'http://$v';
    await _prefs?.setString('server', _base!);
    await _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await http
          .get(Uri.parse('$_base/api/tracks'))
          .timeout(const Duration(seconds: 8));
      final remote = (jsonDecode(r.body) as List).map((j) => Song.fromJson(j)).toList();
      _songs = [..._songs.where((s) => s.isLocal), ...remote];
    } catch (e) {
      _error = 'Could not reach $_base\nIs the server running and on the same Wi-Fi?';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _addLocalFiles() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: true,
        withData: false,
      );
      if (result == null) return;
      final added = <Song>[];
      for (final f in result.files) {
        final path = f.path;
        if (path == null) continue;
        final file = File(path);
        final base = path.replaceAll(RegExp(r'\.[^.]+$'), '');
        var title = f.name.replaceAll(RegExp(r'\.[^.]+$'), '');
        var artist = 'Unknown artist';
        var album = 'Local files';
        Uint8List? art;
        var lyricText = '';
        try {
          final meta = readMetadata(file, getImage: true);
          if ((meta.title ?? '').trim().isNotEmpty) title = meta.title!.trim();
          if ((meta.artist ?? '').trim().isNotEmpty) artist = meta.artist!.trim();
          if ((meta.album ?? '').trim().isNotEmpty) album = meta.album!.trim();
          if (meta.pictures.isNotEmpty) art = meta.pictures.first.bytes;
        } catch (_) {}
        // Sidecar files: SongName.lrc and SongName.jpg/png/webp.
        final lrc = File('$base.lrc');
        if (await lrc.exists()) {
          try { lyricText = await lrc.readAsString(); } catch (_) {}
        }
        if (art == null) {
          for (final ext in ['jpg', 'jpeg', 'png', 'webp']) {
            final image = File('$base.$ext');
            if (await image.exists()) {
              try { art = await image.readAsBytes(); } catch (_) {}
              if (art != null) break;
            }
          }
        }
        added.add(Song(_nextLocalId--, title, artist, album, art != null,
            localPath: path, coverBytes: art, lyrics: lyricText));
      }
      if (!mounted || added.isEmpty) return;
      setState(() {
        _songs.removeWhere((s) => s.isLocal);
        _songs.addAll(added);
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Added ${added.length} local song(s)')),
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not add local files: $e')),
      );
    }
  }

  Future<void> _play(List<Song> list, int index) async {
    try {
      final children = list.map((s) {
        final tag = MediaItem(
          id: s.isLocal ? s.localPath! : '${s.id}',
          title: s.title,
          artist: s.artist,
          album: s.album,
          artUri: s.isLocal ? null : (s.cover ? Uri.parse('$_base/cover/${s.id}') : null),
        );
        return s.isLocal
            ? AudioSource.file(s.localPath!, tag: tag)
            : AudioSource.uri(Uri.parse('$_base/stream/${s.id}'), tag: tag);
      }).toList();
      await player.setAudioSource(
        ConcatenatingAudioSource(children: children), initialIndex: index);
      await player.play();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Playback error: $e')),
      );
      debugPrint('ACHUFY PLAYBACK ERROR: $e');
    }
  }

  Song? _songForTag(Object? tag) {
    if (tag is! MediaItem) return null;
    for (final s in _songs) {
      if ((s.isLocal && s.localPath == tag.id) || (!s.isLocal && '${s.id}' == tag.id)) return s;
    }
    return null;
  }

  List<MapEntry<Duration, String>> _parseLyrics(String raw) {
    final out = <MapEntry<Duration, String>>[];
    final re = RegExp(r'\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\](.*)');
    for (final line in raw.split(RegExp(r'\r?\n'))) {
      final m = re.firstMatch(line);
      if (m == null) continue;
      final ms = int.parse((m.group(3) ?? '0').padRight(3, '0').substring(0, 3));
      final d = Duration(minutes: int.parse(m.group(1)!), seconds: int.parse(m.group(2)!), milliseconds: ms);
      out.add(MapEntry(d, m.group(4)!.trim()));
    }
    out.sort((a, b) => a.key.compareTo(b.key));
    return out;
  }

  void _openNowPlaying(Song? song) {
    if (song == null) return;
    final lines = _parseLyrics(song.lyrics);
    showModalBottomSheet<void>(
      context: context, isScrollControlled: true, backgroundColor: const Color(0xff101410),
      builder: (sheetContext) => DraggableScrollableSheet(
        expand: false, initialChildSize: .9, minChildSize: .55, maxChildSize: .98,
        builder: (_, scroll) => ListView(controller: scroll, padding: const EdgeInsets.all(22), children: [
          Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(4)))),
          const SizedBox(height: 24),
          Center(child: ClipRRect(borderRadius: BorderRadius.circular(18), child: song.coverBytes != null
            ? Image.memory(song.coverBytes!, width: 260, height: 260, fit: BoxFit.cover)
            : (song.isLocal ? const Icon(Icons.album, size: 180, color: Colors.white38)
              : (song.cover ? Image.network('$_base/cover/${song.id}', width: 260, height: 260, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.album, size: 180)) : const Icon(Icons.album, size: 180, color: Colors.white38))))),
          const SizedBox(height: 22),
          Text(song.title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          Text(song.artist, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
          const SizedBox(height: 22),
          if (lines.isEmpty)
            const Padding(padding: EdgeInsets.all(24), child: Text('No lyrics found. Add a matching .lrc file beside this audio file.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)))
          else
            StreamBuilder<Duration>(stream: player.positionStream, builder: (_, snap) {
              final pos = snap.data ?? Duration.zero;
              var active = -1;
              for (var i = 0; i < lines.length; i++) { if (lines[i].key <= pos) active = i; }
              return Column(children: [for (var i = 0; i < lines.length; i++) Padding(
                padding: const EdgeInsets.symmetric(vertical: 9),
                child: Text(lines[i].value.isEmpty ? '♪' : lines[i].value, textAlign: TextAlign.center,
                  style: TextStyle(fontSize: i == active ? 19 : 15, fontWeight: i == active ? FontWeight.bold : FontWeight.normal,
                    color: i == active ? const Color(0xff1ed760) : Colors.white38)),
              )]);
            }),
          const SizedBox(height: 24),
          StreamBuilder<Duration>(stream: player.positionStream, builder: (_, snap) {
            final total = (player.duration ?? Duration.zero).inMilliseconds;
            final pos = (snap.data ?? Duration.zero).inMilliseconds;
            return Slider(value: total == 0 ? 0 : pos.clamp(0, total).toDouble(), max: total == 0 ? 1 : total.toDouble(), onChanged: (v) => player.seek(Duration(milliseconds: v.toInt())));
          }),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(iconSize: 36, onPressed: player.seekToPrevious, icon: const Icon(Icons.skip_previous)),
            StreamBuilder<bool>(stream: player.playingStream, builder: (_, snap) => IconButton(iconSize: 58, onPressed: () => snap.data == true ? player.pause() : player.play(), icon: Icon(snap.data == true ? Icons.pause_circle_filled : Icons.play_circle_filled))),
            IconButton(iconSize: 36, onPressed: player.seekToNext, icon: const Icon(Icons.skip_next)),
          ]),
        ]),
      ),
    );
  }

  Future<void> _addToPlaylist(Song s) async {
    final name = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const ListTile(title: Text('Add to playlist')),
          for (final n in _playlists.keys)
            ListTile(title: Text(n), onTap: () => Navigator.pop(context, n)),
          ListTile(
              leading: const Icon(Icons.add),
              title: const Text('New playlist'),
              onTap: () => Navigator.pop(context, '\u0000new')),
        ]),
      ),
    );
    if (name == null) return;
    var target = name;
    if (name == '\u0000new') {
      final c = TextEditingController();
      final n = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Playlist name'),
          content: TextField(controller: c, autofocus: true),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context, c.text.trim()),
                child: const Text('Create'))
          ],
        ),
      );
      if (n == null || n.isEmpty) return;
      target = n;
    }
    setState(() {
      final l = _playlists.putIfAbsent(target, () => []);
      if (!l.contains(s.id)) l.add(s.id);
    });
    _savePlaylists();
  }

  Widget _tile(Song s, List<Song> list, int i) => ListTile(
        leading: SizedBox(
          width: 48,
          height: 48,
          child: s.coverBytes != null
              ? Image.memory(s.coverBytes!, fit: BoxFit.cover)
              : (s.cover && !s.isLocal
                  ? Image.network('$_base/cover/${s.id}', fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.music_note))
                  : const Icon(Icons.music_note)),
        ),
        title: Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('${s.artist} - ${s.album}',
            maxLines: 1, overflow: TextOverflow.ellipsis),
        onTap: () => _play(list, i),
        onLongPress: () => _addToPlaylist(s),
      );

  Widget _library() {
    final q = _query.toLowerCase();
    final list = _songs
        .where((s) =>
            q.isEmpty ||
            s.title.toLowerCase().contains(q) ||
            s.artist.toLowerCase().contains(q) ||
            s.album.toLowerCase().contains(q))
        .toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: TextField(
          onChanged: (v) => setState(() => _query = v),
          decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: 'Search songs, artists, albums',
              filled: true,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none)),
        ),
      ),
      Expanded(
        child: RefreshIndicator(
          onRefresh: _load,
          child: list.isEmpty
              ? ListView(children: [
                  Padding(
                      padding: const EdgeInsets.all(32),
                      child: Center(
                          child: Text(_error ?? 'No songs found. Tap the folder icon to add music from this device.',
                              textAlign: TextAlign.center)))
                ])
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) => _tile(list[i], list, i)),
        ),
      ),
    ]);
  }

  Widget _playlistsTab() {
    if (_playlists.isEmpty) {
      return const Center(
          child: Padding(
              padding: EdgeInsets.all(32),
              child: Text('No playlists yet.\nLong-press a song to add it.',
                  textAlign: TextAlign.center)));
    }
    return ListView(children: [
      for (final e in _playlists.entries)
        ListTile(
          leading: const Icon(Icons.queue_music),
          title: Text(e.key),
          subtitle: Text('${e.value.length} songs'),
          trailing: IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () {
                setState(() => _playlists.remove(e.key));
                _savePlaylists();
              }),
          onTap: () {
            final byId = {for (final s in _songs) s.id: s};
            final list = e.value.map((i) => byId[i]).whereType<Song>().toList();
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => Scaffold(
                          appBar: AppBar(title: Text(e.key)),
                          body: ListView.builder(
                              itemCount: list.length,
                              itemBuilder: (_, i) => _tile(list[i], list, i)),
                        )));
          },
        ),
    ]);
  }

  Widget _miniPlayer() => StreamBuilder<SequenceState?>(
        stream: player.sequenceStateStream,
        builder: (_, snap) {
          final tag = snap.data?.currentSource?.tag;
          if (tag is! MediaItem) return const SizedBox.shrink();
          return Material(
            color: Theme.of(context).colorScheme.surfaceContainerHigh,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              StreamBuilder<Duration>(
                stream: player.positionStream,
                builder: (_, p) {
                  final total = (player.duration ?? Duration.zero).inMilliseconds;
                  final pos = (p.data ?? Duration.zero).inMilliseconds;
                  return Slider(
                    value: total == 0 ? 0 : pos.clamp(0, total).toDouble(),
                    max: total == 0 ? 1 : total.toDouble(),
                    onChanged: (v) =>
                        player.seek(Duration(milliseconds: v.toInt())),
                  );
                },
              ),
              ListTile(
                dense: true,
                title: Text(tag.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(tag.artist ?? '', maxLines: 1),
                onTap: () => _openNowPlaying(_songForTag(tag)),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(
                      icon: const Icon(Icons.skip_previous),
                      onPressed: player.seekToPrevious),
                  StreamBuilder<bool>(
                    stream: player.playingStream,
                    builder: (_, s) => IconButton(
                      iconSize: 36,
                      icon: Icon(s.data == true
                          ? Icons.pause_circle
                          : Icons.play_circle),
                      onPressed: s.data == true ? player.pause : player.play,
                    ),
                  ),
                  IconButton(
                      icon: const Icon(Icons.skip_next),
                      onPressed: player.seekToNext),
                ]),
              ),
            ]),
          );
        },
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Library'),
          actions: [
            IconButton(tooltip: 'Add local music', icon: const Icon(Icons.folder_open), onPressed: _addLocalFiles),
            IconButton(icon: const Icon(Icons.dns), onPressed: _askServer),
            IconButton(icon: const Icon(Icons.refresh), onPressed: _base == null ? _addLocalFiles : _load),
          ],
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : (_tab == 0 ? _library() : _playlistsTab()),
        bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
          _miniPlayer(),
          NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.library_music), label: 'Songs'),
              NavigationDestination(icon: Icon(Icons.queue_music), label: 'Playlists'),
            ],
          ),
        ]),
      );
}
