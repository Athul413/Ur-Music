import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';

final player = AudioPlayer();

class Song {
  final int id;
  final String title, artist, album;
  final bool cover;
  Song(this.id, this.title, this.artist, this.album, this.cover);
  factory Song.fromJson(Map<String, dynamic> j) =>
      Song(j['id'], j['title'], j['artist'], j['album'], j['cover'] == true);
}

class ClientPage extends StatefulWidget {
  const ClientPage({super.key});
  @override
  State<ClientPage> createState() => _ClientPageState();
}

class _ClientPageState extends State<ClientPage> {
  String? _base;
  List<Song> _songs = [];
  Map<String, List<int>> _playlists = {};
  String _query = '';
  int _tab = 0;
  String? _error;
  bool _loading = false;
  SharedPreferences? _prefs;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs!.getString('playlists');
    if (raw != null) {
      _playlists = (jsonDecode(raw) as Map<String, dynamic>)
          .map((k, v) => MapEntry(k, List<int>.from(v)));
    }
    _base = _prefs!.getString('server');
    if (_base != null) {
      await _load();
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) => _askServer());
    }
    if (mounted) setState(() {});
  }

  void _savePlaylists() =>
      _prefs?.setString('playlists', jsonEncode(_playlists));

  Future<void> _askServer() async {
    final c = TextEditingController(text: _base?.replaceFirst('http://', '') ?? '');
    final v = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Server address'),
        content: TextField(
            controller: c,
            autofocus: true,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(hintText: '192.168.43.1:8080')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, c.text.trim()),
              child: const Text('Connect')),
        ],
      ),
    );
    if (v == null || v.isEmpty) return;
    _base = 'http://$v';
    await _prefs?.setString('server', _base!);
    await _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await http
          .get(Uri.parse('$_base/api/tracks'))
          .timeout(const Duration(seconds: 8));
      _songs = (jsonDecode(r.body) as List).map((j) => Song.fromJson(j)).toList();
    } catch (e) {
      _error = 'Could not reach $_base\nIs the server running and on the same Wi-Fi?';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _play(List<Song> list, int index) async {
    final src = ConcatenatingAudioSource(
      children: list
          .map((s) => AudioSource.uri(
                Uri.parse('$_base/stream/${s.id}'),
                tag: MediaItem(
                  id: '${s.id}',
                  title: s.title,
                  artist: s.artist,
                  album: s.album,
                  artUri: s.cover ? Uri.parse('$_base/cover/${s.id}') : null,
                ),
              ))
          .toList(),
    );
    await player.setAudioSource(src, initialIndex: index);
    player.play();
  }

  Future<void> _addToPlaylist(Song s) async {
    final name = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const ListTile(title: Text('Add to playlist')),
          for (final n in _playlists.keys)
            ListTile(title: Text(n), onTap: () => Navigator.pop(context, n)),
          ListTile(
              leading: const Icon(Icons.add),
              title: const Text('New playlist'),
              onTap: () => Navigator.pop(context, '\u0000new')),
        ]),
      ),
    );
    if (name == null) return;
    var target = name;
    if (name == '\u0000new') {
      final c = TextEditingController();
      final n = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Playlist name'),
          content: TextField(controller: c, autofocus: true),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context, c.text.trim()),
                child: const Text('Create'))
          ],
        ),
      );
      if (n == null || n.isEmpty) return;
      target = n;
    }
    setState(() {
      final l = _playlists.putIfAbsent(target, () => []);
      if (!l.contains(s.id)) l.add(s.id);
    });
    _savePlaylists();
  }

  Widget _tile(Song s, List<Song> list, int i) => ListTile(
        leading: SizedBox(
          width: 48,
          height: 48,
          child: s.cover
              ? Image.network('$_base/cover/${s.id}',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(Icons.music_note))
              : const Icon(Icons.music_note),
        ),
        title: Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('${s.artist} - ${s.album}',
            maxLines: 1, overflow: TextOverflow.ellipsis),
        onTap: () => _play(list, i),
        onLongPress: () => _addToPlaylist(s),
      );

  Widget _library() {
    final q = _query.toLowerCase();
    final list = _songs
        .where((s) =>
            q.isEmpty ||
            s.title.toLowerCase().contains(q) ||
            s.artist.toLowerCase().contains(q) ||
            s.album.toLowerCase().contains(q))
        .toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: TextField(
          onChanged: (v) => setState(() => _query = v),
          decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: 'Search songs, artists, albums',
              filled: true,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none)),
        ),
      ),
      Expanded(
        child: RefreshIndicator(
          onRefresh: _load,
          child: list.isEmpty
              ? ListView(children: [
                  Padding(
                      padding: const EdgeInsets.all(32),
                      child: Center(
                          child: Text(_error ?? 'No songs found',
                              textAlign: TextAlign.center)))
                ])
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) => _tile(list[i], list, i)),
        ),
      ),
    ]);
  }

  Widget _playlistsTab() {
    if (_playlists.isEmpty) {
      return const Center(
          child: Padding(
              padding: EdgeInsets.all(32),
              child: Text('No playlists yet.\nLong-press a song to add it.',
                  textAlign: TextAlign.center)));
    }
    return ListView(children: [
      for (final e in _playlists.entries)
        ListTile(
          leading: const Icon(Icons.queue_music),
          title: Text(e.key),
          subtitle: Text('${e.value.length} songs'),
          trailing: IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () {
                setState(() => _playlists.remove(e.key));
                _savePlaylists();
              }),
          onTap: () {
            final byId = {for (final s in _songs) s.id: s};
            final list = e.value.map((i) => byId[i]).whereType<Song>().toList();
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => Scaffold(
                          appBar: AppBar(title: Text(e.key)),
                          body: ListView.builder(
                              itemCount: list.length,
                              itemBuilder: (_, i) => _tile(list[i], list, i)),
                        )));
          },
        ),
    ]);
  }

  Widget _miniPlayer() => StreamBuilder<SequenceState?>(
        stream: player.sequenceStateStream,
        builder: (_, snap) {
          final tag = snap.data?.currentSource?.tag;
          if (tag is! MediaItem) return const SizedBox.shrink();
          return Material(
            color: Theme.of(context).colorScheme.surfaceContainerHigh,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              StreamBuilder<Duration>(
                stream: player.positionStream,
                builder: (_, p) {
                  final total = (player.duration ?? Duration.zero).inMilliseconds;
                  final pos = (p.data ?? Duration.zero).inMilliseconds;
                  return Slider(
                    value: total == 0 ? 0 : pos.clamp(0, total).toDouble(),
                    max: total == 0 ? 1 : total.toDouble(),
                    onChanged: (v) =>
                        player.seek(Duration(milliseconds: v.toInt())),
                  );
                },
              ),
              ListTile(
                dense: true,
                title: Text(tag.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(tag.artist ?? '', maxLines: 1),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(
                      icon: const Icon(Icons.skip_previous),
                      onPressed: player.seekToPrevious),
                  StreamBuilder<bool>(
                    stream: player.playingStream,
                    builder: (_, s) => IconButton(
                      iconSize: 36,
                      icon: Icon(s.data == true
                          ? Icons.pause_circle
                          : Icons.play_circle),
                      onPressed: s.data == true ? player.pause : player.play,
                    ),
                  ),
                  IconButton(
                      icon: const Icon(Icons.skip_next),
                      onPressed: player.seekToNext),
                ]),
              ),
            ]),
          );
        },
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Library'),
          actions: [
            IconButton(icon: const Icon(Icons.dns), onPressed: _askServer),
            IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          ],
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : (_tab == 0 ? _library() : _playlistsTab()),
        bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
          _miniPlayer(),
          NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.library_music), label: 'Songs'),
              NavigationDestination(icon: Icon(Icons.queue_music), label: 'Playlists'),
            ],
          ),
        ]),
      );
}
