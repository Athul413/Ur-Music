import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';

final player = AudioPlayer();

class Song {
  final int id;
  final String title, artist, album, lyrics;
  final bool cover;
  Song(this.id, this.title, this.artist, this.album, this.cover, this.lyrics);
  factory Song.fromJson(Map<String, dynamic> j) => Song(
    j['id'], j['title'], j['artist'], j['album'],
    j['cover'] == true, (j['lyrics'] ?? '') as String);
}

class ClientPage extends StatefulWidget {
  const ClientPage({super.key});
  @override
  State<ClientPage> createState() => _ClientPageState();
}

class _ClientPageState extends State<ClientPage> {
  String? _base;
  List<Song> _songs = [];
  Map<String, List<int>> _playlists = {};
  String _query = '';
  int _tab = 0;
  String? _error;
  bool _loading = false;
  SharedPreferences? _prefs;

  @override
  void initState() { super.initState(); _init(); }

  Future<void> _init() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs!.getString('playlists');
    if (raw != null) {
      _playlists = (jsonDecode(raw) as Map<String, dynamic>)
          .map((k, v) => MapEntry(k, List<int>.from(v)));
    }
    _base = _prefs!.getString('server');
    if (_base != null) { await _load(); }
    else { WidgetsBinding.instance.addPostFrameCallback((_) => _askServer()); }
    if (mounted) setState(() {});
  }

  void _savePlaylists() => _prefs?.setString('playlists', jsonEncode(_playlists));

  Future<void> _askServer() async {
    final c = TextEditingController(text: _base?.replaceFirst('http://', '') ?? '');
    final v = await showDialog<String>(context: context, builder: (_) => AlertDialog(
      title: const Text('Connect to your music server'),
      content: TextField(controller: c, autofocus: true, keyboardType: TextInputType.url,
        decoration: const InputDecoration(hintText: '192.168.43.1:8080')),
      actions: [TextButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('Connect'))],
    ));
    if (v == null || v.isEmpty) return;
    _base = 'http://$v';
    await _prefs?.setString('server', _base!);
    await _load();
  }

  Future<void> _load() async {
    if (_base == null) return;
    setState(() { _loading = true; _error = null; });
    try {
      final r = await http.get(Uri.parse('$_base/api/tracks')).timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
      _songs = (jsonDecode(r.body) as List).map((j) => Song.fromJson(j)).toList();
    } catch (_) {
      _error = 'Could not reach the server.\nCheck that both phones are on the same Wi-Fi.';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _play(List<Song> list, int index) async {
    if (_base == null || list.isEmpty) return;
    final src = ConcatenatingAudioSource(children: list.map((s) => AudioSource.uri(
      Uri.parse('$_base/stream/${s.id}'),
      tag: MediaItem(id: '${s.id}', title: s.title, artist: s.artist,
        album: s.album, artUri: s.cover ? Uri.parse('$_base/cover/${s.id}') : null),
    )).toList());
    await player.setAudioSource(src, initialIndex: index);
    player.play();
  }

  Future<void> _addToPlaylist(Song s) async {
    final name = await showModalBottomSheet<String>(context: context, builder: (_) => SafeArea(
      child: ListView(shrinkWrap: true, children: [
        const ListTile(title: Text('Add to playlist')),
        for (final n in _playlists.keys) ListTile(title: Text(n), onTap: () => Navigator.pop(context, n)),
        ListTile(leading: const Icon(Icons.add), title: const Text('New playlist'),
          onTap: () => Navigator.pop(context, '\u0000new')),
      ]),
    ));
    if (name == null) return;
    var target = name;
    if (name == '\u0000new') {
      final c = TextEditingController();
      final n = await showDialog<String>(context: context, builder: (_) => AlertDialog(
        title: const Text('Playlist name'), content: TextField(controller: c, autofocus: true),
        actions: [TextButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('Create'))],
      ));
      if (n == null || n.isEmpty) return;
      target = n;
    }
    setState(() { final l = _playlists.putIfAbsent(target, () => []); if (!l.contains(s.id)) l.add(s.id); });
    _savePlaylists();
  }

  Widget _art(Song s, {double size = 54}) => ClipRRect(
    borderRadius: BorderRadius.circular(8),
    child: SizedBox(width: size, height: size,
      child: s.cover && _base != null
        ? Image.network('$_base/cover/${s.id}', fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _placeholder(size))
        : _placeholder(size)),
  );

  Widget _placeholder(double size) => Container(
    color: const Color(0xFF29332B), child: Icon(Icons.music_note, size: size * .48, color: achufyGreen));

  Widget _tile(Song s, List<Song> list, int i) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 3),
    leading: _art(s), title: Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis,
      style: const TextStyle(fontWeight: FontWeight.w600)),
    subtitle: Text('${s.artist} • ${s.album}', maxLines: 1, overflow: TextOverflow.ellipsis),
    trailing: IconButton(icon: const Icon(Icons.more_vert), onPressed: () => _addToPlaylist(s)),
    onTap: () => _play(list, i), onLongPress: () => _addToPlaylist(s));

  Widget _library() {
    final q = _query.toLowerCase();
    final list = _songs.where((s) => q.isEmpty || s.title.toLowerCase().contains(q) ||
      s.artist.toLowerCase().contains(q) || s.album.toLowerCase().contains(q)).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: TextField(
        onChanged: (v) => setState(() => _query = v),
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'What do you want to play?',
          filled: true, fillColor: const Color(0xFF202720),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none)),
      )),
      Expanded(child: RefreshIndicator(onRefresh: _load,
        child: list.isEmpty ? ListView(children: [
          const SizedBox(height: 90),
          Icon(_error == null ? Icons.library_music_outlined : Icons.wifi_off, size: 54, color: Colors.white38),
          const SizedBox(height: 14),
          Center(child: Text(_error ?? 'No songs found', textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70))),
          if (_base == null) Center(child: TextButton(onPressed: _askServer, child: const Text('Connect server'))),
        ]) : ListView(children: [
          Padding(padding: const EdgeInsets.fromLTRB(18, 12, 18, 4), child: Text('${list.length} SONGS',
            style: const TextStyle(color: Colors.white54, fontSize: 11, letterSpacing: 1.5, fontWeight: FontWeight.bold))),
          for (var i = 0; i < list.length; i++) _tile(list[i], list, i),
        ]))),
    ]);
  }

  Widget _playlistsTab() {
    if (_playlists.isEmpty) return const Center(child: Text('Your playlists live here.\nAdd a song to get started.',
      textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)));
    return ListView(children: [
      for (final e in _playlists.entries) ListTile(
        leading: Container(width: 52, height: 52, decoration: BoxDecoration(color: const Color(0xFF29332B),
          borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.queue_music, color: achufyGreen)),
        title: Text(e.key), subtitle: Text('${e.value.length} songs'),
        trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () {
          setState(() => _playlists.remove(e.key)); _savePlaylists();
        }),
        onTap: () {
          final byId = {for (final s in _songs) s.id: s};
          final list = e.value.map((i) => byId[i]).whereType<Song>().toList();
          Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
            appBar: AppBar(title: Text(e.key)), body: ListView.builder(itemCount: list.length,
              itemBuilder: (_, i) => _tile(list[i], list, i)))));
        },
      ),
    ]);
  }

  Widget _miniPlayer() => StreamBuilder<SequenceState?>(
    stream: player.sequenceStateStream,
    builder: (_, snap) {
      final tag = snap.data?.currentSource?.tag;
      if (tag is! MediaItem) return const SizedBox.shrink();
      final matches = _songs.where((s) => '${s.id}' == tag.id).toList();
      final song = matches.isEmpty ? null : matches.first;
      return InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) =>
          NowPlayingPage(base: _base ?? '', songs: _songs))),
        child: Container(color: const Color(0xFF25372A), padding: const EdgeInsets.fromLTRB(10, 5, 8, 4),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            StreamBuilder<Duration>(stream: player.positionStream, builder: (_, p) {
              final total = (player.duration ?? Duration.zero).inMilliseconds;
              final pos = (p.data ?? Duration.zero).inMilliseconds;
              return LinearProgressIndicator(value: total == 0 ? 0 : pos.clamp(0, total) / total,
                minHeight: 2, backgroundColor: Colors.white12, color: achufyGreen);
            }),
            Row(children: [
              if (song != null) _art(song, size: 42) else _placeholder(42),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(tag.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                Text(tag.artist ?? '', maxLines: 1, style: const TextStyle(color: Colors.white60, fontSize: 12)),
              ])),
              IconButton(icon: const Icon(Icons.skip_previous), onPressed: player.seekToPrevious),
              StreamBuilder<bool>(stream: player.playingStream, builder: (_, s) => IconButton(
                iconSize: 30, icon: Icon(s.data == true ? Icons.pause : Icons.play_arrow),
                onPressed: s.data == true ? player.pause : player.play)),
              IconButton(icon: const Icon(Icons.skip_next), onPressed: player.seekToNext),
            ]),
          ]),
        ),
      );
    });

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Row(children: [const AchufyMark(size: 28), const SizedBox(width: 9),
        const Text('Achufy', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -.4))]),
      actions: [
        IconButton(icon: const Icon(Icons.dns_outlined), tooltip: 'Server address', onPressed: _askServer),
        IconButton(icon: const Icon(Icons.refresh), tooltip: 'Refresh library', onPressed: _load),
      ],
    ),
    body: _loading ? const Center(child: CircularProgressIndicator(color: achufyGreen))
      : (_tab == 0 ? _library() : _playlistsTab()),
    bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
      _miniPlayer(),
      NavigationBar(
        backgroundColor: const Color(0xFF101310), indicatorColor: achufyGreen.withOpacity(.15),
        selectedIndex: _tab, onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.library_music_outlined), selectedIcon: Icon(Icons.library_music), label: 'Your Library'),
        ],
      ),
    ]),
  );
}

class NowPlayingPage extends StatelessWidget {
  final String base;
  final List<Song> songs;
  const NowPlayingPage({super.key, required this.base, required this.songs});

  String _time(Duration d) => '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) => StreamBuilder<SequenceState?>(
    stream: player.sequenceStateStream,
    builder: (context, snap) {
      final tag = snap.data?.currentSource?.tag;
      final matches = tag is MediaItem ? songs.where((s) => '${s.id}' == tag.id).toList() : <Song>[];
      final song = matches.isEmpty ? null : matches.first;
      if (tag is! MediaItem) return const Scaffold(body: Center(child: Text('Nothing is playing')));
      return Scaffold(
        appBar: AppBar(leading: IconButton(icon: const Icon(Icons.keyboard_arrow_down),
          onPressed: () => Navigator.pop(context)), title: const Text('NOW PLAYING',
          style: TextStyle(fontSize: 12, letterSpacing: 2, fontWeight: FontWeight.bold)),
          centerTitle: true, actions: [IconButton(icon: const Icon(Icons.queue_music),
            onPressed: () => showModalBottomSheet(context: context, builder: (_) => SafeArea(
              child: ListView(shrinkWrap: true, children: [
                const ListTile(title: Text('Up next')),
                for (final s in songs) ListTile(title: Text(s.title), subtitle: Text(s.artist),
                  onTap: () { player.seek(Duration.zero, index: songs.indexOf(s)); Navigator.pop(context); }),
              ]))))]),
        body: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(24, 10, 24, 24), children: [
          const SizedBox(height: 10),
          AspectRatio(aspectRatio: 1, child: ClipRRect(borderRadius: BorderRadius.circular(14),
            child: song != null && song.cover
              ? Image.network('$base/cover/${song.id}', fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _bigPlaceholder())
              : _bigPlaceholder())),
          const SizedBox(height: 26),
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tag.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text(tag.artist ?? '', style: const TextStyle(color: Colors.white60, fontSize: 17)),
            ])),
            IconButton(iconSize: 30, color: achufyGreen, icon: const Icon(Icons.favorite_border),
              onPressed: () {}),
          ]),
          const SizedBox(height: 14),
          StreamBuilder<Duration>(stream: player.positionStream, builder: (_, p) {
            final total = player.duration ?? Duration.zero;
            final pos = p.data ?? Duration.zero;
            return Column(children: [
              Slider(value: total.inMilliseconds == 0 ? 0 : pos.inMilliseconds.clamp(0, total.inMilliseconds).toDouble(),
                max: total.inMilliseconds == 0 ? 1 : total.inMilliseconds.toDouble(),
                activeColor: achufyGreen, inactiveColor: Colors.white24,
                onChanged: (v) => player.seek(Duration(milliseconds: v.toInt()))),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(_time(pos), style: const TextStyle(color: Colors.white54, fontSize: 12)),
                Text(_time(total), style: const TextStyle(color: Colors.white54, fontSize: 12)),
              ]),
            ]);
          }),
          const SizedBox(height: 6),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            IconButton(icon: const Icon(Icons.shuffle), color: achufyGreen, onPressed: () {}),
            IconButton(iconSize: 38, icon: const Icon(Icons.skip_previous), onPressed: player.seekToPrevious),
            StreamBuilder<bool>(stream: player.playingStream, builder: (_, s) => IconButton(
              iconSize: 68, color: achufyGreen,
              icon: Icon(s.data == true ? Icons.pause_circle_filled : Icons.play_circle_filled),
              onPressed: s.data == true ? player.pause : player.play)),
            IconButton(iconSize: 38, icon: const Icon(Icons.skip_next), onPressed: player.seekToNext),
            IconButton(icon: const Icon(Icons.repeat), onPressed: () {}),
          ]),
          const SizedBox(height: 22),
          Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(
            color: const Color(0xFF1B2B20), borderRadius: BorderRadius.circular(18)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [const Expanded(child: Text('Lyrics', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                Icon(Icons.lyrics_outlined, color: achufyGreen)]),
              const SizedBox(height: 12),
              if (song == null || song.lyrics.trim().isEmpty)
                const Text('No lyrics found for this track.\nAdd a matching .lrc file beside the audio file on the server phone.',
                  style: TextStyle(color: Colors.white60, height: 1.5))
              else
                StreamBuilder<Duration>(stream: player.positionStream, builder: (_, p) {
                  final lines = _parseLyrics(song.lyrics);
                  final now = (p.data ?? Duration.zero).inMilliseconds;
                  var active = lines.lastIndexWhere((l) => l.$1 <= now);
                  if (active < 0) active = 0;
                  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    for (var i = 0; i < lines.length; i++)
                      Padding(padding: const EdgeInsets.symmetric(vertical: 7),
                        child: Text(lines[i].$2, style: TextStyle(
                          fontSize: i == active ? 19 : 15,
                          height: 1.35,
                          fontWeight: i == active ? FontWeight.bold : FontWeight.normal,
                          color: i == active ? Colors.white : Colors.white38))),
                  ]);
                }),
            ]),
          ),
        ])),
      );
    });

  Widget _bigPlaceholder() => Container(color: const Color(0xFF29332B),
    child: const Center(child: Icon(Icons.music_note, size: 100, color: achufyGreen)));

  List<(int, String)> _parseLyrics(String raw) {
    final out = <(int, String)>[];
    final re = RegExp(r'\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\](.*)');
    for (final line in raw.split('\n')) {
      final m = re.firstMatch(line);
      if (m == null) continue;
      final ms = (int.parse(m.group(1)!) * 60 + int.parse(m.group(2)!)) * 1000 +
        int.parse((m.group(3) ?? '0').padRight(3, '0').substring(0, 3));
      out.add((ms, m.group(4)!.trim()));
    }
    out.sort((a, b) => a.$1.compareTo(b.$1));
    return out;
  }
}
