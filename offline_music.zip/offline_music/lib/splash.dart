import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'client.dart';
import 'launch.dart';
import 'main.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))
        ..repeat();
  bool _first = false;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    var first = false;
    try {
      final p = await SharedPreferences.getInstance();
      first = !(p.getBool('seen_intro') ?? false);
      await p.setBool('seen_intro', true);
    } catch (_) {}
    if (mounted) setState(() => _first = first);
    await Future.delayed(Duration(milliseconds: first ? 3000 : 1900));
    if (!mounted) return;
    Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 600),
          pageBuilder: (_, __, ___) => isTv ? const ClientPage() : const LaunchPage(),
          transitionsBuilder: (_, a, __, child) =>
              FadeTransition(opacity: a, child: child),
        ));
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: kBg,
        body: Backdrop(
          child: Center(
            child: AnimatedBuilder(
              animation: _c,
              builder: (_, __) {
                final pulse = 1 + 0.04 * math.sin(_c.value * 2 * math.pi);
                return Column(mainAxisSize: MainAxisSize.min, children: [
                  Transform.scale(
                    scale: pulse,
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(34),
                          boxShadow: [
                            BoxShadow(
                                color: kAccent.withAlpha(110),
                                blurRadius: 50,
                                spreadRadius: 4)
                          ]),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(34),
                          child: Image.asset('assets/logo.png',
                              width: 128, height: 128)),
                    ),
                  ),
                  const SizedBox(height: 28),
                  const Text('ACHUFY',
                      style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 8)),
                  const SizedBox(height: 6),
                  const Text('Your music. Your sound.',
                      style: TextStyle(color: Colors.white54, letterSpacing: 1)),
                  const SizedBox(height: 44),
                  SizedBox(
                    height: 36,
                    child: Row(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          for (var i = 0; i < 5; i++)
                            Container(
                              width: 6,
                              height: 8 +
                                  28 *
                                      math
                                          .sin((_c.value + i * 0.17) * math.pi)
                                          .abs(),
                              margin: const EdgeInsets.symmetric(horizontal: 3),
                              decoration: BoxDecoration(
                                  color: kAccent,
                                  borderRadius: BorderRadius.circular(3)),
                            ),
                        ]),
                  ),
                  const SizedBox(height: 18),
                  Text(
                      _first
                          ? 'Setting things up for the first time...'
                          : 'Loading your music...',
                      style: const TextStyle(color: Colors.white38, fontSize: 12)),
                ]);
              },
            ),
          ),
        ),
      );
}
