import 'dart:io';

T? tryOr<T>(T? Function() f) {
  try {
    return f();
  } catch (_) {
    return null;
  }
}

class ExtraTags {
  final String genre;
  final int? year;
  final int? durMs;
  ExtraTags(this.genre, this.year, this.durMs);
}

/// Reads genre / year / duration from whatever the metadata reader exposes.
/// Uses dynamic access so a missing field never breaks scanning.
ExtraTags extraTags(dynamic m) {
  final g = tryOr<String>(() {
    final x = m.genres;
    if (x is List && x.isNotEmpty) return '${x.first}';
    if (x is String) return x;
    return null;
  });
  final y = tryOr<int>(() {
    final x = m.year;
    if (x is DateTime) return x.year;
    if (x is int) return x;
    return int.tryParse('$x');
  });
  final d = tryOr<int>(() {
    final x = m.duration;
    if (x is Duration) return x.inMilliseconds;
    return null;
  });
  return ExtraTags((g ?? '').trim(), (y != null && y > 1000 && y < 3000) ? y : null, d);
}

/// Looks for a REPLAYGAIN_TRACK_GAIN tag in the first bytes of the file.
Future<double?> readReplayGain(File f) async {
  try {
    final len = await f.length();
    final n = len < 200000 ? len : 200000;
    final bytes = <int>[];
    await for (final c in f.openRead(0, n)) {
      bytes.addAll(c);
    }
    final cleaned = String.fromCharCodes(bytes.where((b) => b != 0));
    final m = RegExp(
            r'REPLAYGAIN_TRACK_GAIN[^0-9\-+]{0,24}([\-+]?\d+(?:\.\d+)?)\s*dB',
            caseSensitive: false)
        .firstMatch(cleaned);
    if (m == null) return null;
    return double.tryParse(m.group(1)!);
  } catch (_) {
    return null;
  }
}
