import 'dart:convert';
import 'dart:io';
import 'dart:math';

/// Server side of Party mode: keeps one shared, time-stamped playback state
/// and sends it to every connected device.
class PartyHub {
  final Map<WebSocket, Map<String, dynamic>> _members = {};
  List<int> queue = [];
  int index = 0;
  bool playing = false;
  int anchorPos = 0; // song position (ms) at server time anchorAt
  int anchorAt = 0;

  int _now() => DateTime.now().millisecondsSinceEpoch;
  int _curPos() => playing ? anchorPos + max(0, _now() - anchorAt) : anchorPos;

  void add(WebSocket ws) {
    _members[ws] = {'name': 'Guest', 'role': 'full'};
    ws.pingInterval = Duration(seconds: 20);
    ws.listen((m) {
      if (m is String) {
        try {
          _handle(ws, jsonDecode(m) as Map<String, dynamic>);
        } catch (_) {}
      }
    }, onDone: () {
      _members.remove(ws);
      _roster();
    }, onError: (_) {
      _members.remove(ws);
      _roster();
    });
  }

  void closeAll() {
    for (final ws in _members.keys.toList()) {
      try {
        ws.close();
      } catch (_) {}
    }
    _members.clear();
  }

  void _send(WebSocket ws, Map<String, dynamic> m) {
    try {
      ws.add(jsonEncode(m));
    } catch (_) {}
  }

  void _all(Map<String, dynamic> m) {
    for (final ws in _members.keys.toList()) {
      _send(ws, m);
    }
  }

  Map<String, dynamic> _state() => {
        't': 'state',
        'queue': queue,
        'index': index,
        'playing': playing,
        'pos': anchorPos,
        'at': anchorAt,
      };

  void _roster() => _all({
        't': 'roster',
        'members': [
          for (final e in _members.values) {'name': e['name'], 'role': e['role']}
        ],
      });

  void _advance(int d, {bool auto = false}) {
    final ni = index + d;
    if (ni < 0 || ni >= queue.length) {
      if (auto) {
        playing = false;
        anchorPos = 0;
        anchorAt = _now();
        _all(_state());
      }
      return;
    }
    index = ni;
    anchorPos = 0;
    anchorAt = _now() + 900;
    playing = true;
    _all(_state());
  }

  void _handle(WebSocket ws, Map<String, dynamic> m) {
    switch (m['t']) {
      case 'hello':
        _members[ws] = {'name': '${m['name'] ?? 'Guest'}', 'role': '${m['role'] ?? 'full'}'};
        if (queue.isNotEmpty) _send(ws, _state());
        _roster();
        break;
      case 'ping':
        _send(ws, {'t': 'pong', 'c': m['c'], 's': _now()});
        break;
      case 'role':
        _members[ws]?['role'] = '${m['role']}';
        _roster();
        break;
      case 'set':
        queue = List<int>.from(m['queue'] ?? []);
        index = (m['index'] as num?)?.toInt() ?? 0;
        anchorPos = (m['pos'] as num?)?.toInt() ?? 0;
        playing = m['playing'] != false;
        anchorAt = _now() + 900;
        _all(_state());
        break;
      case 'play':
        if (!playing) {
          playing = true;
          anchorAt = _now() + 600;
        }
        _all(_state());
        break;
      case 'pause':
        if (playing) {
          anchorPos = _curPos();
          playing = false;
          anchorAt = _now();
        }
        _all(_state());
        break;
      case 'seek':
        anchorPos = (m['pos'] as num?)?.toInt() ?? 0;
        anchorAt = _now() + (playing ? 600 : 0);
        _all(_state());
        break;
      case 'next':
        _advance(1);
        break;
      case 'prev':
        _advance(-1);
        break;
      case 'ended':
        if ((m['index'] as num?)?.toInt() == index) _advance(1, auto: true);
        break;
    }
  }
}
