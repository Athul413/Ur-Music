import 'package:flutter/material.dart';
import 'client.dart';
import 'main.dart' show Backdrop, kAccent, kCard, toast;
import 'stats.dart';

String _fmt(int ms) {
  final m = ms ~/ 60000;
  if (m >= 60) return '${m ~/ 60} h ${m % 60} min';
  return '$m min';
}

class StatsPage extends StatelessWidget {
  StatsPage({super.key});
  @override
  Widget build(BuildContext context) => Backdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(backgroundColor: Colors.transparent, title: Text('Listening statistics')),
          body: ListenableBuilder(
            listenable: stats,
            builder: (_, __) {
              final now = DateTime.now();
              final week = [for (var i = 6; i >= 0; i--) now.subtract(Duration(days: i))];
              final ms = [for (final d in week) stats.msOnDay(d)];
              final maxMs = ms.fold<int>(1, (a, b) => b > a ? b : a);
              final today = stats.msOnDay(now);
              final weekTotal = ms.fold<int>(0, (a, b) => a + b);
              final top = stats.songs.entries.where((e) => e.value.plays > 0).toList()
                ..sort((a, b) => b.value.plays.compareTo(a.value.plays));
              final artistPlays = <String, int>{};
              for (final e in stats.songs.entries) {
                final s = libraryById[e.key];
                if (s != null) artistPlays[s.artist] = (artistPlays[s.artist] ?? 0) + e.value.plays;
              }
              final artists = artistPlays.entries.where((e) => e.value > 0).toList()
                ..sort((a, b) => b.value.compareTo(a.value));
              Widget card(String t, String v) => Expanded(
                    child: Container(
                      margin: EdgeInsets.all(4),
                      padding: EdgeInsets.all(14),
                      decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(18)),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(v, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                        Text(t, style: TextStyle(color: Colors.white54, fontSize: 12)),
                      ]),
                    ),
                  );
              return ListView(padding: EdgeInsets.all(16), children: [
                Row(children: [card('Today', _fmt(today)), card('Last 7 days', _fmt(weekTotal))]),
                Row(children: [card('All time', _fmt(stats.totalMs)), card('Plays', '${stats.totalPlays}')]),
                SizedBox(height: 14),
                Text('Last 7 days', style: TextStyle(fontWeight: FontWeight.w800)),
                SizedBox(height: 10),
                SizedBox(
                  height: 120,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    for (var i = 0; i < 7; i++)
                      Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                          Container(
                            margin: EdgeInsets.symmetric(horizontal: 6),
                            height: 6 + 90 * ms[i] / maxMs,
                            decoration: BoxDecoration(
                                color: kAccent, borderRadius: BorderRadius.circular(6)),
                          ),
                          SizedBox(height: 4),
                          Text(['M', 'T', 'W', 'T', 'F', 'S', 'S'][week[i].weekday - 1],
                              style: TextStyle(fontSize: 11, color: Colors.white54)),
                        ]),
                      ),
                  ]),
                ),
                SizedBox(height: 18),
                Text('Top songs', style: TextStyle(fontWeight: FontWeight.w800)),
                if (top.isEmpty)
                  Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('Listen to a song for 30 seconds to start counting.',
                          style: TextStyle(color: Colors.white54))),
                for (final e in top.take(8))
                  if (libraryById[e.key] != null)
                    ListTile(
                      dense: true,
                      leading: CoverArt(url: libraryById[e.key]!.coverUrl, size: 40, radius: 8),
                      title: Text(libraryById[e.key]!.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(libraryById[e.key]!.artist, maxLines: 1),
                      trailing: Text('${e.value.plays} plays'),
                    ),
                SizedBox(height: 14),
                Text('Top artists', style: TextStyle(fontWeight: FontWeight.w800)),
                for (final e in artists.take(6))
                  ListTile(dense: true, title: Text(e.key), trailing: Text('${e.value} plays')),
              ]);
            },
          ),
        ),
      );
}

class SmartPage extends StatelessWidget {
  SmartPage({super.key});
  @override
  Widget build(BuildContext context) => Backdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(backgroundColor: Colors.transparent, title: Text('Smart playlists')),
          body: ListenableBuilder(
            listenable: stats,
            builder: (_, __) {
              final lists = smartLists(libraryAll);
              if (lists.isEmpty) {
                return Center(child: Text('Connect to your music first'));
              }
              return ListView(children: [
                for (final l in lists)
                  ListTile(
                    leading: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                          color: kAccent.withAlpha(60), borderRadius: BorderRadius.circular(12)),
                      child: Icon(Icons.auto_awesome),
                    ),
                    title: Text(l.title),
                    subtitle: Text(l.subtitle, style: TextStyle(color: Colors.white54)),
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => SongListPage(
                                title: l.title,
                                subtitle: l.subtitle,
                                coverUrl: l.songs.firstWhere((s) => s.coverUrl != null, orElse: () => l.songs.first).coverUrl,
                                songs: l.songs))),
                  ),
              ]);
            },
          ),
        ),
      );
}

class DuplicatesPage extends StatefulWidget {
  DuplicatesPage({super.key});
  @override
  State<DuplicatesPage> createState() => _DuplicatesPageState();
}

class _DuplicatesPageState extends State<DuplicatesPage> {
  @override
  Widget build(BuildContext context) {
    final groups = findDuplicates(libraryAll);
    return Backdrop(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(backgroundColor: Colors.transparent, title: Text('Duplicate songs')),
        body: groups.isEmpty
            ? Center(child: Text('No duplicates found'))
            : ListView(children: [
                Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                        'Songs with the same title and artist, or the same file size. Hide the copies you do not want - files are never deleted.',
                        style: TextStyle(color: Colors.white60, fontSize: 12.5))),
                for (final g in groups)
                  Container(
                    margin: EdgeInsets.fromLTRB(12, 0, 12, 12),
                    decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(18)),
                    child: Column(children: [
                      for (final s in g)
                        ListTile(
                          dense: true,
                          leading: CoverArt(url: s.coverUrl, size: 40, radius: 8),
                          title: Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(
                              '${s.artist}  -  ${s.isLocal ? 'phone' : 'server'}'
                              '${s.size != null ? '  -  ${(s.size! / 1048576).toStringAsFixed(1)} MB' : ''}',
                              maxLines: 1),
                          trailing: TextButton(
                            onPressed: () {
                              stats.hide(s.id, true);
                              publishLibrary();
                              toast('Hidden from your library');
                              setState(() {});
                            },
                            child: Text('Hide'),
                          ),
                          onTap: () => playSongs([s], 0),
                        ),
                    ]),
                  ),
              ]),
      ),
    );
  }
}

Future<void> showSimilarSheet(BuildContext context, Song s) async {
  final list = similarTo(s, libraryAll);
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: kCard,
    builder: (_) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.7,
      builder: (_, c) => ListView(controller: c, children: [
        ListTile(
            title: Text('Similar songs', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('Based on artist, album, genre and mood of "${s.title}"'),
            trailing: IconButton(
                icon: Icon(Icons.play_arrow, color: kAccent),
                onPressed: list.isEmpty ? null : () => playSongs(list, 0))),
        if (list.isEmpty)
          Padding(padding: EdgeInsets.all(24), child: Text('Nothing similar found yet')),
        for (var i = 0; i < list.length; i++)
          SongTile(song: list[i], onTap: () => playSongs(list, i)),
      ]),
    ),
  );
}
