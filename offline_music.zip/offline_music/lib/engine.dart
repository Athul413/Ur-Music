import 'dart:async';
import 'dart:convert';
import 'dart:math' as m;
import 'package:audio_session/audio_session.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'client.dart' show Song, player, buildSource;
import 'fx.dart';
import 'main.dart' show toast;
import 'party.dart';

/// Playback engineering: ReplayGain, fade between tracks, queue persistence,
/// headphone events.
class PlaybackEngine {
  PlaybackEngine._();
  static final PlaybackEngine I = PlaybackEngine._();

  bool replayGain = true;
  double fadeSec = 0;
  List<int> queueIds = [];
  double _base = 1.0;
  double _lastF = 1.0;
  SharedPreferences? _p;

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    replayGain = _p!.getBool('rg') ?? true;
    fadeSec = _p!.getDouble('fade') ?? 0;
    player.sequenceStateStream.listen(_onTrack);
    player.positionStream.listen(_onPos);
    player.playingStream.listen((_) => save());
    Timer.periodic(Duration(seconds: 10), (_) {
      if (player.playing) save();
    });
    try {
      final s = await AudioSession.instance;
      await s.configure(AudioSessionConfiguration.music());
      s.becomingNoisyEventStream
          .listen((_) => toast('Headphones disconnected - playback paused'));
      s.devicesChangedEventStream.listen((e) {
        final out = e.devicesAdded.where((d) => d.isOutput).toList();
        if (out.isNotEmpty) toast('Audio output connected: ${out.first.name}');
      });
    } catch (_) {}
  }

  void setReplayGain(bool v) {
    replayGain = v;
    _p?.setBool('rg', v);
    _onTrack(player.sequenceState);
  }

  void setFade(double s) {
    fadeSec = s;
    _p?.setDouble('fade', s);
    if (s <= 0) player.setVolume(_base);
  }

  void _onTrack(SequenceState? s) {
    final tag = s?.currentSource?.tag;
    if (tag is! MediaItem) return;
    final g = tag.extras?['gain'];
    var base = 1.0;
    var mb = 0;
    if (replayGain && g is num) {
      final db = g.toDouble().clamp(-15.0, 12.0);
      if (db < 0) {
        base = m.pow(10, db / 20).toDouble();
      } else {
        mb = (db * 100).round();
      }
    }
    _base = base;
    _lastF = 1.0;
    AudioFx.I.setLoudness(mb);
    player.setVolume(base);
    AudioFx.I.onTrack(int.tryParse(tag.id));
    save();
  }

  void _onPos(Duration pos) {
    if (fadeSec <= 0 || PartyClient.I.connected) return;
    final d = player.duration;
    if (d == null) return;
    final cf = fadeSec * 1000;
    final p = pos.inMilliseconds.toDouble();
    final remain = d.inMilliseconds - p;
    var f = 1.0;
    if (remain < cf) f = remain / cf;
    if (p < cf * 0.7) f = m.min(f, p / (cf * 0.7));
    f = f.clamp(0.05, 1.0);
    if ((f - _lastF).abs() > 0.03) {
      _lastF = f;
      player.setVolume(_base * f);
    }
  }

  void save() {
    if (queueIds.isEmpty || PartyClient.I.connected) return;
    _p?.setString(
        'queue_v1',
        jsonEncode({
          'ids': queueIds,
          'i': player.currentIndex ?? 0,
          'pos': player.position.inMilliseconds,
          'loop': player.loopMode.index,
        }));
  }

  /// Restores the last queue (paused) when the app starts.
  Future<void> restore(Map<int, Song> byId) async {
    if (player.audioSource != null) return;
    final raw = _p?.getString('queue_v1');
    if (raw == null) return;
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      final ids = List<int>.from(j['ids']);
      final songs = [for (final id in ids) if (byId[id] != null) byId[id]!];
      if (songs.isEmpty) return;
      final i = (j['i'] as num?)?.toInt() ?? 0;
      final cur = i < ids.length ? ids[i] : null;
      var idx = songs.indexWhere((s) => s.id == cur);
      if (idx < 0) idx = 0;
      queueIds = songs.map((s) => s.id).toList();
      await player.setAudioSource(buildSource(songs),
          initialIndex: idx,
          initialPosition: Duration(milliseconds: (j['pos'] as num?)?.toInt() ?? 0));
      await player.setLoopMode(LoopMode.values[(j['loop'] as num?)?.toInt() ?? 0]);
    } catch (_) {}
  }
}
