import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart' show Backdrop, kAccent, kCard, setAccent, accentValue;

const homeSectionNames = {
  'hero': 'Library card',
  'tools': 'Tools row',
  'recent': 'Recently played',
  'most': 'Most played',
  'mood': 'Moods',
  'albums': 'Albums',
  'artists': 'Artists',
  'songs': 'Songs',
};

/// Which home sections are shown, and in which order.
class HomeLayout extends ChangeNotifier {
  HomeLayout._();
  static final HomeLayout I = HomeLayout._();
  List<String> order = homeSectionNames.keys.toList();
  Set<String> off = {};
  SharedPreferences? _p;

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    final saved = _p!.getStringList('home_order');
    if (saved != null) {
      order = [
        ...saved.where(homeSectionNames.containsKey),
        ...homeSectionNames.keys.where((k) => !saved.contains(k)),
      ];
    }
    off = (_p!.getStringList('home_off') ?? []).toSet();
  }

  void _save() {
    _p?.setStringList('home_order', order);
    _p?.setStringList('home_off', off.toList());
    notifyListeners();
  }

  void move(String id, int d) {
    final i = order.indexOf(id);
    final j = i + d;
    if (i < 0 || j < 0 || j >= order.length) return;
    order.removeAt(i);
    order.insert(j, id);
    _save();
  }

  void toggle(String id) {
    off.contains(id) ? off.remove(id) : off.add(id);
    _save();
  }

  void reset() {
    order = homeSectionNames.keys.toList();
    off = {};
    _save();
  }
}

const accentChoices = [
  0xFFE5383B, 0xFFFF6B35, 0xFFF5B700, 0xFF2EC27E,
  0xFF1DB5C9, 0xFF3A86FF, 0xFF8A5CF6, 0xFFE056A0,
];

class CustomizePage extends StatelessWidget {
  CustomizePage({super.key});
  @override
  Widget build(BuildContext context) => Backdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(backgroundColor: Colors.transparent, title: Text('Personalize')),
          body: ListenableBuilder(
            listenable: HomeLayout.I,
            builder: (_, __) => ListView(padding: EdgeInsets.all(16), children: [
              Text('Accent colour', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              SizedBox(height: 4),
              Text('The app refreshes when you change it.',
                  style: TextStyle(color: Colors.white54, fontSize: 12)),
              SizedBox(height: 12),
              Wrap(spacing: 14, runSpacing: 14, children: [
                for (final c in accentChoices)
                  InkWell(
                    customBorder: CircleBorder(),
                    onTap: () => setAccent(c),
                    child: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(c),
                          border: Border.all(
                              color: accentValue.value == c ? Colors.white : Colors.transparent,
                              width: 3)),
                      child: accentValue.value == c ? Icon(Icons.check, color: Colors.white) : null,
                    ),
                  ),
              ]),
              SizedBox(height: 26),
              Row(children: [
                Expanded(
                    child: Text('Home screen', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                TextButton(onPressed: HomeLayout.I.reset, child: Text('Reset')),
              ]),
              Text('Show, hide and reorder the sections of your home screen.',
                  style: TextStyle(color: Colors.white54, fontSize: 12)),
              SizedBox(height: 8),
              for (final id in HomeLayout.I.order)
                Container(
                  margin: EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(16)),
                  child: ListTile(
                    title: Text(homeSectionNames[id]!),
                    leading: Switch(
                      activeColor: kAccent,
                      value: !HomeLayout.I.off.contains(id),
                      onChanged: (_) => HomeLayout.I.toggle(id),
                    ),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                          icon: Icon(Icons.arrow_upward),
                          onPressed: () => HomeLayout.I.move(id, -1)),
                      IconButton(
                          icon: Icon(Icons.arrow_downward),
                          onPressed: () => HomeLayout.I.move(id, 1)),
                    ]),
                  ),
                ),
            ]),
          ),
        ),
      );
}
