import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

class TagHints {
  final String? genre;
  final double? gain; // ReplayGain track gain in dB
  TagHints(this.genre, this.gain);
}

const _id3Genres =
    'Blues,Classic Rock,Country,Dance,Disco,Funk,Grunge,Hip-Hop,Jazz,Metal,New Age,Oldies,Other,Pop,R&B,Rap,Reggae,Rock,Techno,Industrial,Alternative,Ska,Death Metal,Pranks,Soundtrack,Euro-Techno,Ambient,Trip-Hop,Vocal,Jazz+Funk,Fusion,Trance,Classical,Instrumental,Acid,House,Game,Sound Clip,Gospel,Noise,AlternRock,Bass,Soul,Punk,Space,Meditative,Instrumental Pop,Instrumental Rock,Ethnic,Gothic,Darkwave,Techno-Industrial,Electronic,Pop-Folk,Eurodance,Dream,Southern Rock,Comedy,Cult,Gangsta,Top 40,Christian Rap,Pop/Funk,Jungle,Native American,Cabaret,New Wave,Psychadelic,Rave,Showtunes,Trailer,Lo-Fi,Tribal,Acid Punk,Acid Jazz,Polka,Retro,Musical,Rock & Roll,Hard Rock';

String _decode(Uint8List b) {
  if (b.isEmpty) return '';
  final enc = b[0];
  final d = b.sublist(1);
  if (enc == 1 || enc == 2) {
    final units = <int>[];
    var i = 0;
    var le = enc == 1;
    if (d.length >= 2 && d[0] == 0xFF && d[1] == 0xFE) {
      le = true;
      i = 2;
    } else if (d.length >= 2 && d[0] == 0xFE && d[1] == 0xFF) {
      le = false;
      i = 2;
    }
    for (; i + 1 < d.length; i += 2) {
      units.add(le ? d[i] | (d[i + 1] << 8) : (d[i] << 8) | d[i + 1]);
    }
    return String.fromCharCodes(units).replaceAll('\u0000', '');
  }
  return String.fromCharCodes(d).replaceAll('\u0000', '');
}

String? _cleanGenre(String raw) {
  var g = raw.trim();
  if (g.isEmpty) return null;
  final num = RegExp(r'^\(?(\d{1,3})\)?').firstMatch(g);
  if (num != null) {
    final i = int.parse(num.group(1)!);
    final list = _id3Genres.split(',');
    final rest = g.substring(num.end).trim();
    if (rest.isNotEmpty) return rest;
    return i < list.length ? list[i] : null;
  }
  return g.split(RegExp(r'[;/\u0000]')).first.trim();
}

String? _id3Genre(Uint8List b) {
  if (b.length < 10 || b[0] != 0x49 || b[1] != 0x44 || b[2] != 0x33) return null;
  final ver = b[3];
  final size = (b[6] << 21) | (b[7] << 14) | (b[8] << 7) | b[9];
  var pos = 10;
  final end = min(b.length, 10 + size);
  while (pos + 10 <= end) {
    if (b[pos] == 0) break;
    final id = String.fromCharCodes(b.sublist(pos, pos + 4));
    final fsize = ver == 4
        ? (b[pos + 4] << 21) | (b[pos + 5] << 14) | (b[pos + 6] << 7) | b[pos + 7]
        : (b[pos + 4] << 24) | (b[pos + 5] << 16) | (b[pos + 6] << 8) | b[pos + 7];
    if (fsize <= 0 || pos + 10 + fsize > end) break;
    if (id == 'TCON') {
      return _cleanGenre(_decode(b.sublist(pos + 10, pos + 10 + fsize)));
    }
    pos += 10 + fsize;
  }
  return null;
}

/// Reads genre and ReplayGain from the start of the file (no decoding).
TagHints readTagHints(String path) {
  RandomAccessFile? f;
  try {
    f = File(path).openSync();
    final head = f.readSync(262144);
    final genre = _id3Genre(head);
    final s = String.fromCharCodes(head.where((x) => x != 0));
    final m = RegExp(
            r'replaygain_track_gain[^\d+\-]{0,40}([+\-]?\d+(?:\.\d+)?)\s*db',
            caseSensitive: false)
        .firstMatch(s);
    final gain = m == null ? null : double.tryParse(m.group(1)!);
    return TagHints(genre, gain);
  } catch (_) {
    return TagHints(null, null);
  } finally {
    try {
      f?.closeSync();
    } catch (_) {}
  }
}
