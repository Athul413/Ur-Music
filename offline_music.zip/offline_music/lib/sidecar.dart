import 'dart:io';

const imageExts = {'jpg', 'jpeg', 'png', 'webp'};
const lyricExts = {'lrc', 'txt'};
const genericCovers = [
  'cover', 'folder', 'album', 'front', 'thumbnail', 'thumb', 'artwork', 'art'
];

String _stem(String p) => p.split('/').last.replaceAll(RegExp(r'\.[^.]+$'), '');

/// Finds files that sit next to a song (cover images, lyrics).
/// Matching is case-insensitive.
class Sidecars {
  final _cache = <String, List<String>>{};

  List<String> _files(String dir) => _cache.putIfAbsent(dir, () {
        try {
          return Directory(dir)
              .listSync(followLinks: false)
              .whereType<File>()
              .map((f) => f.path)
              .toList();
        } catch (_) {
          return <String>[];
        }
      });

  /// Order of preference: same name as the song, then the song title,
  /// then generic names (cover.jpg, folder.jpg...), then the only image in the folder.
  String? find(String songPath, Set<String> exts,
      {String? title,
      List<String> generic = const [],
      bool singleFallback = false}) {
    final dir = File(songPath).parent.path;
    final stem = _stem(songPath).toLowerCase();
    final t = (title ?? '').toLowerCase();
    String? byTitle;
    final byGeneric = <String, String>{};
    final all = <String>[];
    for (final p in _files(dir)) {
      final ext = p.split('.').last.toLowerCase();
      if (!exts.contains(ext)) continue;
      final s = _stem(p).toLowerCase();
      if (s == stem) return p;
      if (t.isNotEmpty && s == t) byTitle ??= p;
      if (generic.contains(s)) byGeneric[s] = p;
      all.add(p);
    }
    if (byTitle != null) return byTitle;
    for (final g in generic) {
      if (byGeneric.containsKey(g)) return byGeneric[g];
    }
    if (singleFallback && all.length == 1) return all.first;
    return null;
  }
}
