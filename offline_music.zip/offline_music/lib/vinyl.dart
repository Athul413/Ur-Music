import 'dart:async';
import 'package:flutter/material.dart';
import 'client.dart' show CoverArt, player;
import 'main.dart' show kAccent, kBg, playerStyle;

/// A vinyl record showing the cover in its center. Spins while music plays.
class VinylDisc extends StatefulWidget {
  final String? url;
  final double size;
  final bool alwaysSpin;
  const VinylDisc({super.key, this.url, required this.size, this.alwaysSpin = false});
  @override
  State<VinylDisc> createState() => _VinylDiscState();
}

class _VinylDiscState extends State<VinylDisc>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 9));
  StreamSubscription<bool>? _sub;

  @override
  void initState() {
    super.initState();
    if (widget.alwaysSpin || player.playing) _c.repeat();
    _sub = player.playingStream.listen((p) {
      if (!mounted || widget.alwaysSpin) return;
      if (p) {
        _c.repeat();
      } else {
        _c.stop();
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    return DecoratedBox(
      decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [
        BoxShadow(color: kAccent.withAlpha(70), blurRadius: s * 0.22, spreadRadius: 1),
      ]),
      child: RotationTransition(
        turns: _c,
        child: SizedBox(
          width: s,
          height: s,
          child: Stack(alignment: Alignment.center, children: [
            CustomPaint(size: Size(s, s), painter: _DiscPainter()),
            ClipOval(
              child: SizedBox(
                  width: s * 0.56,
                  height: s * 0.56,
                  child: CoverArt(url: widget.url, radius: 0)),
            ),
            Container(
              width: s * 0.07,
              height: s * 0.07,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: kBg,
                  border: Border.all(color: Colors.white24, width: 1)),
            ),
          ]),
        ),
      ),
    );
  }
}

class _DiscPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final c = Offset(s.width / 2, s.height / 2);
    final r = s.width / 2;
    final rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = const RadialGradient(
                  colors: [Color(0xFF2B2B2B), Color(0xFF050505)])
              .createShader(rect));
    final groove = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.6
      ..color = Colors.white.withAlpha(18);
    for (double f = 0.6; f < 0.97; f += 0.028) {
      canvas.drawCircle(c, r * f, groove);
    }
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = SweepGradient(colors: [
            Colors.transparent,
            Colors.white.withAlpha(32),
            Colors.transparent,
            Colors.white.withAlpha(32),
            Colors.transparent,
          ], stops: const [
            0,
            0.25,
            0.5,
            0.75,
            1
          ]).createShader(rect));
    canvas.drawCircle(
        c,
        r - 1,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = kAccent.withAlpha(170));
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// Shows the cover in the style the user picked: cover, vinyl or turntable.
class DiscView extends StatelessWidget {
  final String? url;
  final double size;
  const DiscView({super.key, this.url, required this.size});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: playerStyle,
        builder: (_, s, __) {
          if (s == 0) return CoverArt(url: url, size: size, radius: size * 0.07);
          if (s == 2) return Turntable(url: url, size: size);
          return VinylDisc(url: url, size: size);
        },
      );
}

/// Vinyl record with a tonearm that swings onto the record while playing.
class Turntable extends StatelessWidget {
  final String? url;
  final double size;
  const Turntable({super.key, this.url, required this.size});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: Stack(children: [
          Positioned(left: 0, bottom: 0, child: VinylDisc(url: url, size: size * 0.86)),
          Positioned(right: 0, top: 0, child: _Tonearm(height: size * 0.7)),
        ]),
      );
}

class _Tonearm extends StatelessWidget {
  final double height;
  const _Tonearm({required this.height});
  @override
  Widget build(BuildContext context) => StreamBuilder<bool>(
        stream: player.playingStream,
        initialData: player.playing,
        builder: (_, s) => AnimatedRotation(
          turns: s.data == true ? 0.05 : -0.04,
          duration: const Duration(milliseconds: 800),
          curve: Curves.easeInOut,
          alignment: const Alignment(0, -0.85),
          child: SizedBox(
              width: height * 0.2,
              height: height,
              child: CustomPaint(painter: _ArmPainter())),
        ),
      );
}

class _ArmPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width, h = s.height;
    final pivot = Offset(w / 2, h * 0.075);
    final arm = Paint()
      ..color = const Color(0xFFC9C9C9)
      ..strokeWidth = w * 0.14
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(pivot, Offset(w / 2, h * 0.86), arm);
    canvas.drawCircle(pivot, w * 0.42, Paint()..color = const Color(0xFF3A3A3A));
    canvas.drawCircle(pivot, w * 0.26, Paint()..color = const Color(0xFF8C8C8C));
    canvas.drawCircle(pivot, w * 0.1, Paint()..color = kBg);
    final head = RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(w / 2, h * 0.9), width: w * 0.55, height: h * 0.1),
        Radius.circular(w * 0.1));
    canvas.drawRRect(head, Paint()..color = const Color(0xFF1B1B1B));
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset(w / 2, h * 0.945), width: w * 0.2, height: h * 0.025),
            Radius.circular(2)),
        Paint()..color = kAccent);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
