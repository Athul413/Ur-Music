import 'dart:async';
import 'package:flutter/material.dart';
import 'client.dart' show CoverArt, player;
import 'main.dart' show kAccent, kBg;

/// A vinyl record showing the cover in its center. Spins while music plays.
class VinylDisc extends StatefulWidget {
  final String? url;
  final double size;
  const VinylDisc({super.key, this.url, required this.size});
  @override
  State<VinylDisc> createState() => _VinylDiscState();
}

class _VinylDiscState extends State<VinylDisc>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 9));
  StreamSubscription<bool>? _sub;

  @override
  void initState() {
    super.initState();
    if (player.playing) _c.repeat();
    _sub = player.playingStream.listen((p) {
      if (!mounted) return;
      if (p) {
        _c.repeat();
      } else {
        _c.stop();
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    return DecoratedBox(
      decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [
        BoxShadow(color: kAccent.withAlpha(70), blurRadius: s * 0.22, spreadRadius: 1),
      ]),
      child: RotationTransition(
        turns: _c,
        child: SizedBox(
          width: s,
          height: s,
          child: Stack(alignment: Alignment.center, children: [
            CustomPaint(size: Size(s, s), painter: _DiscPainter()),
            ClipOval(
              child: SizedBox(
                  width: s * 0.56,
                  height: s * 0.56,
                  child: CoverArt(url: widget.url, radius: 0)),
            ),
            Container(
              width: s * 0.07,
              height: s * 0.07,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: kBg,
                  border: Border.all(color: Colors.white24, width: 1)),
            ),
          ]),
        ),
      ),
    );
  }
}

class _DiscPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final c = Offset(s.width / 2, s.height / 2);
    final r = s.width / 2;
    final rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = const RadialGradient(
                  colors: [Color(0xFF2B2B2B), Color(0xFF050505)])
              .createShader(rect));
    final groove = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.6
      ..color = Colors.white.withAlpha(18);
    for (double f = 0.6; f < 0.97; f += 0.028) {
      canvas.drawCircle(c, r * f, groove);
    }
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = SweepGradient(colors: [
            Colors.transparent,
            Colors.white.withAlpha(32),
            Colors.transparent,
            Colors.white.withAlpha(32),
            Colors.transparent,
          ], stops: const [
            0,
            0.25,
            0.5,
            0.75,
            1
          ]).createShader(rect));
    canvas.drawCircle(
        c,
        r - 1,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = kAccent.withAlpha(170));
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
