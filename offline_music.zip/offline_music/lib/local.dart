import 'dart:convert';
import 'dart:io';
import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'client.dart' show Song;
import 'sidecar.dart';
import 'tagextra.dart';
import 'taghints.dart';

const localExts = {'mp3', 'm4a', 'aac', 'flac', 'ogg', 'opus', 'wav'};

int _hash(String s) {
  var h = 0x811c9dc5;
  for (final b in s.codeUnits) {
    h ^= (b & 0xFF);
    h = (h * 0x01000193) & 0xFFFFFFFF;
  }
  return h;
}

/// Scans music stored on this phone. Local song ids are negative so they never
/// clash with server song ids.
Future<List<Song>> scanLocal(String dir) async {
  final d = Directory(dir);
  if (!await d.exists()) {
    throw Exception('Folder not found: $dir');
  }
  final cache = Directory('${Directory.systemTemp.path}/achufy_covers');
  await cache.create(recursive: true);
  final side = Sidecars();
  final out = <Song>[];
  final seen = <int>{};
  var n = 0;
  final stream = d
      .list(recursive: true, followLinks: false)
      .handleError((_) {}, test: (e) => e is FileSystemException);
  await for (final e in stream) {
    if (e is! File) continue;
    final ext = e.path.split('.').last.toLowerCase();
    if (!localExts.contains(ext)) continue;
    final name = e.uri.pathSegments.last.replaceAll(RegExp(r'\.[^.]+$'), '');
    var title = name, artist = 'Unknown artist', album = 'Unknown album';
    String? coverPath;
    var tags = ExtraTags('', null, null);
    try {
      final m = readMetadata(e, getImage: true);
      tags = extraTags(m);
      if ((m.title ?? '').trim().isNotEmpty) title = m.title!;
      if ((m.artist ?? '').trim().isNotEmpty) artist = m.artist!;
      if ((m.album ?? '').trim().isNotEmpty) album = m.album!;
      if (m.pictures.isNotEmpty) {
        final f = File('${cache.path}/${_hash(e.path)}.jpg');
        if (!await f.exists()) await f.writeAsBytes(m.pictures.first.bytes);
        coverPath = f.path;
      }
    } catch (_) {}
    coverPath ??= side.find(e.path, imageExts,
        title: title, generic: genericCovers, singleFallback: true);
    final size = await e.length();
    final rg = await readReplayGain(e);
    var id = -(_hash(e.path) + 1);
    while (!seen.add(id)) {
      id--;
    }
    out.add(Song(id, title, artist, album, coverPath != null,
        localPath: e.path,
        localCover: coverPath,
        genre: tags.genre.isNotEmpty ? tags.genre : readTagHints(e.path).genre,
        year: tags.year,
        size: size,
        dur: tags.durMs,
        rg: rg));
    if (++n % 15 == 0) await Future.delayed(Duration.zero);
  }
  return out;
}

/// Reads a lyrics file stored next to a local song.
Future<String?> readLocalLyrics(String songPath) async {
  final path = Sidecars().find(songPath, lyricExts);
  if (path == null) return null;
  return utf8.decode(await File(path).readAsBytes(), allowMalformed: true);
}
