import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'client.dart';
import 'local.dart';
import 'main.dart' show kAccent;
import 'output.dart';
import 'vinyl.dart';

class LrcLine {
  final Duration time;
  final String text;
  LrcLine(this.time, this.text);
}

List<LrcLine> parseLrc(String raw) {
  final re = RegExp(r'\[(\d+):(\d+(?:[.:]\d+)?)\]');
  final out = <LrcLine>[];
  for (final line in raw.split(RegExp(r'\r?\n'))) {
    final ms = re.allMatches(line).toList();
    if (ms.isEmpty) continue;
    final text = line.substring(ms.last.end).trim();
    for (final m in ms) {
      final min = int.parse(m.group(1)!);
      final sec = double.parse(m.group(2)!.replaceAll(':', '.'));
      out.add(LrcLine(
          Duration(milliseconds: ((min * 60 + sec) * 1000).round()), text));
    }
  }
  out.sort((a, b) => a.time.compareTo(b.time));
  return out;
}

String fmt(Duration d) {
  final m = d.inMinutes;
  final s = d.inSeconds % 60;
  return '$m:${s.toString().padLeft(2, '0')}';
}

class NowPlayingPage extends StatefulWidget {
  const NowPlayingPage({super.key});
  @override
  State<NowPlayingPage> createState() => _NowPlayingPageState();
}

class _NowPlayingPageState extends State<NowPlayingPage> {
  static const double _lineH = 56;
  bool _showLyrics = false;
  bool _loaded = false;
  List<LrcLine> _lrc = [];
  String? _plain;
  String? _lyricsFor;
  int _lastIdx = -1;
  StreamSubscription<SequenceState?>? _sub;
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    store.addListener(_rebuild);
    _sub = player.sequenceStateStream.listen((s) {
      final tag = s?.currentSource?.tag;
      if (tag is MediaItem && tag.id != _lyricsFor) {
        _loadLyrics(tag.id, tag.extras?['path'] as String?);
      }
    });
  }

  @override
  void dispose() {
    store.removeListener(_rebuild);
    _sub?.cancel();
    _scroll.dispose();
    super.dispose();
  }

  void _rebuild() {
    if (mounted) setState(() {});
  }

  Future<void> _loadLyrics(String id, [String? localPath]) async {
    _lyricsFor = id;
    _lastIdx = -1;
    if (mounted) {
      setState(() {
        _lrc = [];
        _plain = null;
        _loaded = false;
      });
    }
    try {
      String? txt;
      if (localPath != null) {
        txt = await readLocalLyrics(localPath);
      } else {
        final r = await http
            .get(Uri.parse('$base/lyrics/$id'))
            .timeout(const Duration(seconds: 8));
        if (r.statusCode == 200) {
          txt = utf8.decode(r.bodyBytes, allowMalformed: true);
        }
      }
      if (_lyricsFor != id) return;
      if (txt != null) {
        final l = parseLrc(txt);
        if (mounted) {
          setState(() {
            if (l.isNotEmpty) {
              _lrc = l;
            } else {
              _plain = txt;
            }
          });
        }
      }
    } catch (_) {}
    if (mounted && _lyricsFor == id) setState(() => _loaded = true);
  }

  Widget _lyricsView() {
    if (!_loaded) {
      return const Center(child: CircularProgressIndicator(color: kAccent));
    }
    if (_lrc.isEmpty && _plain == null) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
              'No lyrics found.\nPut a .lrc or .txt file with the same name as the song in the same folder on the server phone.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70)),
        ),
      );
    }
    if (_lrc.isEmpty) {
      return SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Text(_plain!,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 20, height: 1.6, fontWeight: FontWeight.w600)),
      );
    }
    return LayoutBuilder(builder: (_, box) {
      final pad = (box.maxHeight - _lineH) / 2;
      return StreamBuilder<Duration>(
        stream: player.positionStream,
        builder: (_, snap) {
          final pos = snap.data ?? Duration.zero;
          var idx = -1;
          for (var i = 0; i < _lrc.length; i++) {
            if (_lrc[i].time <= pos) {
              idx = i;
            } else {
              break;
            }
          }
          if (idx != _lastIdx) {
            _lastIdx = idx;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (_scroll.hasClients && idx >= 0) {
                _scroll.animateTo(idx * _lineH,
                    duration: const Duration(milliseconds: 350),
                    curve: Curves.easeOut);
              }
            });
          }
          return ListView.builder(
            controller: _scroll,
            padding: EdgeInsets.symmetric(vertical: pad < 0 ? 0 : pad),
            itemExtent: _lineH,
            itemCount: _lrc.length,
            itemBuilder: (_, i) => GestureDetector(
              onTap: () => player.seek(_lrc[i].time),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Text(_lrc[i].text.isEmpty ? '\u266A' : _lrc[i].text,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: i == idx ? 24 : 20,
                          fontWeight: FontWeight.w800,
                          color: i == idx ? Colors.white : Colors.white38)),
                ),
              ),
            ),
          );
        },
      );
    });
  }

  Widget _seekBar() => StreamBuilder<Duration>(
        stream: player.positionStream,
        builder: (_, snap) {
          final total = (player.duration ?? Duration.zero);
          final pos = snap.data ?? Duration.zero;
          final max = total.inMilliseconds.toDouble();
          return Column(children: [
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                  trackHeight: 3,
                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                  activeTrackColor: Colors.white,
                  inactiveTrackColor: Colors.white24,
                  thumbColor: Colors.white),
              child: Slider(
                value: max == 0 ? 0 : pos.inMilliseconds.clamp(0, max.toInt()).toDouble(),
                max: max == 0 ? 1 : max,
                onChanged: (v) => player.seek(Duration(milliseconds: v.toInt())),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(fmt(pos), style: const TextStyle(color: Colors.white60, fontSize: 12)),
                Text(fmt(total), style: const TextStyle(color: Colors.white60, fontSize: 12)),
              ]),
            ),
          ]);
        },
      );

  Widget _controls() => Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        StreamBuilder<bool>(
          stream: player.shuffleModeEnabledStream,
          builder: (_, s) => IconButton(
            icon: Icon(Icons.shuffle, color: s.data == true ? kAccent : Colors.white70),
            onPressed: () async {
              final on = !(s.data ?? false);
              await player.setShuffleModeEnabled(on);
              if (on) await player.shuffle();
            },
          ),
        ),
        IconButton(
            iconSize: 40,
            icon: const Icon(Icons.skip_previous),
            onPressed: player.seekToPrevious),
        StreamBuilder<bool>(
          stream: player.playingStream,
          builder: (_, s) => Container(
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: IconButton(
              iconSize: 42,
              color: Colors.black,
              icon: Icon(s.data == true ? Icons.pause : Icons.play_arrow),
              onPressed: s.data == true ? player.pause : player.play,
            ),
          ),
        ),
        IconButton(
            iconSize: 40,
            icon: const Icon(Icons.skip_next),
            onPressed: player.seekToNext),
        StreamBuilder<LoopMode>(
          stream: player.loopModeStream,
          builder: (_, s) {
            final m = s.data ?? LoopMode.off;
            return IconButton(
              icon: Icon(m == LoopMode.one ? Icons.repeat_one : Icons.repeat,
                  color: m == LoopMode.off ? Colors.white70 : kAccent),
              onPressed: () => player.setLoopMode(m == LoopMode.off
                  ? LoopMode.all
                  : (m == LoopMode.all ? LoopMode.one : LoopMode.off)),
            );
          },
        ),
      ]);

  @override
  Widget build(BuildContext context) => StreamBuilder<SequenceState?>(
        stream: player.sequenceStateStream,
        builder: (_, snap) {
          final tag = snap.data?.currentSource?.tag;
          if (tag is! MediaItem) {
            return const Scaffold(body: Center(child: Text('Nothing playing')));
          }
          final id = int.tryParse(tag.id) ?? -1;
          return Scaffold(
            body: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFF6B1119), Color(0xFF0A0506)],
                    stops: [0, 0.7]),
              ),
              child: SafeArea(
                child: Column(children: [
                  Row(children: [
                    IconButton(
                        icon: const Icon(Icons.keyboard_arrow_down, size: 32),
                        onPressed: () => Navigator.pop(context)),
                    Expanded(
                        child: Text(tag.album ?? '',
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600))),
                    IconButton(
                        icon: const Icon(Icons.speaker_group_outlined),
                        onPressed: () => showOutputSheet(context)),
                    IconButton(
                        icon: Icon(Icons.lyrics,
                            color: _showLyrics ? kAccent : Colors.white),
                        onPressed: () => setState(() => _showLyrics = !_showLyrics)),
                  ]),
                  Expanded(
                    child: _showLyrics
                        ? _lyricsView()
                        : LayoutBuilder(builder: (_, box) {
                            final side = (box.maxWidth < box.maxHeight
                                    ? box.maxWidth
                                    : box.maxHeight) -
                                48;
                            return Center(
                                child: VinylDisc(
                                    url: tag.artUri?.toString(),
                                    size: side < 140 ? 140 : side));
                          }),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 8, 8, 0),
                    child: Row(children: [
                      Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          Text(tag.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 22, fontWeight: FontWeight.w800)),
                          Text(tag.artist ?? '',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white70)),
                        ]),
                      ),
                      IconButton(
                        icon: Icon(
                            store.liked(id) ? Icons.favorite : Icons.favorite_border,
                            color: store.liked(id) ? kAccent : Colors.white70),
                        onPressed: () => store.toggleLike(id),
                      ),
                    ]),
                  ),
                  _seekBar(),
                  _controls(),
                  const SizedBox(height: 16),
                ]),
              ),
            ),
          );
        },
      );
}
