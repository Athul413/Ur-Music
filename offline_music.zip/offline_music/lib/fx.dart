import 'dart:async';
import 'dart:convert';
import 'dart:math' as m;
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'client.dart' show player;

const kBandFreqs = [31.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0];
const kBandLabels = ['31', '62', '125', '250', '500', '1k', '2k', '4k', '8k', '16k'];

const kPresets = <String, List<double>>{
  'Flat': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  'Rock': [4, 3, 2, 0, -1, -1, 1, 3, 4, 4],
  'Jazz': [3, 2, 1, 2, -2, -2, 0, 1, 2, 3],
  'Classical': [3, 2, 1, 0, 0, 0, -1, 2, 3, 3],
  'Pop': [-1, 0, 2, 3, 3, 2, 0, -1, -1, -2],
  'Bass': [7, 6, 5, 3, 1, 0, 0, 0, 0, 0],
  'Vocal': [-2, -2, -1, 1, 3, 4, 3, 1, 0, -1],
  'Electronic': [4, 3, 0, -1, -2, 0, 1, 3, 4, 4],
};
const _karaoke = <double>[2, 2, 0, -4, -8, -10, -8, -4, 1, 2];
const _roleGains = <String, List<double>>{
  'bass': [8, 8, 6, 2, -4, -8, -10, -12, -12, -12],
  'treble': [-12, -12, -10, -6, -2, 2, 4, 5, 5, 5],
  'mid': [-10, -8, -4, 2, 5, 5, 3, 0, -4, -8],
};

/// Audio effects (equalizer, bass, virtualizer, loudness) and the spectrum.
class AudioFx extends ChangeNotifier {
  AudioFx._();
  static final AudioFx I = AudioFx._();
  static const _ch = MethodChannel('achufy/fx');
  static const _ev = EventChannel('achufy/fft');

  bool available = false, bassOk = false, virtOk = false;
  int bands = 0, minL = -1500, maxL = 1500;
  List<double> freqs = [];
  bool eqOn = true;
  String preset = 'Flat';
  List<double> gains = List.filled(10, 0.0);
  List<double> custom = List.filled(10, 0.0);
  double bass = 0, virt = 0;
  bool karaoke = false;
  String role = 'full';
  int? songId;
  SharedPreferences? _p;
  Map<String, dynamic> _songs = {};
  Map<String, dynamic>? _globalSnap;
  int? _session;
  int vizStyle = 0;

  bool get hasSongProfile => songId != null && _songs.containsKey('$songId');

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    final raw = _p!.getString('fx_v1');
    if (raw != null) {
      try {
        final j = jsonDecode(raw) as Map<String, dynamic>;
        _load(j);
        custom = List<double>.from((j['custom'] as List).map((e) => (e as num).toDouble()));
        eqOn = j['eqOn'] != false;
      } catch (_) {}
    }
    try {
      _songs = jsonDecode(_p!.getString('fx_songs_v1') ?? '{}') as Map<String, dynamic>;
    } catch (_) {}
    vizStyle = _p!.getInt('viz_style') ?? 0;
    player.androidAudioSessionIdStream.listen(_onSession);
    _onSession(player.androidAudioSessionId);
  }

  void _load(Map<String, dynamic> j) {
    gains = List<double>.from((j['gains'] as List).map((e) => (e as num).toDouble()));
    preset = '${j['preset'] ?? 'Custom'}';
    bass = (j['bass'] as num?)?.toDouble() ?? 0;
    virt = (j['virt'] as num?)?.toDouble() ?? 0;
  }

  Map<String, dynamic> _snap() =>
      {'gains': gains, 'preset': preset, 'bass': bass, 'virt': virt};

  Future<void> _onSession(int? id) async {
    if (id == null || id == _session) return;
    _session = id;
    try {
      final r = await _ch.invokeMethod<Map>('attach', {'session': id});
      if (r == null) return;
      bands = (r['bands'] as num).toInt();
      minL = (r['min'] as num).toInt();
      maxL = (r['max'] as num).toInt();
      freqs = (r['freqs'] as List).map((e) => (e as num).toDouble()).toList();
      bassOk = r['bass'] == true;
      virtOk = r['virt'] == true;
      available = bands > 0;
      await _push();
    } catch (_) {}
    notifyListeners();
  }

  List<double> get _effGains {
    if (role != 'full' && _roleGains.containsKey(role)) return _roleGains[role]!;
    if (karaoke) return _karaoke;
    return gains;
  }

  double get _effBass => role == 'bass' ? 0.8 : bass;

  double _interp(List<double> g, double f) {
    if (f <= kBandFreqs.first) return g.first;
    if (f >= kBandFreqs.last) return g.last;
    for (var i = 0; i < 9; i++) {
      if (f <= kBandFreqs[i + 1]) {
        final a = m.log(kBandFreqs[i]), b = m.log(kBandFreqs[i + 1]);
        final t = (m.log(f) - a) / (b - a);
        return g[i] * (1 - t) + g[i + 1] * t;
      }
    }
    return 0;
  }

  Future<void> _push() async {
    if (!available) return;
    final g = _effGains;
    final levels = [
      for (final f in freqs) (_interp(g, f) * 100).round().clamp(minL, maxL)
    ];
    try {
      await _ch.invokeMethod('setEq', {'levels': levels, 'on': eqOn});
      await _ch.invokeMethod('setBass', {'v': (_effBass * 1000).round()});
      await _ch.invokeMethod('setVirt', {'v': (virt * 1000).round()});
    } catch (_) {}
  }

  void _save() {
    if (hasSongProfile) {
      _songs['$songId'] = _snap();
      _p?.setString('fx_songs_v1', jsonEncode(_songs));
    } else {
      _p?.setString('fx_v1', jsonEncode({..._snap(), 'custom': custom, 'eqOn': eqOn}));
    }
  }

  void _changed() {
    _save();
    _push();
    notifyListeners();
  }

  void setGain(int i, double v) {
    gains = List.of(gains)..[i] = v.clamp(-12.0, 12.0);
    preset = 'Custom';
    custom = List.of(gains);
    _changed();
  }

  void setPreset(String name) {
    preset = name;
    gains = name == 'Custom' ? List.of(custom) : List.of(kPresets[name]!);
    _changed();
  }

  void setBass(double v) {
    bass = v;
    _changed();
  }

  void setVirt(double v) {
    virt = v;
    _changed();
  }

  void setEqOn(bool v) {
    eqOn = v;
    _changed();
  }

  void setKaraoke(bool v) {
    karaoke = v;
    _push();
    notifyListeners();
  }

  void setRole(String r) {
    role = r;
    _push();
    notifyListeners();
  }

  void toggleSongProfile(bool on) {
    if (songId == null) return;
    if (on) {
      _songs['$songId'] = _snap();
      _p?.setString('fx_songs_v1', jsonEncode(_songs));
    } else {
      _songs.remove('$songId');
      _p?.setString('fx_songs_v1', jsonEncode(_songs));
      if (_globalSnap != null) _load(_globalSnap!);
      _push();
    }
    notifyListeners();
  }

  /// Called when the track changes: applies the per-song profile if any.
  void onTrack(int? id) {
    if (!hasSongProfile) _globalSnap = _snap();
    songId = id;
    if (hasSongProfile) {
      _load(_songs['$id'] as Map<String, dynamic>);
    } else if (_globalSnap != null) {
      _load(_globalSnap!);
    }
    _push();
    notifyListeners();
  }

  Future<void> setLoudness(int mb) async {
    try {
      await _ch.invokeMethod('setLoud', {'mb': mb});
    } catch (_) {}
  }

  void setVizStyle(int s) {
    vizStyle = s;
    _p?.setInt('viz_style', s);
    notifyListeners();
  }

  // ---- spectrum ----
  final fft = ValueNotifier<List<double>>(List.filled(48, 0.0));
  int _users = 0;
  StreamSubscription? _sub;

  Future<bool> acquireViz() async {
    _users++;
    if (_users > 1) return true;
    var ok = false;
    try {
      ok = await Permission.microphone.request().isGranted;
      if (ok) ok = await _ch.invokeMethod<bool>('startViz') ?? false;
    } catch (_) {}
    if (!ok) {
      _users--;
      return false;
    }
    _sub = _ev.receiveBroadcastStream().listen((e) {
      final l = (e as List).map((x) => (x as num).toDouble() / 255.0).toList();
      final prev = fft.value;
      fft.value = [
        for (var i = 0; i < l.length; i++)
          (i < prev.length ? prev[i] * 0.55 : 0.0) + l[i] * 0.45
      ];
    }, onError: (_) {});
    return true;
  }

  void releaseViz() {
    if (_users > 0) _users--;
    if (_users == 0) {
      _sub?.cancel();
      _sub = null;
      try {
        _ch.invokeMethod('stopViz');
      } catch (_) {}
    }
  }

  Future<Map<String, dynamic>?> audioInfo(String src) async {
    try {
      final s = src.startsWith('file:') ? Uri.parse(src).toFilePath() : src;
      final r = await _ch.invokeMethod<Map>('audioInfo', {'src': s});
      return r?.map((k, v) => MapEntry('$k', v));
    } catch (_) {
      return null;
    }
  }
}
