import 'dart:async';
import 'dart:convert';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'client.dart' show Song, player;
import 'fx.dart';
import 'package:flutter/foundation.dart';

class SongStat {
  int plays = 0, last = 0, ms = 0;
}

/// Listening history, statistics and music intelligence.
class StatsStore extends ChangeNotifier {
  StatsStore._();
  static final StatsStore I = StatsStore._();

  final Map<int, SongStat> songs = {};
  final Map<String, int> days = {};
  final List<int> recent = [];
  final Map<int, String> genres = {};
  final Set<int> hidden = {};
  SharedPreferences? _p;
  int? _cur;
  int _curMs = 0;
  bool _counted = false;
  int _dirty = 0;

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    try {
      final j = jsonDecode(_p!.getString('stats_v1') ?? '{}') as Map<String, dynamic>;
      (j['songs'] as Map? ?? {}).forEach((k, v) {
        final s = SongStat()
          ..plays = (v['p'] as num).toInt()
          ..last = (v['l'] as num).toInt()
          ..ms = (v['m'] as num).toInt();
        songs[int.parse('$k')] = s;
      });
      (j['days'] as Map? ?? {}).forEach((k, v) => days['$k'] = (v as num).toInt());
      recent.addAll(List<int>.from(j['recent'] ?? []));
      (j['genres'] as Map? ?? {}).forEach((k, v) => genres[int.parse('$k')] = '$v');
      hidden.addAll(List<int>.from(j['hidden'] ?? []));
    } catch (_) {}
    player.sequenceStateStream.listen(_onTrack);
    Timer.periodic(Duration(seconds: 1), (_) => _tick());
  }

  Future<void> _onTrack(SequenceState? s) async {
    final tag = s?.currentSource?.tag;
    if (tag is! MediaItem) return;
    final id = int.tryParse(tag.id);
    if (id == _cur) return;
    _save();
    _cur = id;
    _curMs = 0;
    _counted = false;
    final src = s?.currentSource;
    if (id != null && !genres.containsKey(id) && src is UriAudioSource) {
      final info = await AudioFx.I.audioInfo(src.uri.toString());
      final g = info?['genre'];
      if (g is String && g.trim().isNotEmpty) {
        genres[id] = g.trim();
        _dirty++;
      }
    }
  }

  String _dayKey([DateTime? d]) {
    final t = d ?? DateTime.now();
    return '${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
  }

  void _tick() {
    final id = _cur;
    if (id == null || !player.playing) return;
    final st = songs.putIfAbsent(id, () => SongStat());
    st.ms += 1000;
    final k = _dayKey();
    days[k] = (days[k] ?? 0) + 1000;
    _curMs += 1000;
    if (!_counted && _curMs >= 30000) {
      _counted = true;
      st.plays++;
      st.last = DateTime.now().millisecondsSinceEpoch;
      recent.remove(id);
      recent.insert(0, id);
      if (recent.length > 60) recent.removeLast();
      notifyListeners();
    }
    if (++_dirty >= 20) _save();
  }

  void _save() {
    _dirty = 0;
    _p?.setString(
        'stats_v1',
        jsonEncode({
          'songs': {for (final e in songs.entries) '${e.key}': {'p': e.value.plays, 'l': e.value.last, 'm': e.value.ms}},
          'days': days,
          'recent': recent,
          'genres': {for (final e in genres.entries) '${e.key}': e.value},
          'hidden': hidden.toList(),
        }));
  }

  void hide(int id, bool on) {
    on ? hidden.add(id) : hidden.remove(id);
    _save();
    notifyListeners();
  }

  int get totalMs => days.values.fold(0, (a, b) => a + b);
  int get totalPlays => songs.values.fold(0, (a, b) => a + b.plays);
  int msOnDay(DateTime d) => days[_dayKey(d)] ?? 0;
}

final stats = StatsStore.I;

// ---------------- mood ----------------
const moods = ['Energetic', 'Party', 'Happy', 'Chill', 'Focus', 'Sad'];

bool _has(String t, List<String> k) => k.any((e) => t.contains(e));

String moodOf(Song s) {
  final g = (s.genre ?? stats.genres[s.id] ?? '').toLowerCase();
  final t = '${s.title} ${s.album}'.toLowerCase();
  if (_has(g, ['metal', 'punk', 'hard rock', 'rock', 'techno', 'trance', 'hardcore', 'grunge', 'industrial'])) return 'Energetic';
  if (_has(g, ['dance', 'disco', 'house', 'club', 'edm', 'hip', 'rap', 'reggaeton', 'eurodance', 'rave'])) return 'Party';
  if (_has(g, ['classical', 'instrumental', 'soundtrack', 'jazz', 'piano', 'meditat', 'new age'])) return 'Focus';
  if (_has(g, ['ambient', 'lounge', 'lo-fi', 'lofi', 'chill', 'acoustic', 'folk', 'easy', 'soft'])) return 'Chill';
  if (_has(g, ['blues', 'soul', 'gothic', 'darkwave'])) return 'Sad';
  if (_has(g, ['pop', 'funk', 'reggae', 'latin', 'country', 'r&b', 'top 40'])) return 'Happy';
  if (_has(t, ['party', 'dance', 'club', 'remix', 'bass'])) return 'Party';
  if (_has(t, ['sad', 'cry', 'tears', 'lonely', 'goodbye', 'broken', 'alone', 'rain', 'hurt'])) return 'Sad';
  if (_has(t, ['happy', 'sun', 'summer', 'smile', 'joy', 'dance'])) return 'Happy';
  if (_has(t, ['chill', 'calm', 'sleep', 'dream', 'night', 'acoustic', 'slow'])) return 'Chill';
  if (_has(t, ['fire', 'war', 'power', 'rock', 'fight'])) return 'Energetic';
  return 'Happy';
}

Set<String> _words(String s) => s
    .toLowerCase()
    .split(RegExp(r'[^a-z0-9]+'))
    .where((w) => w.length > 3)
    .toSet();

/// Similar songs from local metadata (artist, album, genre, mood, title words).
List<Song> similarTo(Song s, List<Song> all, {int limit = 25}) {
  final g = (s.genre ?? stats.genres[s.id] ?? '').toLowerCase();
  final mood = moodOf(s);
  final w1 = _words(s.title);
  final scored = <MapEntry<Song, int>>[];
  for (final o in all) {
    if (o.id == s.id) continue;
    var sc = 0;
    if (s.artist != 'Unknown artist' && o.artist == s.artist) sc += 5;
    if (s.album != 'Unknown album' && o.album == s.album) sc += 4;
    final og = (o.genre ?? stats.genres[o.id] ?? '').toLowerCase();
    if (g.isNotEmpty && og == g) sc += 3;
    if (moodOf(o) == mood) sc += 2;
    sc += w1.intersection(_words(o.title)).length;
    if (sc > 2) scored.add(MapEntry(o, sc));
  }
  scored.sort((a, b) => b.value.compareTo(a.value));
  return scored.take(limit).map((e) => e.key).toList();
}

String _norm(String s) => s
    .toLowerCase()
    .replaceAll(RegExp(r'\(.*?\)|\[.*?\]'), '')
    .replaceAll(RegExp(r'[^a-z0-9]+'), ' ')
    .trim();

/// Groups of songs that look like duplicates (same title+artist, or same file size).
List<List<Song>> findDuplicates(List<Song> all) {
  final byName = <String, List<Song>>{};
  for (final s in all) {
    byName.putIfAbsent('${_norm(s.title)}|${_norm(s.artist)}', () => []).add(s);
  }
  final out = <List<Song>>[for (final g in byName.values) if (g.length > 1) g];
  final used = {for (final g in out) for (final s in g) s.id};
  final bySize = <int, List<Song>>{};
  for (final s in all) {
    if ((s.size ?? 0) > 100000 && !used.contains(s.id)) {
      bySize.putIfAbsent(s.size!, () => []).add(s);
    }
  }
  out.addAll([for (final g in bySize.values) if (g.length > 1) g]);
  return out;
}

class SmartList {
  final String title, subtitle;
  final List<Song> songs;
  SmartList(this.title, this.subtitle, this.songs);
}

List<SmartList> smartLists(List<Song> all) {
  final by = {for (final s in all) s.id: s};
  final now = DateTime.now().millisecondsSinceEpoch;
  final recent = [for (final id in stats.recent) if (by[id] != null) by[id]!];
  final played = all.where((s) => (stats.songs[s.id]?.plays ?? 0) > 0).toList()
    ..sort((a, b) => stats.songs[b.id]!.plays.compareTo(stats.songs[a.id]!.plays));
  final forgotten = played
      .where((s) =>
          stats.songs[s.id]!.plays >= 3 &&
          now - stats.songs[s.id]!.last > 14 * 86400000)
      .toList();
  final never = all.where((s) => (stats.songs[s.id]?.plays ?? 0) == 0).toList()..shuffle();
  // daily mix: favourite artists + similar songs
  final artistMs = <String, int>{};
  for (final s in played) {
    artistMs[s.artist] = (artistMs[s.artist] ?? 0) + stats.songs[s.id]!.ms;
  }
  final top = artistMs.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
  final favArtists = top.take(4).map((e) => e.key).toSet();
  final mix = all.where((s) => favArtists.contains(s.artist)).toList()..shuffle();
  final lists = <SmartList>[
    if (recent.isNotEmpty) SmartList('Recently played', '${recent.length} songs', recent),
    if (played.isNotEmpty)
      SmartList('Most played', 'Your favourites', played.take(50).toList()),
    if (forgotten.isNotEmpty)
      SmartList('Forgotten favourites', 'Loved, but not played lately', forgotten),
    if (mix.isNotEmpty) SmartList('Daily mix', 'Built from your top artists', mix.take(40).toList()),
    if (never.isNotEmpty)
      SmartList('Never played', 'Discover your own library', never.take(100).toList()),
  ];
  for (final m in moods) {
    final l = all.where((s) => moodOf(s) == m).toList();
    if (l.isNotEmpty) lists.add(SmartList('$m mood', '${l.length} songs', l));
  }
  return lists;
}
