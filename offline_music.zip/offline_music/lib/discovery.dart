import 'dart:async';
import 'dart:convert';
import 'dart:io';

const kDiscoveryPort = 48123;

class Found {
  final String host;
  final int port;
  final String name;
  Found(this.host, this.port, this.name);
}

/// Finds Achufy servers on the local network without typing an address.
/// 1) UDP broadcast  2) fallback: probe every address on the subnet.
Future<List<Found>> discoverServers() async {
  final found = <String, Found>{};
  RawDatagramSocket? s;
  try {
    s = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    s.broadcastEnabled = true;
    final sock = s;
    sock.listen((e) {
      if (e != RawSocketEvent.read) return;
      final d = sock.receive();
      if (d == null) return;
      final m = utf8.decode(d.data, allowMalformed: true);
      if (!m.startsWith('ACHUFY|')) return;
      final p = m.split('|');
      final port = int.tryParse(p.length > 1 ? p[1] : '') ?? 8080;
      found['${d.address.address}:$port'] =
          Found(d.address.address, port, p.length > 2 ? p[2] : 'Achufy server');
    });
    final msg = utf8.encode('ACHUFY?');
    for (var round = 0; round < 3; round++) {
      try {
        sock.send(msg, InternetAddress('255.255.255.255'), kDiscoveryPort);
      } catch (_) {}
      for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
        for (final a in i.addresses) {
          final o = a.rawAddress;
          if (o.length == 4 && !a.isLoopback) {
            try {
              sock.send(msg, InternetAddress('${o[0]}.${o[1]}.${o[2]}.255'), kDiscoveryPort);
            } catch (_) {}
          }
        }
      }
      await Future.delayed(const Duration(milliseconds: 900));
    }
  } catch (_) {
  } finally {
    s?.close();
  }
  if (found.isNotEmpty) return found.values.toList();
  return _sweep();
}

Future<List<Found>> _sweep() async {
  final subnets = <String>{};
  try {
    for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
      for (final a in i.addresses) {
        if (a.isLoopback) continue;
        final p = a.address.split('.');
        subnets.add('${p[0]}.${p[1]}.${p[2]}');
      }
    }
  } catch (_) {}
  final out = <Found>[];
  final c = HttpClient()..connectionTimeout = const Duration(milliseconds: 700);
  Future<void> probe(String ip) async {
    try {
      final req = await c
          .getUrl(Uri.parse('http://$ip:8080/api/ping'))
          .timeout(const Duration(seconds: 1));
      final res = await req.close().timeout(const Duration(seconds: 1));
      final body = await res.transform(utf8.decoder).join();
      if (body.startsWith('achufy')) {
        final i = body.indexOf(':');
        out.add(Found(ip, 8080, i < 0 ? 'Achufy server' : body.substring(i + 1)));
      }
    } catch (_) {}
  }

  for (final s in subnets) {
    final ips = [for (var i = 1; i < 255; i++) '$s.$i'];
    for (var k = 0; k < ips.length; k += 64) {
      await Future.wait(ips.skip(k).take(64).map(probe));
    }
  }
  c.close(force: true);
  return out;
}
