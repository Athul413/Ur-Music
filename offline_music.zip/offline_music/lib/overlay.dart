import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'client.dart' show player;
import 'lyrics.dart';
import 'main.dart' show toast;
import 'now_playing.dart' show LrcLine, parseLrc;

const _oc = MethodChannel('achufy/overlay');

/// Lyrics in a small floating window above other apps.
class FloatingLyrics {
  static final enabled = ValueNotifier<bool>(false);
  static StreamSubscription<SequenceState?>? _a;
  static StreamSubscription<Duration>? _b;
  static StreamSubscription<ProcessingState>? _c;
  static bool _wasActive = false;
  static List<LrcLine> _lrc = [];
  static String? _forId;
  static int _idx = -2;

  /// Call once at startup so the ✕ button on the floating window works.
  static void init() {
    _oc.setMethodCallHandler((call) async {
      if (call.method == 'closed') await _teardown();
      return null;
    });
  }

  static Future<void> _teardown() async {
    await _a?.cancel();
    await _b?.cancel();
    await _c?.cancel();
    _a = null;
    _b = null;
    _c = null;
    enabled.value = false;
  }

  static Future<bool> toggle() async {
    if (enabled.value) {
      await stop();
      return false;
    }
    return start();
  }

  static Future<bool> start() async {
    bool ok = false;
    try {
      ok = await _oc.invokeMethod<bool>('show') ?? false;
    } catch (_) {}
    if (!ok) {
      toast('Turn on "Display over other apps" for Achufy, then tap again.');
      return false;
    }
    enabled.value = true;
    _forId = null;
    _a = player.sequenceStateStream.listen(_onTrack);
    _b = player.positionStream.listen(_onPos);
    _wasActive = player.processingState != ProcessingState.idle;
    // Close the window automatically when playback is stopped / dismissed.
    _c = player.processingStateStream.listen((s) {
      if (s != ProcessingState.idle) {
        _wasActive = true;
      } else if (_wasActive) {
        stop();
      }
    });
    return true;
  }

  static Future<void> stop() async {
    await _teardown();
    try {
      await _oc.invokeMethod('hide');
    } catch (_) {}
  }

  static Future<void> _push(String a, String b) async {
    try {
      await _oc.invokeMethod('update', {'a': a, 'b': b});
    } catch (_) {}
  }

  static Future<void> _onTrack(SequenceState? s) async {
    final tag = s?.currentSource?.tag;
    if (tag is! MediaItem || tag.id == _forId) return;
    final id = tag.id;
    _forId = id;
    _lrc = [];
    _idx = -2;
    final artist = tag.artist ?? '';
    await _push(tag.title, artist);
    final txt = await fetchLyrics(id, tag.extras?['path'] as String?);
    if (_forId != id) return;
    if (txt != null) _lrc = parseLrc(txt);
    if (_lrc.isEmpty) {
      await _push(tag.title, artist.isEmpty ? 'No synced lyrics' : '$artist  -  no synced lyrics');
    }
  }

  static void _onPos(Duration pos) {
    if (_lrc.isEmpty) return;
    var idx = -1;
    for (var i = 0; i < _lrc.length; i++) {
      if (_lrc[i].time <= pos) {
        idx = i;
      } else {
        break;
      }
    }
    if (idx == _idx) return;
    _idx = idx;
    final cur = idx < 0 || _lrc[idx].text.isEmpty ? '\u266A' : _lrc[idx].text;
    final next = idx + 1 < _lrc.length ? _lrc[idx + 1].text : '';
    _push(cur, next);
  }
}
