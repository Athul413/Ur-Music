import 'package:flutter/material.dart';
import 'client.dart';
import 'discovery.dart';
import 'main.dart' show kAccent, kCard, toast;

/// Pick one of several found servers.
Future<Found?> pickServer(BuildContext context, List<Found> found) =>
    showModalBottomSheet<Found>(
      context: context,
      backgroundColor: kCard,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const ListTile(
              title: Text('Servers found',
                  style: TextStyle(fontWeight: FontWeight.w800))),
          for (final f in found)
            ListTile(
              leading: const Icon(Icons.dns, color: kAccent),
              title: Text(f.name),
              subtitle: Text('${f.host}:${f.port}'),
              onTap: () => Navigator.pop(context, f),
            ),
        ]),
      ),
    );

/// Returns true if the connection settings changed.
Future<bool> showConnectSheet(BuildContext context) async {
  final r = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: kCard,
    builder: (_) => const _ConnectSheet(),
  );
  return r == true;
}

const _platforms = [
  ['lan', 'Wi-Fi', 'wifi'],
  ['tailscale', 'Tailscale', 'vpn'],
  ['tunnel', 'Web tunnel', 'cloud'],
  ['direct', 'Direct IP', 'router'],
  ['internet', 'Achufy relay', 'public'],
];

IconData _icon(String k) {
  switch (k) {
    case 'vpn':
      return Icons.vpn_lock;
    case 'cloud':
      return Icons.cloud_queue;
    case 'router':
      return Icons.router;
    case 'public':
      return Icons.public;
    default:
      return Icons.wifi;
  }
}

class _ConnectSheet extends StatefulWidget {
  const _ConnectSheet();
  @override
  State<_ConnectSheet> createState() => _ConnectSheetState();
}

class _ConnectSheetState extends State<_ConnectSheet> {
  final _lan = TextEditingController();
  final _ts = TextEditingController();
  final _tun = TextEditingController();
  final _direct = TextEditingController();
  final _relay = TextEditingController();
  final _room = TextEditingController();
  final _pass = TextEditingController(text: token);
  bool _https = false;
  String _p = 'lan';
  List<Found> _found = [];
  bool _searching = false;
  bool _searched = false;

  @override
  void initState() {
    super.initState();
    final p = store.prefs;
    _p = p?.getString('conn_mode') ?? 'lan';
    if (_p == 'lan') _lan.text = base.replaceFirst('http://', '');
    _ts.text = p?.getString('addr_tailscale') ?? '';
    _tun.text = p?.getString('addr_tunnel') ?? '';
    _direct.text = p?.getString('addr_direct') ?? '';
    _https = p?.getBool('direct_https') ?? false;
    _relay.text = p?.getString('relay_url') ?? '';
    _room.text = p?.getString('relay_room') ?? '';
  }

  Future<void> _search() async {
    setState(() {
      _searching = true;
      _searched = false;
    });
    final f = await discoverServers();
    if (!mounted) return;
    setState(() {
      _found = f;
      _searching = false;
      _searched = true;
    });
  }

  Future<void> _apply(String b, String mode, {String? typed}) async {
    base = b;
    token = _pass.text.trim();
    final p = store.prefs;
    await p?.setString('server', b);
    await p?.setString('token', token);
    await p?.setString('conn_mode', mode);
    if (typed != null) await p?.setString('addr_$mode', typed);
    if (mode == 'direct') await p?.setBool('direct_https', _https);
    if (mode == 'internet') {
      await p?.setString('relay_url', _relay.text.trim());
      await p?.setString('relay_room', _room.text.trim());
    }
    if (mounted) Navigator.pop(context, true);
  }

  String _clean(String s) => s.trim().replaceFirst(RegExp(r'^https?://'), '').replaceAll(RegExp(r'/+$'), '');

  bool _needPass() {
    if (_pass.text.trim().isEmpty) {
      toast('Enter the server password for this connection type.');
      return true;
    }
    return false;
  }

  Widget _help(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(t,
            style: const TextStyle(color: Colors.white60, fontSize: 12.5, height: 1.4)),
      );

  Widget _field(TextEditingController c, String label,
          {String? hint, TextInputType? type}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
            controller: c,
            keyboardType: type ?? TextInputType.url,
            decoration: InputDecoration(
                labelText: label, hintText: hint, border: const OutlineInputBorder())),
      );

  Widget _go(String text, VoidCallback onTap) => FilledButton(
        style: FilledButton.styleFrom(
            backgroundColor: kAccent,
            foregroundColor: Colors.white,
            shape: const StadiumBorder(),
            padding: const EdgeInsets.symmetric(vertical: 14)),
        onPressed: onTap,
        child: Text(text),
      );

  Widget _body() {
    switch (_p) {
      case 'tailscale':
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _help('Install Tailscale on the server phone and on this device and sign in '
              'with the same account. Then enter the server\'s 100.x.x.x address '
              '(shown on the server screen).'),
          _field(_ts, 'Tailscale address', hint: '100.101.102.103:8080'),
          _go('Connect', () {
            final a = _clean(_ts.text);
            if (a.isEmpty) return;
            _apply('http://${a.contains(':') ? a : '$a:8080'}', 'tailscale', typed: a);
          }),
        ]);
      case 'tunnel':
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _help('Run a tunnel on the server phone, e.g. in Termux:\n'
              'pkg install cloudflared\n'
              'cloudflared tunnel --url http://localhost:8080\n'
              'Paste the https link it prints (ngrok and Pinggy links work too). '
              'Set a server password.'),
          _field(_tun, 'Tunnel link', hint: 'https://something.trycloudflare.com'),
          _go('Connect', () {
            final a = _clean(_tun.text);
            if (a.isEmpty || _needPass()) return;
            _apply('https://$a', 'tunnel', typed: a);
          }),
        ]);
      case 'direct':
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _help('For a server reachable by public IP or a DDNS name (you forward the '
              'port on your router). Set a server password.'),
          _field(_direct, 'Address and port', hint: 'myname.ddns.net:8080'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            activeColor: kAccent,
            title: const Text('Use HTTPS'),
            value: _https,
            onChanged: (v) => setState(() => _https = v),
          ),
          _go('Connect', () {
            final a = _clean(_direct.text);
            if (a.isEmpty || _needPass()) return;
            _apply('${_https ? 'https' : 'http'}://$a', 'direct', typed: a);
          }),
        ]);
      case 'internet':
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _help('Uses your own Achufy relay (see the relay folder). Enter the same '
              'relay address, room ID and password as on the server phone.'),
          _field(_relay, 'Relay address', hint: 'https://your-relay.onrender.com'),
          _field(_room, 'Room ID', type: TextInputType.text),
          _go('Connect', () {
            var r = _relay.text.trim().replaceAll(RegExp(r'/+$'), '');
            final room = _room.text.trim();
            if (r.isEmpty || room.isEmpty || _needPass()) return;
            if (!r.startsWith('http')) r = 'https://$r';
            _apply('$r/r/$room', 'internet');
          }),
        ]);
      default:
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _go(_searching ? 'Searching...' : 'Find server automatically',
              _searching ? () {} : _search),
          if (_searched && _found.isEmpty)
            const Padding(
                padding: EdgeInsets.only(top: 12),
                child: Text(
                    'No server found. Make sure it is running and both devices are on the same Wi-Fi.',
                    style: TextStyle(color: Colors.white60))),
          for (final f in _found)
            ListTile(
              leading: const Icon(Icons.dns, color: kAccent),
              title: Text(f.name),
              subtitle: Text('${f.host}:${f.port}'),
              onTap: () => _apply('http://${f.host}:${f.port}', 'lan'),
            ),
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: const Text('Enter address manually'),
            children: [
              _field(_lan, 'Address', hint: '192.168.1.20:8080'),
              OutlinedButton(
                  onPressed: () {
                    final a = _clean(_lan.text);
                    if (a.isEmpty) return;
                    _apply('http://$a', 'lan');
                  },
                  child: const Text('Connect')),
            ],
          ),
        ]);
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SafeArea(
          child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(20), children: [
            const Text('Connect to your server',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 4, children: [
              for (final pl in _platforms)
                ChoiceChip(
                  avatar: Icon(_icon(pl[2]), size: 18),
                  label: Text(pl[1]),
                  selected: _p == pl[0],
                  showCheckmark: false,
                  selectedColor: kAccent,
                  onSelected: (_) => setState(() => _p = pl[0]),
                ),
            ]),
            const SizedBox(height: 16),
            _field(_pass, _p == 'lan' ? 'Server password (if it has one)' : 'Server password',
                type: TextInputType.text),
            _body(),
          ]),
        ),
      );
}
