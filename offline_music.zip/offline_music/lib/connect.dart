import 'package:flutter/material.dart';
import 'client.dart';
import 'discovery.dart';
import 'main.dart' show kAccent, kCard, toast;

/// Pick one of several found servers.
Future<Found?> pickServer(BuildContext context, List<Found> found) =>
    showModalBottomSheet<Found>(
      context: context,
      backgroundColor: kCard,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const ListTile(
              title: Text('Servers found',
                  style: TextStyle(fontWeight: FontWeight.w800))),
          for (final f in found)
            ListTile(
              leading: const Icon(Icons.dns, color: kAccent),
              title: Text(f.name),
              subtitle: Text('${f.host}:${f.port}'),
              onTap: () => Navigator.pop(context, f),
            ),
        ]),
      ),
    );

/// Returns true if the connection settings changed.
Future<bool> showConnectSheet(BuildContext context) async {
  final r = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: kCard,
    builder: (_) => const _ConnectSheet(),
  );
  return r == true;
}

class _ConnectSheet extends StatefulWidget {
  const _ConnectSheet();
  @override
  State<_ConnectSheet> createState() => _ConnectSheetState();
}

class _ConnectSheetState extends State<_ConnectSheet> {
  final _addr = TextEditingController();
  final _pass = TextEditingController(text: token);
  final _relay = TextEditingController();
  final _room = TextEditingController();
  List<Found> _found = [];
  bool _searching = false;
  bool _searched = false;

  @override
  void initState() {
    super.initState();
    final p = store.prefs;
    final mode = p?.getString('conn_mode') ?? 'lan';
    if (mode == 'lan') {
      _addr.text = base.replaceFirst('http://', '');
    }
    _relay.text = p?.getString('relay_url') ?? '';
    _room.text = p?.getString('relay_room') ?? '';
  }

  Future<void> _search() async {
    setState(() {
      _searching = true;
      _searched = false;
    });
    final f = await discoverServers();
    if (!mounted) return;
    setState(() {
      _found = f;
      _searching = false;
      _searched = true;
    });
  }

  Future<void> _apply(String b, String mode) async {
    base = b;
    token = _pass.text.trim();
    final p = store.prefs;
    await p?.setString('server', b);
    await p?.setString('token', token);
    await p?.setString('conn_mode', mode);
    if (mode == 'internet') {
      await p?.setString('relay_url', _relay.text.trim());
      await p?.setString('relay_room', _room.text.trim());
    }
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SafeArea(
          child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(20), children: [
            const Text('Connect to your server',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                  backgroundColor: kAccent,
                  foregroundColor: Colors.white,
                  shape: const StadiumBorder(),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              icon: _searching
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.wifi_find),
              label: Text(_searching ? 'Searching...' : 'Find server automatically'),
              onPressed: _searching ? null : _search,
            ),
            if (_searched && _found.isEmpty)
              const Padding(
                  padding: EdgeInsets.only(top: 12),
                  child: Text(
                      'No server found. Make sure it is running and both phones are on the same Wi-Fi.',
                      style: TextStyle(color: Colors.white60))),
            for (final f in _found)
              ListTile(
                leading: const Icon(Icons.dns, color: kAccent),
                title: Text(f.name),
                subtitle: Text('${f.host}:${f.port}'),
                onTap: () => _apply('http://${f.host}:${f.port}', 'lan'),
              ),
            const SizedBox(height: 16),
            TextField(
                controller: _pass,
                decoration: const InputDecoration(
                    labelText: 'Server password (if it has one)',
                    border: OutlineInputBorder())),
            const SizedBox(height: 16),
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: const Text('Enter address manually'),
              children: [
                TextField(
                    controller: _addr,
                    keyboardType: TextInputType.url,
                    decoration: const InputDecoration(
                        hintText: '192.168.1.20:8080', border: OutlineInputBorder())),
                const SizedBox(height: 8),
                OutlinedButton(
                    onPressed: () {
                      final a = _addr.text.trim().replaceFirst(RegExp(r'^https?://'), '');
                      if (a.isEmpty) return;
                      _apply('http://$a', 'lan');
                    },
                    child: const Text('Connect')),
              ],
            ),
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              initiallyExpanded: (store.prefs?.getString('conn_mode') ?? 'lan') == 'internet',
              leading: const Icon(Icons.public),
              title: const Text('Internet mode (from anywhere)'),
              children: [
                TextField(
                    controller: _relay,
                    keyboardType: TextInputType.url,
                    decoration: const InputDecoration(
                        labelText: 'Relay address', border: OutlineInputBorder())),
                const SizedBox(height: 10),
                TextField(
                    controller: _room,
                    decoration: const InputDecoration(
                        labelText: 'Room ID', border: OutlineInputBorder())),
                const SizedBox(height: 8),
                OutlinedButton(
                    onPressed: () {
                      var r = _relay.text.trim().replaceAll(RegExp(r'/+$'), '');
                      final room = _room.text.trim();
                      if (r.isEmpty || room.isEmpty || _pass.text.trim().isEmpty) {
                        toast('Enter the relay address, room ID and password.');
                        return;
                      }
                      if (!r.startsWith('http')) r = 'https://$r';
                      _apply('$r/r/$room', 'internet');
                    },
                    child: const Text('Connect over internet')),
              ],
            ),
          ]),
        ),
      );
}
