import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'client.dart';
import 'fx.dart';
import 'lyrics.dart';
import 'lyricstudio.dart';
import 'main.dart' show Backdrop, kAccent, toast;
import 'now_playing.dart' show LrcLine, parseLrc;

/// Full-screen sing-along: big synced lyrics with a fill that follows the singer.
class KaraokePage extends StatefulWidget {
  KaraokePage({super.key});
  @override
  State<KaraokePage> createState() => _KaraokePageState();
}

class _KaraokePageState extends State<KaraokePage> {
  List<LrcLine> _lrc = [];
  bool _loaded = false;
  String? _forId;
  MediaItem? _tag;
  StreamSubscription<SequenceState?>? _sub;

  @override
  void initState() {
    super.initState();
    _sub = player.sequenceStateStream.listen((s) {
      final tag = s?.currentSource?.tag;
      if (tag is MediaItem && tag.id != _forId) _load(tag);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    AudioFx.I.setKaraoke(false);
    super.dispose();
  }

  Future<void> _load(MediaItem tag) async {
    _forId = tag.id;
    if (mounted) setState(() { _tag = tag; _lrc = []; _loaded = false; });
    final txt = await fetchLyrics(tag.id, tag.extras?['path'] as String?);
    if (_forId != tag.id || !mounted) return;
    setState(() {
      _lrc = txt == null ? [] : parseLrc(txt);
      _loaded = true;
    });
  }

  Widget _line(String t, {double size = 22, Color color = Colors.white38}) => Padding(
        padding: EdgeInsets.symmetric(vertical: 6, horizontal: 24),
        child: Text(t,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: size, fontWeight: FontWeight.w800, color: color)),
      );

  Widget _stage(Duration pos) {
    var idx = -1;
    for (var i = 0; i < _lrc.length; i++) {
      if (_lrc[i].time <= pos) {
        idx = i;
      } else {
        break;
      }
    }
    final nextT = idx + 1 < _lrc.length
        ? _lrc[idx + 1].time
        : (idx >= 0 ? _lrc[idx].time + Duration(seconds: 5) : Duration(seconds: 3));
    final gapToNext = (idx + 1 < _lrc.length ? _lrc[idx + 1].time : nextT) - pos;
    final showDots = gapToNext > Duration(seconds: 6) ||
        (idx < 0 && gapToNext < Duration(seconds: 6));
    String txt(int i) => i >= 0 && i < _lrc.length ? (_lrc[i].text.isEmpty ? '' : _lrc[i].text) : '';
    double p = 0;
    if (idx >= 0) {
      final span = (nextT - _lrc[idx].time).inMilliseconds;
      p = span <= 0 ? 1 : ((pos - _lrc[idx].time).inMilliseconds / span).clamp(0.0, 1.0);
    }
    final cur = idx >= 0 ? txt(idx) : '';
    final secs = gapToNext.inMilliseconds / 1000;
    final dots = secs > 4 ? 0 : secs.ceil().clamp(0, 4);
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      _line(txt(idx - 1)),
      SizedBox(height: 8),
      if (cur.isEmpty || (showDots && p > 0.97 && dots > 0))
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (var d = 0; d < 4; d++)
            Container(
              margin: EdgeInsets.all(6),
              width: 16,
              height: 16,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: d < dots ? kAccent : Colors.white24),
            ),
        ])
      else
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: ShaderMask(
            blendMode: BlendMode.srcIn,
            shaderCallback: (r) => LinearGradient(
              colors: [kAccent, kAccent, Colors.white, Colors.white],
              stops: [0, p, p + 0.001 > 1 ? 1.0 : p + 0.001, 1],
            ).createShader(r),
            child: Text(cur,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 34, fontWeight: FontWeight.w900, color: Colors.white, height: 1.2)),
          ),
        ),
      SizedBox(height: 8),
      _line(txt(idx + 1), size: 24, color: Colors.white54),
      _line(txt(idx + 2), size: 20),
    ]);
  }

  @override
  Widget build(BuildContext context) => Backdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            title: Text(_tag?.title ?? 'Karaoke'),
            actions: [
              ListenableBuilder(
                listenable: AudioFx.I,
                builder: (_, __) => FilterChip(
                  label: Text('Vocal reducer'),
                  selected: AudioFx.I.karaoke,
                  selectedColor: kAccent,
                  showCheckmark: false,
                  onSelected: (v) {
                    AudioFx.I.setKaraoke(v);
                    if (v) toast('Vocals are reduced, not removed');
                  },
                ),
              ),
              SizedBox(width: 12),
            ],
          ),
          body: Column(children: [
            Expanded(
              child: !_loaded
                  ? Center(child: CircularProgressIndicator(color: kAccent))
                  : _lrc.isEmpty
                      ? Center(
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            Padding(
                                padding: EdgeInsets.all(24),
                                child: Text('No synced lyrics for this song yet.',
                                    style: TextStyle(color: Colors.white70, fontSize: 16))),
                            FilledButton.icon(
                                style: FilledButton.styleFrom(
                                    backgroundColor: kAccent, foregroundColor: Colors.white),
                                icon: Icon(Icons.edit_note),
                                label: Text('Make lyrics'),
                                onPressed: () => openLyricsStudio(context)),
                          ]),
                        )
                      : StreamBuilder<Duration>(
                          stream: player.createPositionStream(
                              minPeriod: Duration(milliseconds: 40),
                              maxPeriod: Duration(milliseconds: 80)),
                          builder: (_, s) => _stage(s.data ?? Duration.zero),
                        ),
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 20),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton(iconSize: 38, icon: Icon(Icons.skip_previous), onPressed: doPrev),
                StreamBuilder<bool>(
                  stream: player.playingStream,
                  builder: (_, s) => IconButton(
                    autofocus: true,
                    iconSize: 56,
                    color: kAccent,
                    icon: Icon(s.data == true ? Icons.pause_circle : Icons.play_circle),
                    onPressed: s.data == true ? doPause : doPlay,
                  ),
                ),
                IconButton(iconSize: 38, icon: Icon(Icons.skip_next), onPressed: doNext),
              ]),
            ),
          ]),
        ),
      );
}
