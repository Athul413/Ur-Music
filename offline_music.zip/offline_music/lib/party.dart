import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'client.dart';
import 'fx.dart';
import 'main.dart' show Backdrop, kAccent, kCard, toast;

/// Party mode client: every device plays the same song from the server,
/// kept in sync by a shared clock.
class PartyClient extends ChangeNotifier {
  PartyClient._();
  static final PartyClient I = PartyClient._();

  WebSocket? _ws;
  bool connected = false;
  String name = 'My device';
  String role = 'full';
  List<Map<String, dynamic>> roster = [];
  List<int> queue = [];
  int index = 0;
  bool playing = false;
  int anchorPos = 0, anchorAt = 0;
  int _offset = 0;
  final List<List<int>> _samples = [];
  int syncNudge = 0;
  Timer? _pingT, _driftT, _startT;
  StreamSubscription<ProcessingState>? _endSub;
  int? _loadedId;
  int _endedFor = -1;

  int serverNow() => DateTime.now().millisecondsSinceEpoch + _offset;
  int get expectedPos =>
      playing ? max(0, anchorPos + serverNow() - anchorAt) : anchorPos;

  void _send(Map<String, dynamic> m) {
    try {
      _ws?.add(jsonEncode(m));
    } catch (_) {}
  }

  Future<bool> join() async {
    if (base.isEmpty) {
      toast('Connect to your server first.');
      return false;
    }
    final b = base.replaceFirst(RegExp(r'^http'), 'ws');
    final uri = '$b/party${token.isEmpty ? '' : '?k=${Uri.encodeQueryComponent(token)}'}';
    try {
      final ws = await WebSocket.connect(uri).timeout(Duration(seconds: 8));
      ws.pingInterval = Duration(seconds: 20);
      _ws = ws;
      connected = true;
      _loadedId = null;
      _samples.clear();
      _send({'t': 'hello', 'name': name, 'role': role});
      AudioFx.I.setRole(role);
      for (var i = 0; i < 6; i++) {
        Future.delayed(Duration(milliseconds: 150 * i), _ping);
      }
      _pingT = Timer.periodic(Duration(seconds: 20), (_) => _ping());
      _driftT = Timer.periodic(Duration(milliseconds: 1500), (_) => _drift());
      _endSub = player.processingStateStream.listen((s) {
        if (s == ProcessingState.completed && playing && _endedFor != index) {
          _endedFor = index;
          _send({'t': 'ended', 'index': index});
        }
      });
      ws.listen(_onMsg, onDone: _closed, onError: (_) => _closed());
      notifyListeners();
      return true;
    } catch (_) {
      toast('Could not join. Party needs a direct, Wi-Fi, Tailscale or tunnel connection.');
      return false;
    }
  }

  void _closed() {
    if (!connected) return;
    leave(silent: true);
    toast('Party ended or disconnected');
  }

  void leave({bool silent = false}) {
    connected = false;
    _pingT?.cancel();
    _driftT?.cancel();
    _startT?.cancel();
    _endSub?.cancel();
    try {
      _ws?.close();
    } catch (_) {}
    _ws = null;
    roster = [];
    player.setSpeed(1.0);
    AudioFx.I.setRole('full');
    notifyListeners();
  }

  void _ping() => _send({'t': 'ping', 'c': DateTime.now().millisecondsSinceEpoch});

  void _onMsg(dynamic raw) {
    if (raw is! String) return;
    final m = jsonDecode(raw) as Map<String, dynamic>;
    switch (m['t']) {
      case 'pong':
        final t1 = DateTime.now().millisecondsSinceEpoch;
        final rtt = t1 - (m['c'] as num).toInt();
        final off = (m['s'] as num).toInt() + rtt ~/ 2 - t1;
        _samples.add([rtt, off]);
        if (_samples.length > 8) _samples.removeAt(0);
        final best = _samples.reduce((a, b) => a[0] <= b[0] ? a : b);
        _offset = best[1];
        break;
      case 'roster':
        roster = List<Map<String, dynamic>>.from(
            (m['members'] as List).map((e) => Map<String, dynamic>.from(e as Map)));
        notifyListeners();
        break;
      case 'state':
        _onState(m);
        break;
    }
  }

  Future<void> _onState(Map<String, dynamic> m) async {
    queue = List<int>.from(m['queue']);
    index = (m['index'] as num).toInt();
    playing = m['playing'] == true;
    anchorPos = (m['pos'] as num).toInt();
    anchorAt = (m['at'] as num).toInt();
    notifyListeners();
    if (queue.isEmpty || index >= queue.length) return;
    final song = libraryById[queue[index]];
    if (song == null || song.isLocal) {
      toast('This song is not on the server library for this device');
      return;
    }
    _startT?.cancel();
    try {
      if (_loadedId != song.id) {
        _loadedId = song.id;
        _endedFor = -1;
        await player.setAudioSource(buildSource([song]),
            initialPosition: Duration(milliseconds: max(0, anchorPos)));
      }
      if (!playing) {
        await player.pause();
        await player.seek(Duration(milliseconds: anchorPos));
        return;
      }
      final wait = anchorAt - serverNow();
      if (wait > 0) {
        await player.seek(Duration(milliseconds: max(0, anchorPos + syncNudge)));
        await player.pause();
        _startT = Timer(Duration(milliseconds: wait), () => player.play());
      } else {
        await player.seek(Duration(milliseconds: max(0, anchorPos - wait + syncNudge)));
        await player.play();
      }
    } catch (_) {
      toast('Could not play the party song');
    }
  }

  void _drift() {
    if (!connected || !playing || !player.playing) {
      if (player.speed != 1.0) player.setSpeed(1.0);
      return;
    }
    final diff = player.position.inMilliseconds - (expectedPos + syncNudge);
    if (diff.abs() > 600) {
      player.seek(Duration(milliseconds: max(0, expectedPos + syncNudge)));
      player.setSpeed(1.0);
    } else if (diff.abs() > 70) {
      player.setSpeed(diff > 0 ? 0.97 : 1.03);
    } else if (player.speed != 1.0) {
      player.setSpeed(1.0);
    }
  }

  void setQueue(List<Song> list, int i) => _send({
        't': 'set',
        'queue': [for (final s in list) if (!s.isLocal) s.id],
        'index': i,
        'pos': 0,
        'playing': true,
      });

  void ctl(String t, {int? pos}) => _send({'t': t, if (pos != null) 'pos': pos});

  void setRole(String r) {
    role = r;
    AudioFx.I.setRole(r);
    _send({'t': 'role', 'role': r});
    notifyListeners();
  }

  void setNudge(int ms) {
    syncNudge = ms;
    notifyListeners();
  }
}

class PartyPage extends StatefulWidget {
  PartyPage({super.key});
  @override
  State<PartyPage> createState() => _PartyPageState();
}

class _PartyPageState extends State<PartyPage> {
  final _name = TextEditingController(text: PartyClient.I.name);
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    PartyClient.I.addListener(_r);
  }

  @override
  void dispose() {
    PartyClient.I.removeListener(_r);
    super.dispose();
  }

  void _r() {
    if (mounted) setState(() {});
  }

  static const _roles = [
    ['full', 'Full sound', Icons.speaker],
    ['bass', 'Bass (sub)', Icons.graphic_eq],
    ['mid', 'Vocals / mids', Icons.mic],
    ['treble', 'Treble', Icons.music_note],
  ];

  @override
  Widget build(BuildContext context) {
    final p = PartyClient.I;
    return Backdrop(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(backgroundColor: Colors.transparent, title: Text('Party mode')),
        body: ListView(padding: EdgeInsets.all(20), children: [
          Text(
              p.connected
                  ? 'You are in the party. Songs you play now play on every device.'
                  : 'Play the same song on several phones, tablets or TVs at once. Every device must be connected to the same Achufy server.',
              style: TextStyle(color: Colors.white70, height: 1.4)),
          SizedBox(height: 16),
          if (!p.connected) ...[
            TextField(
              controller: _name,
              decoration: InputDecoration(
                  labelText: 'This device name', border: OutlineInputBorder()),
            ),
            SizedBox(height: 14),
            Text('Speaker role', style: TextStyle(fontWeight: FontWeight.w700)),
            SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              for (final r in _roles)
                ChoiceChip(
                  avatar: Icon(r[2] as IconData, size: 16),
                  label: Text(r[1] as String),
                  selected: p.role == r[0],
                  showCheckmark: false,
                  selectedColor: kAccent,
                  onSelected: (_) => setState(() => p.role = r[0] as String),
                ),
            ]),
            SizedBox(height: 20),
            FilledButton.icon(
              autofocus: true,
              style: FilledButton.styleFrom(
                  backgroundColor: kAccent,
                  foregroundColor: Colors.white,
                  shape: StadiumBorder(),
                  padding: EdgeInsets.symmetric(vertical: 14)),
              icon: Icon(Icons.celebration),
              label: Text(_busy ? 'Joining...' : 'Join / start party'),
              onPressed: _busy
                  ? null
                  : () async {
                      setState(() => _busy = true);
                      p.name = _name.text.trim().isEmpty ? 'My device' : _name.text.trim();
                      await p.join();
                      if (mounted) setState(() => _busy = false);
                    },
            ),
          ] else ...[
            Container(
              padding: EdgeInsets.all(14),
              decoration: BoxDecoration(
                  color: kCard, borderRadius: BorderRadius.circular(18)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${p.roster.length} device${p.roster.length == 1 ? '' : 's'} connected',
                    style: TextStyle(fontWeight: FontWeight.w800)),
                SizedBox(height: 8),
                for (final m in p.roster)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.speaker_group, color: kAccent),
                    title: Text('${m['name']}'),
                    subtitle: Text(_roles
                        .firstWhere((r) => r[0] == m['role'], orElse: () => _roles.first)[1]
                        as String),
                  ),
              ]),
            ),
            SizedBox(height: 14),
            Text('This device plays as', style: TextStyle(fontWeight: FontWeight.w700)),
            SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              for (final r in _roles)
                ChoiceChip(
                  avatar: Icon(r[2] as IconData, size: 16),
                  label: Text(r[1] as String),
                  selected: p.role == r[0],
                  showCheckmark: false,
                  selectedColor: kAccent,
                  onSelected: (_) => p.setRole(r[0] as String),
                ),
            ]),
            SizedBox(height: 4),
            Text(
                'Roles split the sound by frequency (a simulated multi-speaker setup). Put a bass device and full-range devices around the room.',
                style: TextStyle(color: Colors.white54, fontSize: 12)),
            SizedBox(height: 14),
            Text('Sync nudge: ${p.syncNudge} ms',
                style: TextStyle(fontWeight: FontWeight.w700)),
            Slider(
              min: -500,
              max: 500,
              divisions: 100,
              value: p.syncNudge.toDouble(),
              onChanged: (v) => p.setNudge(v.round()),
            ),
            Text(
                'If this device sounds late or early (for example Bluetooth speakers), nudge it until the echo disappears.',
                style: TextStyle(color: Colors.white54, fontSize: 12)),
            SizedBox(height: 16),
            Row(children: [
              IconButton(
                  iconSize: 34,
                  icon: Icon(Icons.skip_previous),
                  onPressed: () => p.ctl('prev')),
              IconButton(
                  iconSize: 48,
                  icon: Icon(p.playing ? Icons.pause_circle : Icons.play_circle,
                      color: kAccent),
                  onPressed: () => p.ctl(p.playing ? 'pause' : 'play')),
              IconButton(
                  iconSize: 34,
                  icon: Icon(Icons.skip_next),
                  onPressed: () => p.ctl('next')),
              Spacer(),
              OutlinedButton(
                  onPressed: () {
                    p.leave();
                    setState(() {});
                  },
                  child: Text('Leave')),
            ]),
            SizedBox(height: 8),
            Text(
                'Tip: with the party on, tap any song in your library to play it for everyone.',
                style: TextStyle(color: Colors.white54, fontSize: 12)),
          ],
        ]),
      ),
    );
  }
}
