import 'dart:convert';
import 'dart:io';
import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;
import 'package:shelf_router/shelf_router.dart';

const _mimes = {
  'mp3': 'audio/mpeg', 'm4a': 'audio/mp4', 'aac': 'audio/aac',
  'flac': 'audio/flac', 'ogg': 'audio/ogg', 'opus': 'audio/ogg',
  'wav': 'audio/wav',
};

class Track {
  final int id;
  final String path, title, artist, album, lyrics;
  final bool cover;
  Track(this.id, this.path, this.title, this.artist, this.album, this.cover, this.lyrics);
  Map<String, dynamic> toJson() => {
        'id': id, 'title': title, 'artist': artist, 'album': album, 'cover': cover,
        'lyrics': lyrics,
      };
}

class MusicServer {
  HttpServer? _http;
  final List<Track> tracks = [];

  Future<int> scan(String dir) async {
    tracks.clear();
    final d = Directory(dir);
    if (!await d.exists()) return 0;
    final found = <Track>[];
    await for (final e in d.list(recursive: true, followLinks: false)) {
      if (e is! File) continue;
      final ext = e.path.split('.').last.toLowerCase();
      if (!_mimes.containsKey(ext)) continue;
      final name = e.uri.pathSegments.last.replaceAll(RegExp(r'\.[^.]+$'), '');
      String title = name, artist = 'Unknown artist', album = 'Unknown album';
      bool cover = false;
      String lyrics = '';
      final lrc = File(e.path.replaceFirst(RegExp(r'\.[^.]+$'), '.lrc'));
      if (await lrc.exists()) {
        try { lyrics = await lrc.readAsString(); } catch (_) {}
      }
      try {
        final m = readMetadata(e, getImage: true);
        if ((m.title ?? '').trim().isNotEmpty) title = m.title!;
        if ((m.artist ?? '').trim().isNotEmpty) artist = m.artist!;
        if ((m.album ?? '').trim().isNotEmpty) album = m.album!;
        cover = m.pictures.isNotEmpty;
      } catch (_) {}
      found.add(Track(0, e.path, title, artist, album, cover, lyrics));
    }
    found.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    for (var i = 0; i < found.length; i++) {
      final t = found[i];
      tracks.add(Track(i, t.path, t.title, t.artist, t.album, t.cover, t.lyrics));
    }
    return tracks.length;
  }

  Track? _byId(String id) {
    final i = int.tryParse(id);
    return (i == null || i < 0 || i >= tracks.length) ? null : tracks[i];
  }

  Future<Response> _stream(Request req, String id) async {
    final t = _byId(id);
    if (t == null) return Response.notFound('no such track');
    final file = File(t.path);
    final len = await file.length();
    final ext = t.path.split('.').last.toLowerCase();
    final h = {
      'content-type': _mimes[ext] ?? 'application/octet-stream',
      'accept-ranges': 'bytes',
    };
    final m = RegExp(r'bytes=(\d*)-(\d*)').firstMatch(req.headers['range'] ?? '');
    if (m != null) {
      final s = m.group(1)!.isEmpty ? 0 : int.parse(m.group(1)!);
      var e = m.group(2)!.isEmpty ? len - 1 : int.parse(m.group(2)!);
      if (e >= len) e = len - 1;
      if (s > e) return Response(416, headers: {'content-range': 'bytes */$len'});
      return Response(206,
          body: file.openRead(s, e + 1),
          headers: {
            ...h,
            'content-range': 'bytes $s-$e/$len',
            'content-length': '${e - s + 1}',
          });
    }
    return Response.ok(file.openRead(), headers: {...h, 'content-length': '$len'});
  }

  Response _cover(Request req, String id) {
    final t = _byId(id);
    if (t == null || !t.cover) return Response.notFound('no cover');
    try {
      final p = readMetadata(File(t.path), getImage: true).pictures.first;
      return Response.ok(p.bytes, headers: {
        'content-type': p.mimetype.isEmpty ? 'image/jpeg' : p.mimetype,
        'cache-control': 'max-age=86400',
      });
    } catch (_) {
      return Response.notFound('no cover');
    }
  }

  Future<void> start(int port) async {
    await stop();
    final r = Router()
      ..get('/api/ping', (Request _) => Response.ok('ok'))
      ..get(
          '/api/tracks',
          (Request _) => Response.ok(
              jsonEncode(tracks.map((t) => t.toJson()).toList()),
              headers: {'content-type': 'application/json'}))
      ..get('/stream/<id>', _stream)
      ..get('/cover/<id>', _cover);
    _http = await io.serve(r.call, InternetAddress.anyIPv4, port);
  }

  Future<void> stop() async {
    await _http?.close(force: true);
    _http = null;
  }
}

class ServerPage extends StatefulWidget {
  const ServerPage({super.key});
  @override
  State<ServerPage> createState() => _ServerPageState();
}

class _ServerPageState extends State<ServerPage> {
  static final _server = MusicServer();
  final _dir = TextEditingController(text: '/storage/emulated/0/Music');
  final _port = TextEditingController(text: '8080');
  bool _running = false, _busy = false;
  String _status = 'Stopped';
  List<String> _ips = [];

  Future<void> _start() async {
    setState(() {
      _busy = true;
      _status = 'Requesting permissions...';
    });
    await Permission.manageExternalStorage.request();
    await Permission.notification.request();
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'music_server', channelName: 'Music server'),
      iosNotificationOptions: const IOSNotificationOptions(),
      foregroundTaskOptions: ForegroundTaskOptions(
          eventAction: ForegroundTaskEventAction.nothing()),
    );
    await FlutterForegroundTask.startService(
        notificationTitle: 'Music server running',
        notificationText: 'Serving your library on the local network');
    setState(() => _status = 'Scanning library...');
    final n = await _server.scan(_dir.text.trim());
    final port = int.tryParse(_port.text) ?? 8080;
    await _server.start(port);
    final ips = <String>[];
    for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
      for (final a in i.addresses) {
        ips.add('${a.address}:$port');
      }
    }
    setState(() {
      _running = true;
      _busy = false;
      _ips = ips;
      _status = 'Running - $n tracks';
    });
  }

  Future<void> _stop() async {
    await _server.stop();
    await FlutterForegroundTask.stopService();
    setState(() {
      _running = false;
      _status = 'Stopped';
      _ips = [];
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Music server')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          TextField(
              controller: _dir,
              enabled: !_running,
              decoration: const InputDecoration(
                  labelText: 'Music folder', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(
              controller: _port,
              enabled: !_running,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  labelText: 'Port', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : (_running ? _stop : _start),
            child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(_running ? 'Stop server' : 'Start server')),
          ),
          const SizedBox(height: 20),
          Text(_status, style: const TextStyle(fontSize: 16)),
          if (_ips.isNotEmpty) ...[
            const SizedBox(height: 12),
            const Text('Enter one of these in the player:'),
            for (final ip in _ips)
              SelectableText(ip,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold)),
          ],
          const SizedBox(height: 24),
          const Text('Tip: turn off battery optimization for this app and keep '
              'the phone plugged in.'),
        ]),
      );
}
