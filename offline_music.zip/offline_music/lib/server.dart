import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:flutter/material.dart' hide Router;
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;
import 'package:shelf_router/shelf_router.dart';
import 'discovery.dart' show kDiscoveryPort;
import 'main.dart' show Backdrop, kAccent;
import 'permissions.dart';
import 'party_hub.dart';
import 'sidecar.dart';
import 'taghints.dart';
import 'tagextra.dart';

const _mimes = {
  'mp3': 'audio/mpeg', 'm4a': 'audio/mp4', 'aac': 'audio/aac',
  'flac': 'audio/flac', 'ogg': 'audio/ogg', 'opus': 'audio/ogg',
  'wav': 'audio/wav',
};

class Track {
  final int id;
  final String path, title, artist, album;
  final bool cover;
  final String? coverFile;
  final String genre;
  final int? year, dur;
  final int size;
  final double? rg;
  Track(this.id, this.path, this.title, this.artist, this.album, this.cover,
      {this.coverFile, this.genre = '', this.year, this.dur, this.size = 0, this.rg});
  Map<String, dynamic> toJson() => {
        'id': id, 'title': title, 'artist': artist, 'album': album, 'cover': cover,
        'genre': genre, 'year': year, 'dur': dur, 'size': size, 'rg': rg,
      };
}

int _stableId(String s) {
  var h = 0x811c9dc5;
  for (final b in utf8.encode(s)) {
    h ^= b;
    h = (h * 0x01000193) & 0xFFFFFFFF;
  }
  return h;
}

/// Connects out to a relay on the internet so the player can reach this
/// server from anywhere (no port forwarding needed).
class RelayLink {
  WebSocket? _ws;
  bool _stop = true;
  bool connected = false;
  void Function()? onChange;

  void start(String relay, String room, Handler handler) {
    _stop = false;
    _loop(relay, room, handler);
  }

  Future<void> stop() async {
    _stop = true;
    connected = false;
    try {
      await _ws?.close();
    } catch (_) {}
    _ws = null;
    onChange?.call();
  }

  static String wsUrl(String relay, String room) {
    var r = relay.trim().replaceAll(RegExp(r'/+$'), '');
    if (r.startsWith('https://')) {
      r = 'wss://${r.substring(8)}';
    } else if (r.startsWith('http://')) {
      r = 'ws://${r.substring(7)}';
    } else if (!r.startsWith('ws')) {
      r = 'wss://$r';
    }
    return '$r/connect?id=${Uri.encodeQueryComponent(room)}';
  }

  Future<void> _loop(String relay, String room, Handler handler) async {
    var delay = 2;
    while (!_stop) {
      try {
        final ws = await WebSocket.connect(wsUrl(relay, room))
            .timeout(Duration(seconds: 15));
        ws.pingInterval = Duration(seconds: 20);
        _ws = ws;
        connected = true;
        delay = 2;
        onChange?.call();
        final cancelled = <int>{};
        await for (final msg in ws) {
          if (msg is! String) continue;
          final m = jsonDecode(msg) as Map<String, dynamic>;
          if (m['t'] == 'req') {
            _serve(ws, m, handler, cancelled);
          } else if (m['t'] == 'cancel') {
            cancelled.add((m['id'] as num).toInt());
          }
        }
      } catch (_) {}
      connected = false;
      _ws = null;
      onChange?.call();
      if (_stop) break;
      await Future.delayed(Duration(seconds: delay));
      delay = min(delay * 2, 30);
    }
  }

  Future<void> _serve(WebSocket ws, Map<String, dynamic> m, Handler handler,
      Set<int> cancelled) async {
    final id = (m['id'] as num).toInt();
    try {
      final hdr = m['headers'];
      final range = hdr is Map ? '${hdr['range'] ?? ''}' : '';
      final req = Request(
        '${m['method'] ?? 'GET'}',
        Uri.parse('http://localhost${m['path'] ?? '/'}'),
        headers: {if (range.isNotEmpty) 'range': range},
      );
      final resp = await handler(req);
      ws.add(jsonEncode(
          {'t': 'res', 'id': id, 'status': resp.statusCode, 'headers': resp.headers}));
      var n = 0;
      await for (final chunk in resp.read()) {
        if (cancelled.contains(id) || ws.readyState != WebSocket.open) break;
        final frame = Uint8List(4 + chunk.length);
        frame[0] = (id >> 24) & 255;
        frame[1] = (id >> 16) & 255;
        frame[2] = (id >> 8) & 255;
        frame[3] = id & 255;
        frame.setRange(4, 4 + chunk.length, chunk);
        ws.add(frame);
        if (++n % 16 == 0) await Future.delayed(Duration(milliseconds: 1));
      }
    } catch (_) {
    } finally {
      cancelled.remove(id);
      if (ws.readyState == WebSocket.open) {
        ws.add(jsonEncode({'t': 'end', 'id': id}));
      }
    }
  }
}

class MusicServer {
  HttpServer? _http;
  bool get isRunning => _http != null;
  RawDatagramSocket? _udp;
  final relay = RelayLink();
  final party = PartyHub();
  final Map<int, Track> byId = {};
  String password = '';
  String name = 'Achufy server';
  int port = 8080;
  Handler? handler;

  Future<int> scan(String dir) async {
    byId.clear();
    final d = Directory(dir);
    if (!await d.exists()) return 0;
    final side = Sidecars();
    await for (final e in d.list(recursive: true, followLinks: false)) {
      if (e is! File) continue;
      final ext = e.path.split('.').last.toLowerCase();
      if (!_mimes.containsKey(ext)) continue;
      final fname = e.uri.pathSegments.last.replaceAll(RegExp(r'\.[^.]+$'), '');
      String title = fname, artist = 'Unknown artist', album = 'Unknown album';
      bool cover = false;
      var tags = ExtraTags('', null, null);
      try {
        final m = readMetadata(e, getImage: true);
        tags = extraTags(m);
        if ((m.title ?? '').trim().isNotEmpty) title = m.title!;
        if ((m.artist ?? '').trim().isNotEmpty) artist = m.artist!;
        if ((m.album ?? '').trim().isNotEmpty) album = m.album!;
        cover = m.pictures.isNotEmpty;
      } catch (_) {}
      String? coverFile;
      if (!cover) {
        coverFile = side.find(e.path, imageExts,
            title: title, generic: genericCovers, singleFallback: true);
        cover = coverFile != null;
      }
      final size = await e.length();
      final rg = await readReplayGain(e);
      final genre = tags.genre.isNotEmpty ? tags.genre : (readTagHints(e.path).genre ?? '');
      var id = _stableId(e.path.replaceFirst(dir, ''));
      while (byId.containsKey(id)) {
        id++;
      }
      byId[id] = Track(id, e.path, title, artist, album, cover,
          coverFile: coverFile,
          genre: genre,
          year: tags.year,
          dur: tags.durMs,
          size: size,
          rg: rg);
    }
    return byId.length;
  }

  Track? _byId(String id) {
    final i = int.tryParse(id);
    return i == null ? null : byId[i];
  }

  Future<Response> _stream(Request req, String id) async {
    final t = _byId(id);
    if (t == null) return Response.notFound('no such track');
    final file = File(t.path);
    if (!await file.exists()) return Response.notFound('file missing');
    final int len;
    try {
      len = await file.length();
    } catch (_) {
      return Response.internalServerError(body: 'cannot read file');
    }
    final ext = t.path.split('.').last.toLowerCase();
    final h = {
      'content-type': _mimes[ext] ?? 'application/octet-stream',
      'accept-ranges': 'bytes',
    };
    final m = RegExp(r'bytes=(\d*)-(\d*)').firstMatch(req.headers['range'] ?? '');
    if (m != null) {
      final s = m.group(1)!.isEmpty ? 0 : int.parse(m.group(1)!);
      var e = m.group(2)!.isEmpty ? len - 1 : int.parse(m.group(2)!);
      if (e >= len) e = len - 1;
      if (s > e) return Response(416, headers: {'content-range': 'bytes */$len'});
      return Response(206,
          body: file.openRead(s, e + 1),
          headers: {
            ...h,
            'content-range': 'bytes $s-$e/$len',
            'content-length': '${e - s + 1}',
          });
    }
    return Response.ok(file.openRead(), headers: {...h, 'content-length': '$len'});
  }

  Response _cover(Request req, String id) {
    final t = _byId(id);
    if (t == null || !t.cover) return Response.notFound('no cover');
    if (t.coverFile != null) {
      final ext = t.coverFile!.split('.').last.toLowerCase();
      final mime = ext == 'png'
          ? 'image/png'
          : (ext == 'webp' ? 'image/webp' : 'image/jpeg');
      return Response.ok(File(t.coverFile!).openRead(), headers: {
        'content-type': mime,
        'cache-control': 'max-age=86400',
      });
    }
    try {
      final p = readMetadata(File(t.path), getImage: true).pictures.first;
      return Response.ok(p.bytes, headers: {
        'content-type': p.mimetype.isEmpty ? 'image/jpeg' : p.mimetype,
        'cache-control': 'max-age=86400',
      });
    } catch (_) {
      return Response.notFound('no cover');
    }
  }

  Future<Response> _lyrics(Request req, String id) async {
    final t = _byId(id);
    if (t == null) return Response.notFound('no such track');
    final path = Sidecars().find(t.path, lyricExts, title: t.title);
    if (path != null) {
      final bytes = await File(path).readAsBytes();
      return Response.ok(bytes,
          headers: {'content-type': 'text/plain; charset=utf-8'});
    }
    return Response.notFound('no lyrics');
  }

  Future<Response> _putLyrics(Request req, String id) async {
    final t = _byId(id);
    if (t == null) return Response.notFound('no such track');
    final body = await req.readAsString();
    if (body.length > 400000) return Response(413, body: 'too large');
    final stem = t.path.replaceFirst(RegExp(r'\.[^./]+$'), '');
    await File('$stem.lrc').writeAsString(body);
    return Response.ok('saved');
  }

  Middleware _auth() => (Handler inner) => (Request req) {
        if (password.isEmpty ||
            req.url.path == 'api/ping' ||
            req.requestedUri.queryParameters['k'] == password) {
          return inner(req);
        }
        return Response.forbidden('password required');
      };

  Future<void> start(int p) async {
    await stop();
    port = p;
    final r = Router()
      ..get('/api/ping', (Request _) => Response.ok('achufy:$name'))
      ..get(
          '/api/tracks',
          (Request _) => Response.ok(
              jsonEncode(byId.values.map((t) => t.toJson()).toList()),
              headers: {'content-type': 'application/json'}))
      ..get('/stream/<id>', _stream)
      ..get('/cover/<id>', _cover)
      ..get('/lyrics/<id>', _lyrics)
      ..put('/lyrics/<id>', _putLyrics);
    handler = Pipeline().addMiddleware(_auth()).addHandler(r.call);
    final hs = await HttpServer.bind(InternetAddress.anyIPv4, port);
    _http = hs;
    hs.listen((HttpRequest r) async {
      try {
        if (r.uri.path == '/party' && WebSocketTransformer.isUpgradeRequest(r)) {
          if (password.isNotEmpty && r.uri.queryParameters['k'] != password) {
            r.response.statusCode = 403;
            await r.response.close();
            return;
          }
          party.add(await WebSocketTransformer.upgrade(r));
        } else {
          await io.handleRequest(r, handler!);
        }
      } catch (_) {}
    });
    try {
      final s = await RawDatagramSocket.bind(InternetAddress.anyIPv4, kDiscoveryPort,
          reuseAddress: true);
      _udp = s;
      s.listen((e) {
        if (e != RawSocketEvent.read) return;
        final d = s.receive();
        if (d == null) return;
        if (utf8.decode(d.data, allowMalformed: true).startsWith('ACHUFY?')) {
          s.send(utf8.encode('ACHUFY|$port|$name'), d.address, d.port);
        }
      });
    } catch (_) {}
  }

  void startRelay(String url, String room) => relay.start(url, room, handler!);

  Future<void> stop() async {
    await relay.stop();
    party.closeAll();
    _udp?.close();
    _udp = null;
    await _http?.close(force: true);
    _http = null;
  }
}

/// One server shared by the whole app (so Quit can stop it).
final musicServer = MusicServer();

class ServerPage extends StatefulWidget {
  ServerPage({super.key});
  @override
  State<ServerPage> createState() => _ServerPageState();
}

class _ServerPageState extends State<ServerPage> {
  final _server = musicServer;
  final _dir = TextEditingController(text: '/storage/emulated/0/Music');
  final _port = TextEditingController(text: '8080');
  final _pass = TextEditingController();
  final _relay = TextEditingController();
  final _room = TextEditingController();
  bool _internet = false;
  bool _running = false, _busy = false;
  String _status = 'Stopped';
  List<String> _ips = [];
  SharedPreferences? _prefs;

  @override
  void initState() {
    super.initState();
    _load();
    if (_server.isRunning) {
      _running = true;
      _status = 'Running - ${_server.byId.length} tracks';
      _refreshIps();
    }
    _server.relay.onChange = () {
      if (mounted) setState(() {});
    };
  }

  Future<void> _refreshIps() async {
    final ips = <String>[];
    for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
      for (final a in i.addresses) {
        ips.add('${a.address}:${_server.port}');
      }
    }
    if (mounted) setState(() => _ips = ips);
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    _prefs = p;
    _dir.text = p.getString('srv_dir') ?? _dir.text;
    _port.text = p.getString('srv_port') ?? _port.text;
    _pass.text = p.getString('srv_pass') ?? '';
    _relay.text = p.getString('srv_relay') ?? '';
    var room = p.getString('srv_room');
    if (room == null || room.isEmpty) {
      const chars = 'abcdefghijkmnpqrstuvwxyz23456789';
      final r = Random.secure();
      room = List.generate(12, (_) => chars[r.nextInt(chars.length)]).join();
      await p.setString('srv_room', room);
    }
    _room.text = room;
    _internet = p.getBool('srv_internet') ?? false;
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    final p = _prefs;
    if (p == null) return;
    await p.setString('srv_dir', _dir.text.trim());
    await p.setString('srv_port', _port.text.trim());
    await p.setString('srv_pass', _pass.text);
    await p.setString('srv_relay', _relay.text.trim());
    await p.setString('srv_room', _room.text.trim());
    await p.setBool('srv_internet', _internet);
  }

  Future<void> _start() async {
    try {
      await _startInner();
    } catch (e) {
      try {
        await _server.stop();
        await FlutterForegroundTask.stopService();
      } catch (_) {}
      if (mounted) {
        setState(() {
          _busy = false;
          _running = false;
          _status = 'Error: $e';
        });
      }
    }
  }

  Future<void> _startInner() async {
    if (_internet && (_pass.text.isEmpty || _relay.text.trim().isEmpty || _room.text.trim().isEmpty)) {
      throw 'Internet mode needs a relay address, a room ID and a password.';
    }
    await _save();
    setState(() {
      _busy = true;
      _status = 'Requesting permissions...';
    });
    if (!mounted || !await ensureStorage(context)) {
      throw 'Music access is needed to share your songs. Tap Start again and allow it.';
    }
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'achufy_server', channelName: 'Achufy server'),
      iosNotificationOptions: IOSNotificationOptions(),
      foregroundTaskOptions: ForegroundTaskOptions(
          eventAction: ForegroundTaskEventAction.nothing()),
    );
    await FlutterForegroundTask.startService(
        notificationTitle: 'Achufy server running',
        notificationText: 'Serving your library');
    setState(() => _status = 'Scanning library...');
    final dir = _dir.text.trim();
    if (!await Directory(dir).exists()) {
      throw 'Folder not found: $dir\n(Allow "all files access" for Achufy in Settings > Apps.)';
    }
    final n = await _server.scan(dir);
    _server.password = _pass.text;
    await _server.start(int.tryParse(_port.text) ?? 8080);
    if (_internet) _server.startRelay(_relay.text.trim(), _room.text.trim());
    final ips = <String>[];
    for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
      for (final a in i.addresses) {
        ips.add('${a.address}:${_server.port}');
      }
    }
    if (!mounted) return;
    setState(() {
      _running = true;
      _busy = false;
      _ips = ips;
      _status = n == 0
          ? 'Running - 0 tracks found (is the folder empty?)'
          : 'Running - $n tracks';
    });
  }

  Future<void> _stop() async {
    await _server.stop();
    await FlutterForegroundTask.stopService();
    setState(() {
      _running = false;
      _status = 'Stopped';
      _ips = [];
    });
  }

  @override
  Widget build(BuildContext context) => Backdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
              backgroundColor: Colors.transparent, title: Text('Achufy server')),
          body: ListView(padding: EdgeInsets.all(20), children: [
            TextField(
                controller: _dir,
                enabled: !_running,
                decoration: InputDecoration(
                    labelText: 'Music folder', border: OutlineInputBorder())),
            SizedBox(height: 12),
            TextField(
                controller: _port,
                enabled: !_running,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                    labelText: 'Port', border: OutlineInputBorder())),
            SizedBox(height: 12),
            TextField(
                controller: _pass,
                enabled: !_running,
                decoration: InputDecoration(
                    labelText: 'Password (optional on Wi-Fi, required for internet)',
                    border: OutlineInputBorder())),
            SizedBox(height: 4),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              activeColor: kAccent,
              title: Text('Internet mode'),
              subtitle: Text('Reach this server from anywhere through a relay'),
              value: _internet,
              onChanged: _running ? null : (v) => setState(() => _internet = v),
            ),
            if (_internet) ...[
              TextField(
                  controller: _relay,
                  enabled: !_running,
                  keyboardType: TextInputType.url,
                  decoration: InputDecoration(
                      labelText: 'Relay address (https://your-relay.onrender.com)',
                      border: OutlineInputBorder())),
              SizedBox(height: 12),
              TextField(
                  controller: _room,
                  enabled: !_running,
                  decoration: InputDecoration(
                      labelText: 'Room ID (keep it secret)',
                      border: OutlineInputBorder())),
              SizedBox(height: 8),
            ],
            SizedBox(height: 8),
            FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: kAccent, foregroundColor: Colors.white),
              onPressed: _busy ? null : (_running ? _stop : _start),
              child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text(_running ? 'Stop server' : 'Start server')),
            ),
            SizedBox(height: 20),
            Text(_status, style: TextStyle(fontSize: 16)),
            if (_running) ...[
              SizedBox(height: 12),
              Text('On Wi-Fi the player finds this server automatically.'),
              for (final ip in _ips)
                SelectableText(
                    ip.startsWith('100.') ? '$ip   (Tailscale)' : ip,
                    style: TextStyle(color: Colors.white60)),
              if (_internet) ...[
                SizedBox(height: 12),
                Text(
                    _server.relay.connected
                        ? 'Internet: connected to relay'
                        : 'Internet: connecting to relay...',
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: _server.relay.connected ? Colors.greenAccent : Colors.orangeAccent)),
                SizedBox(height: 6),
                Text('In the player: Connect > Internet, then enter the same relay address, room ID and password.'),
              ],
            ],
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(14),
              decoration: BoxDecoration(
                  color: Colors.white.withAlpha(12),
                  borderRadius: BorderRadius.circular(16)),
              child: Text(
                  'Other ways to reach this server from outside:\n'
                  '- Tailscale: install it on both devices and use the 100.x address above.\n'
                  '- Web tunnel: in Termux run  cloudflared tunnel --url http://localhost:8080\n'
                  '- Direct: forward the port on your router.\n'
                  'For all of these, set a password above.',
                  style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.4)),
            ),
            SizedBox(height: 24),
            Text('Lyrics: put a .lrc (synced) or .txt file with the same name '
                'next to each song.\n\nTip: turn off battery optimization for this app and keep the phone plugged in.',
                style: TextStyle(color: Colors.white54)),
          ]),
        ),
      );
}
