import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'client.dart';
import 'lyrics.dart';
import 'main.dart' show Backdrop, kAccent, kCard, toast;
import 'now_playing.dart' show parseLrc;

void openLyricsStudio(BuildContext context) {
  final s = currentSong();
  if (s == null) {
    toast('Play a song first, then open Lyrics Studio.');
    return;
  }
  Navigator.push(context, MaterialPageRoute(builder: (_) => LyricsStudioPage(song: s)));
}

class _L {
  String text;
  int ms;
  _L(this.text, [this.ms = -1]);
}

String _stamp(int ms) {
  final m = ms ~/ 60000;
  final s = (ms % 60000) / 1000;
  return '${m.toString().padLeft(2, '0')}:${s.toStringAsFixed(2).padLeft(5, '0')}';
}

/// Offline lyrics maker: paste the words, tap along while the song plays,
/// and save a synced .lrc file next to the music file.
class LyricsStudioPage extends StatefulWidget {
  final Song song;
  LyricsStudioPage({super.key, required this.song});
  @override
  State<LyricsStudioPage> createState() => _LyricsStudioPageState();
}

class _LyricsStudioPageState extends State<LyricsStudioPage> {
  final _text = TextEditingController();
  List<_L> _lines = [];
  bool _sync = false;
  int _next = 0;

  @override
  void initState() {
    super.initState();
    _loadExisting(silent: true);
  }

  Future<void> _loadExisting({bool silent = false}) async {
    final s = widget.song;
    final t = await fetchLyrics('${s.id}', s.localPath);
    if (t == null) {
      if (!silent) toast('No lyrics file found for this song.');
      return;
    }
    final parsed = parseLrc(t);
    final plain = parsed.isNotEmpty
        ? parsed.map((e) => e.text).join('\n')
        : t;
    if (mounted) setState(() => _text.text = plain);
  }

  void _start() {
    final ls = _text.text
        .split(RegExp(r'\r?\n'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    if (ls.isEmpty) {
      toast('Paste or type the lyrics first.');
      return;
    }
    setState(() {
      _lines = [for (final l in ls) _L(l)];
      _next = 0;
      _sync = true;
    });
  }

  void _tap() {
    if (_next >= _lines.length) return;
    final ms = (player.position.inMilliseconds - 120).clamp(0, 1 << 30);
    setState(() {
      _lines[_next].ms = ms;
      _next++;
    });
  }

  void _undo() {
    if (_next == 0) return;
    setState(() {
      _next--;
      _lines[_next].ms = -1;
    });
  }

  /// Rough timing: spreads the remaining lines across the rest of the song by length.
  void _spread() {
    final d = player.duration?.inMilliseconds ?? 0;
    if (d <= 0 || _next >= _lines.length) return;
    final start = _next == 0 ? 0 : _lines[_next - 1].ms + 2000;
    final end = d - 3000;
    if (end <= start) return;
    final rest = _lines.sublist(_next);
    final total = rest.fold<int>(0, (a, l) => a + l.text.length + 8);
    var acc = 0;
    setState(() {
      for (final l in rest) {
        l.ms = start + ((end - start) * acc / total).round();
        acc += l.text.length + 8;
      }
      _next = _lines.length;
    });
    toast('Timing spread across the song - fine-tune any line, then save.');
  }

  String _build() {
    final s = widget.song;
    final b = StringBuffer()
      ..writeln('[ti:${s.title}]')
      ..writeln('[ar:${s.artist}]')
      ..writeln('[al:${s.album}]');
    final sorted = _lines.where((l) => l.ms >= 0).toList()
      ..sort((a, b) => a.ms.compareTo(b.ms));
    for (final l in sorted) {
      b.writeln('[${_stamp(l.ms)}]${l.text}');
    }
    return b.toString();
  }

  Future<void> _save() async {
    if (_lines.every((l) => l.ms < 0)) {
      toast('Tap along first so the lines get timestamps.');
      return;
    }
    final s = widget.song;
    final lrc = _build();
    try {
      if (s.isLocal) {
        final p = s.localPath!.replaceFirst(RegExp(r'\.[^./]+$'), '');
        await File('$p.lrc').writeAsString(lrc);
        toast('Saved ${p.split('/').last}.lrc');
      } else {
        final r = await http
            .put(Uri.parse(url('/lyrics/${s.id}')),
                headers: {'content-type': 'text/plain; charset=utf-8'}, body: lrc)
            .timeout(Duration(seconds: 15));
        toast(r.statusCode == 200
            ? 'Saved next to the song on the server'
            : 'Server refused (${r.statusCode})');
      }
    } catch (_) {
      toast('Could not save. Saving to the server needs a direct, Wi-Fi, Tailscale or tunnel connection.');
    }
  }

  @override
  Widget build(BuildContext context) => Backdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            title: Text(_sync ? 'Tap to sync' : 'Lyrics Studio'),
            actions: [
              if (_sync)
                TextButton(onPressed: _save, child: Text('Save .lrc', style: TextStyle(color: kAccent))),
            ],
          ),
          body: _sync ? _syncView() : _editView(),
        ),
      );

  Widget _editView() => ListView(padding: EdgeInsets.all(16), children: [
        Text('${widget.song.title} - ${widget.song.artist}',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        SizedBox(height: 6),
        Text(
            'Step 1: paste or type the lyrics, one line per row.\nStep 2: play the song and tap once at the start of every line.\nStep 3: save - a .lrc file with the same name as the song is created.',
            style: TextStyle(color: Colors.white60, height: 1.4)),
        SizedBox(height: 12),
        TextField(
          controller: _text,
          minLines: 10,
          maxLines: 18,
          decoration: InputDecoration(
              hintText: 'Paste lyrics here...', border: OutlineInputBorder()),
        ),
        SizedBox(height: 12),
        Row(children: [
          OutlinedButton(onPressed: _loadExisting, child: Text('Load existing')),
          Spacer(),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.white),
            icon: Icon(Icons.timer),
            label: Text('Start syncing'),
            onPressed: _start,
          ),
        ]),
      ]);

  Widget _syncView() => Column(children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 8),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(
                icon: Icon(Icons.replay_5),
                onPressed: () => player.seek(player.position - Duration(seconds: 5))),
            StreamBuilder<bool>(
              stream: player.playingStream,
              builder: (_, s) => IconButton(
                iconSize: 44,
                icon: Icon(s.data == true ? Icons.pause_circle : Icons.play_circle),
                onPressed: s.data == true ? player.pause : player.play,
              ),
            ),
            IconButton(
                icon: Icon(Icons.forward_5),
                onPressed: () => player.seek(player.position + Duration(seconds: 5))),
            IconButton(icon: Icon(Icons.undo), onPressed: _undo),
            TextButton(onPressed: _spread, child: Text('Auto-spread')),
          ]),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _lines.length,
            itemBuilder: (_, i) {
              final l = _lines[i];
              final on = i == _next;
              return ListTile(
                dense: true,
                tileColor: on ? kAccent.withAlpha(40) : null,
                title: Text(l.text,
                    style: TextStyle(
                        fontWeight: on ? FontWeight.w800 : FontWeight.w500,
                        color: l.ms >= 0 ? Colors.white : Colors.white60)),
                subtitle: Text(l.ms >= 0 ? _stamp(l.ms) : '--:--'),
                trailing: l.ms < 0
                    ? null
                    : Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(
                            icon: Icon(Icons.remove),
                            onPressed: () => setState(() => l.ms = (l.ms - 200).clamp(0, 1 << 30))),
                        IconButton(
                            icon: Icon(Icons.add),
                            onPressed: () => setState(() => l.ms += 200)),
                      ]),
                onTap: l.ms >= 0 ? () => player.seek(Duration(milliseconds: l.ms)) : null,
              );
            },
          ),
        ),
        Container(
          color: kCard,
          padding: EdgeInsets.all(14),
          width: double.infinity,
          child: FilledButton(
            autofocus: true,
            style: FilledButton.styleFrom(
                backgroundColor: kAccent,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 22),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
            onPressed: _tap,
            child: Text(
                _next >= _lines.length
                    ? 'All lines stamped - tap Save .lrc'
                    : 'TAP  -  "${_lines[_next].text}"',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          ),
        ),
      ]);
}
