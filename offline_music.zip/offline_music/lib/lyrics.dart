import 'package:http/http.dart' as http;
import 'dart:convert';
import 'client.dart' show url;
import 'local.dart';

/// Loads lyrics text for a track (from the server, or next to a local file).
Future<String?> fetchLyrics(String id, String? localPath) async {
  try {
    if (localPath != null) return await readLocalLyrics(localPath);
    final r = await http
        .get(Uri.parse(url('/lyrics/$id')))
        .timeout(const Duration(seconds: 8));
    if (r.statusCode == 200) {
      return utf8.decode(r.bodyBytes, allowMalformed: true);
    }
  } catch (_) {}
  return null;
}
