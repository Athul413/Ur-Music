import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'client.dart';
import 'server.dart';

const achufyGreen = Color(0xFF1ED760);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.achufy.audio',
    androidNotificationChannelName: 'Achufy playback',
    androidNotificationOngoing: true,
  );
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Achufy',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF101310),
          colorScheme: ColorScheme.fromSeed(
            seedColor: achufyGreen,
            brightness: Brightness.dark,
            surface: const Color(0xFF181D19),
          ),
          useMaterial3: true,
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF101310),
            surfaceTintColor: Colors.transparent,
          ),
        ),
        home: const ModePicker(),
      );
}

class AchufyMark extends StatelessWidget {
  final double size;
  const AchufyMark({super.key, this.size = 44});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: size, height: size,
        child: CustomPaint(painter: _AchufyPainter()),
      );
}

class _AchufyPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()..color = achufyGreen..style = PaintingStyle.fill;
    final path = Path()
      ..moveTo(s.width * .08, s.height * .92)
      ..lineTo(s.width * .37, s.height * .08)
      ..quadraticBezierTo(s.width * .40, 0, s.width * .46, s.height * .08)
      ..lineTo(s.width * .92, s.height * .92)
      ..lineTo(s.width * .68, s.height * .92)
      ..lineTo(s.width * .42, s.height * .34)
      ..lineTo(s.width * .27, s.height * .92)
      ..close();
    canvas.drawPath(path, p);
    final bar = Paint()
      ..color = const Color(0xFF101310)
      ..strokeWidth = s.width * .065
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(s.width*.49, s.height*.62), Offset(s.width*.49, s.height*.88), bar);
    canvas.drawLine(Offset(s.width*.59, s.height*.52), Offset(s.width*.59, s.height*.88), bar);
    canvas.drawLine(Offset(s.width*.69, s.height*.66), Offset(s.width*.69, s.height*.88), bar);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ModePicker extends StatelessWidget {
  const ModePicker({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Center(child: AchufyMark(size: 86)),
                const SizedBox(height: 16),
                const Text('Achufy', textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -.8)),
                const SizedBox(height: 8),
                Text('Your music. Your way.', textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 15)),
                const SizedBox(height: 48),
                FilledButton.icon(
                  icon: const Icon(Icons.play_circle_fill),
                  label: const Padding(padding: EdgeInsets.all(14), child: Text('Open music player')),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ClientPage())),
                ),
                const SizedBox(height: 14),
                OutlinedButton.icon(
                  icon: const Icon(Icons.dns),
                  label: const Padding(padding: EdgeInsets.all(14), child: Text('Music server')),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ServerPage())),
                ),
              ],
            ),
          ),
        ),
      );
}
