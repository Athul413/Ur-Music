import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'client.dart';
import 'overlay.dart';
import 'splash.dart';

const kAccent = Color(0xFFE5383B);
const kBg = Color(0xFF0A0506);
const kCard = Color(0xFF1E0D11);
const kRedDeep = Color(0xFF5A0F18);

/// Dark red to black gradient used behind every screen.
class Backdrop extends StatelessWidget {
  final Widget child;
  const Backdrop({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [kRedDeep, kBg],
              stops: [0, 0.55]),
        ),
        child: Material(color: Colors.transparent, child: child),
      );
}

/// true on Android TV / devices without a touchscreen.
bool isTv = false;

/// 0 = album cover, 1 = vinyl disc, 2 = turntable with tonearm.
final playerStyle = ValueNotifier<int>(1);

final messengerKey = GlobalKey<ScaffoldMessengerState>();
final currentId = ValueNotifier<String?>(null);

void toast(String msg) {
  messengerKey.currentState
    ?..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
        content: Text(msg), behavior: SnackBarBehavior.floating));
}

Future<void> main() async {
  runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      isTv = (await const MethodChannel('achufy/audio').invokeMethod<bool>('isTv')) ?? false;
    } catch (_) {}
    try {
      final p = await SharedPreferences.getInstance();
      playerStyle.value = p.getInt('player_style') ?? 1;
    } catch (_) {}
    FlutterError.onError = (d) {
      FlutterError.presentError(d);
      toast('Something went wrong. Please try again.');
    };
    await JustAudioBackground.init(
      androidNotificationChannelId: 'com.example.achufy.audio',
      androidNotificationChannelName: 'Achufy playback',
      androidNotificationOngoing: false,
      androidStopForegroundOnPause: true,
    );
    FloatingLyrics.init();
    player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace st) {
      toast(e is PlayerException
          ? "Can't play this track: ${e.message ?? 'unknown error'}"
          : "Playback error. Check the server connection.");
    });
    player.sequenceStateStream.listen((s) {
      final t = s?.currentSource?.tag;
      currentId.value = t is MediaItem ? t.id : null;
    });
    runApp(const App());
  }, (e, st) => toast('Something went wrong: $e'));
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Achufy',
        scaffoldMessengerKey: messengerKey,
        builder: (c, child) => MediaQuery(
          data: MediaQuery.of(c)
              .copyWith(textScaler: TextScaler.linear(isTv ? 1.25 : 1.0)),
          child: child!,
        ),
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
              seedColor: kAccent, brightness: Brightness.dark, primary: kAccent),
          scaffoldBackgroundColor: kBg,
          focusColor: kAccent.withAlpha(110),
          hoverColor: kAccent.withAlpha(50),
          appBarTheme: const AppBarTheme(
              backgroundColor: kBg, elevation: 0, scrolledUnderElevation: 0),
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: kBg,
            indicatorColor: Colors.transparent,
            labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
                fontSize: 12,
                color: s.contains(WidgetState.selected)
                    ? Colors.white
                    : Colors.white54)),
            iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
                color: s.contains(WidgetState.selected)
                    ? Colors.white
                    : Colors.white54)),
          ),
        ),
        home: const SplashPage(),
      );
}
