import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'client.dart';
import 'customize.dart';
import 'engine.dart';
import 'fx.dart';
import 'overlay.dart';
import 'stats.dart';
import 'launch.dart';
import 'splash.dart';

/// The accent colour (changeable in Personalize).
final accentValue = ValueNotifier<int>(0xFFE5383B);
Color get kAccent => Color(accentValue.value);
const kBg = Color(0xFF0A0708);
Color get kCard => Color.lerp(Color(0xFF111012), kAccent, 0.12)!;
Color get kRedDeep => Color.lerp(kBg, kAccent, 0.38)!;
Color get kHeroA => Color.lerp(Colors.black, kAccent, 0.85)!;
Color get kHeroB => Color.lerp(Colors.black, kAccent, 0.22)!;
Color get kNowTop => Color.lerp(kBg, kAccent, 0.45)!;

/// Set after the splash screen so an accent change does not replay it.
bool splashDone = false;

Future<void> setAccent(int v) async {
  accentValue.value = v;
  try {
    (await SharedPreferences.getInstance()).setInt('accent', v);
  } catch (_) {}
}

/// Dark red to black gradient used behind every screen.
class Backdrop extends StatelessWidget {
  final Widget child;
  Backdrop({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [kRedDeep, kBg],
              stops: [0, 0.55]),
        ),
        child: Material(color: Colors.transparent, child: child),
      );
}

/// true on Android TV / devices without a touchscreen.
bool isTv = false;

/// 0 = album cover, 1 = vinyl disc, 2 = turntable, 3 = animated artwork.
final playerStyle = ValueNotifier<int>(1);

final messengerKey = GlobalKey<ScaffoldMessengerState>();
final currentId = ValueNotifier<String?>(null);

void toast(String msg) {
  messengerKey.currentState
    ?..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
        content: Text(msg), behavior: SnackBarBehavior.floating));
}

Future<void> main() async {
  runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      isTv = (await MethodChannel('achufy/audio').invokeMethod<bool>('isTv')) ?? false;
    } catch (_) {}
    try {
      final p = await SharedPreferences.getInstance();
      playerStyle.value = p.getInt('player_style') ?? 1;
      accentValue.value = p.getInt('accent') ?? 0xFFE5383B;
    } catch (_) {}
    FlutterError.onError = (d) {
      FlutterError.presentError(d);
      toast('Something went wrong. Please try again.');
    };
    await JustAudioBackground.init(
      androidNotificationChannelId: 'com.example.achufy.audio',
      androidNotificationChannelName: 'Achufy playback',
      androidNotificationOngoing: false,
      androidStopForegroundOnPause: true,
    );
    FloatingLyrics.init();
    await HomeLayout.I.init();
    await AudioFx.I.init();
    await stats.init();
    await PlaybackEngine.I.init();
    player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace st) {
      toast(e is PlayerException
          ? "Can't play this track: ${e.message ?? 'unknown error'}"
          : "Playback error. Check the server connection.");
    });
    player.sequenceStateStream.listen((s) {
      final t = s?.currentSource?.tag;
      currentId.value = t is MediaItem ? t.id : null;
    });
    runApp(App());
  }, (e, st) => toast('Something went wrong: $e'));
}

class App extends StatelessWidget {
  App({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
      valueListenable: accentValue,
      builder: (_, accent, __) => MaterialApp(
        key: ValueKey(accent),
        title: 'Achufy',
        scaffoldMessengerKey: messengerKey,
        builder: (c, child) => MediaQuery(
          data: MediaQuery.of(c)
              .copyWith(textScaler: TextScaler.linear(isTv ? 1.25 : 1.0)),
          child: child!,
        ),
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
              seedColor: kAccent, brightness: Brightness.dark, primary: kAccent),
          scaffoldBackgroundColor: kBg,
          focusColor: kAccent.withAlpha(110),
          hoverColor: kAccent.withAlpha(50),
          appBarTheme: AppBarTheme(
              backgroundColor: kBg, elevation: 0, scrolledUnderElevation: 0),
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: kBg,
            indicatorColor: Colors.transparent,
            labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
                fontSize: 12,
                color: s.contains(WidgetState.selected)
                    ? Colors.white
                    : Colors.white54)),
            iconTheme: WidgetStateProperty.resolveWith((s) => IconThemeData(
                color: s.contains(WidgetState.selected)
                    ? Colors.white
                    : Colors.white54)),
          ),
        ),
        home: splashDone
            ? (isTv ? ClientPage() : LaunchPage())
            : SplashPage(),
      ));
}
