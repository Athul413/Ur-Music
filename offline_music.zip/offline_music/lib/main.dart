import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'client.dart';
import 'server.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.example.offline_music.audio',
    androidNotificationChannelName: 'Playback',
    androidNotificationOngoing: true,
  );
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Offline Music',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          colorSchemeSeed: const Color(0xFF1DB954),
          useMaterial3: true,
        ),
        home: const ModePicker(),
      );
}

class ModePicker extends StatelessWidget {
  const ModePicker({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Icon(Icons.library_music, size: 72),
                const SizedBox(height: 16),
                const Text('Offline Music',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                const SizedBox(height: 40),
                FilledButton.icon(
                  icon: const Icon(Icons.play_circle),
                  label: const Padding(
                      padding: EdgeInsets.all(14), child: Text('Player (client)')),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ClientPage())),
                ),
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  icon: const Icon(Icons.dns),
                  label: const Padding(
                      padding: EdgeInsets.all(14),
                      child: Text('Music server (old phone)')),
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ServerPage())),
                ),
              ],
            ),
          ),
        ),
      );
}
