# Achufy
Offline music server + player in one APK (phone, tablet and Android TV).

- Front page: status, quick actions, permission check. Server mode lives under "More".
- Player: Home / Search / Library, vinyl or turntable now-playing, synced lyrics,
  floating lyrics (with a close button), output device picker, music from the phone.
- Quit: More (or Settings) > Quit Achufy stops everything and closes the app.
- Connection types: Wi-Fi (auto-find), Tailscale, Web tunnel (Cloudflare/ngrok link),
  Direct IP/DDNS, Achufy relay (see relay/README.md).
- Lyrics: song.lrc / song.txt next to the song. Covers: embedded or cover.jpg / folder.jpg.
