# Achufy
Offline music server + player in one APK (phone, tablet and Android TV).

Studio: 10-slider equalizer (mapped onto the device's hardware bands), presets, bass,
virtualizer, ReplayGain, fade between tracks, spectrum visualizer (5 styles), audio info,
per-song EQ profiles, karaoke vocal reducer.
Intelligence: listening history, stats, smart playlists, mood sorting, similar songs, duplicates.
Lyrics: synced lyrics, floating lyrics, karaoke mode, Lyrics Studio (tap-to-sync, saves .lrc).
Party mode: several devices play the same server song in sync (needs direct/Wi-Fi/Tailscale/tunnel).
Personalize: accent colour, reorderable home sections, player styles (cover, vinyl, turntable, animated).
Connections: Wi-Fi auto-find, Tailscale, web tunnel, direct IP, Achufy relay (see relay/).
Lyrics files: song.lrc / song.txt next to the song. Covers: embedded or cover.jpg / folder.jpg.
