# Achufy
Offline music server + player in one APK.
- Server mode (old phone): serves your music folder, covers and lyrics.
- Player: Home / Search / Your Library, now-playing screen with synced lyrics,
  playlists, liked songs, and music stored on the phone itself.
Lyrics: put song.lrc (synced) or song.txt next to song.mp3.
