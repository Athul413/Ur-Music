# Achufy

Achufy is a local-network music player and music server.

## Build
1. Open this Flutter project in your Flutter environment.
2. Run `flutter pub get`.
3. Build with `flutter build apk --release`.

## Use
1. Install on both phones.
2. On the old phone, open **Music server**, choose your music folder, and start the server.
3. On the player phone, open **Achufy**, enter the server IP and port, then refresh the library.
4. Tap a track to play. Tap the mini-player to open the full-screen player.
5. Long-press a track or use its menu to add it to a playlist.

## Album art and lyrics
Achufy reads embedded album artwork from supported audio files. For synchronized lyrics, place a `.lrc` file next to the audio file with the same filename. Example: `Song.mp3` and `Song.lrc`. Use standard timestamps such as `[00:12.50]Lyric line`.

Lyrics are loaded from your own local files; Achufy does not fetch copyrighted lyrics from online services.
