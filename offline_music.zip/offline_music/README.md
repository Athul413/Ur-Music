# Offline Music
One APK, two modes.
1. Push this folder to a GitHub repo. Actions builds the APK (Actions tab > latest run > Artifacts).
2. Install the APK on both phones.
3. Old phone: open app > Music server > set folder > Start. Note the IP:port shown.
4. Main phone (same Wi-Fi / hotspot): open app > Player > enter IP:port.
Long-press a song to add it to a playlist.
