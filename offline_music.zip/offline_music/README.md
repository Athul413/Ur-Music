# Achufy
Offline music server + player in one APK (phone, tablet and Android TV).

- Server phone: Run as music server. Players find it automatically on Wi-Fi.
- Player: Home / Search / Library, vinyl or turntable now-playing, synced lyrics,
  floating lyrics over other apps, output device picker, music from the phone itself.
- Internet mode: deploy the `relay` folder (see relay/README.md) and use the same
  relay address, room ID and password on the server and the player.
- Lyrics: put song.lrc (synced) or song.txt next to song.mp3. Covers: embedded art,
  or cover.jpg / folder.jpg / song.jpg in the same folder.
