# Achufy

Achufy supports both network-library playback (using the companion server) and local audio files on the player phone.

## Local music
1. Open Achufy and tap the folder icon in the top bar.
2. Select one or more audio files from the phone's file picker.
3. Tap a song to play it. Local songs play directly from the selected file; no server or Wi-Fi is needed.

## Artwork and lyrics
- Album artwork embedded in the audio file is loaded automatically.
- If there is no embedded artwork, Achufy looks for a same-name image beside the audio file (`.jpg`, `.jpeg`, `.png`, or `.webp`).
- Synchronized lyrics are loaded from a same-name `.lrc` file beside the audio file. Example: `Song.mp3` + `Song.lrc`.
- Tap the mini-player to open the full player and synchronized lyrics view.

The existing server mode and playlists are retained. Local files are selected on the player device; the server is optional for local playback.
